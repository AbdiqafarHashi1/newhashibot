// scripts/research/daily-connected/combined.ts
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { gunzipSync, gzipSync } from "node:zlib";
import { createHash } from "node:crypto";

// supabase/functions/_shared/daily-trend-contract.ts
var DAILY_TREND_ID = "crypto.daily-ema-trend";
var DAILY_TREND_PROFILE = "crypto.daily-ema-trend-v1";
var PROMISING_PAIR_PROFILE = "crypto.daily-alt-pair-v1";
var DAILY_EXIT_POLICY = "daily-ema-trail/v1";
var DAILY_SYMBOLS = ["BTCUSDT", "ETHUSDT"];
var dailyEvidence = (e) => e.exit_policy === DAILY_EXIT_POLICY && e.research_only === true && e.instrument_type === "SPOT" && e.score_is_probability === false;
var dailyCandidate = (c) => c.strategyId === DAILY_TREND_ID && c.strategyVersion === "1.0.0" && DAILY_SYMBOLS.includes(c.symbol) && c.timeframe === "1d" && c.side === "buy" && c.targets.length === 0 && c.riskReward === 0 && dailyEvidence(c.evidence);
var DAILY_PROFILES = [DAILY_TREND_PROFILE, PROMISING_PAIR_PROFILE];

// supabase/functions/_shared/crypto-relative-strength-contract.ts
var ALT_CANDIDATE_ID = "crypto.alt-relative-strength-v1";
var ALT_SYMBOLS = Object.freeze(["BNBUSDT", "SOLUSDT", "XRPUSDT", "ADAUSDT", "DOGEUSDT", "LINKUSDT", "AVAXUSDT", "LTCUSDT", "BCHUSDT", "NEARUSDT", "TRXUSDT"]);
var ALT_CONTEXT_BARS = 960;
var ALT_ASSUMPTIONS = Object.freeze({ entryTiming: "NEXT_OPEN", feeBps: 10, spreadBps: 2, slippageBps: 4, fundingBps: 9, partialExitPct: 0, moveStopToBreakevenAfterTp1: false, trailingStopR: null, sameCandlePolicy: "STOP_FIRST", maxBarsInTrade: 96, closeAtHorizon: true });

// supabase/functions/_shared/crypto-relative-strength.ts
var rejected = (reason) => ({ status: "rejected", direction: "none", entry_low: 0, entry_high: 0, stop_loss: 0, tp1: 0, tp2: 0, risk_reward: 0, confidence_score: 0, grade: "reject", reason, rejection_reason: reason, score_breakdown: { research_only: true, score_is_probability: false } });
function altClosedHours(rows, symbol, asOf) {
  const at = Date.parse(asOf), input = rows.slice(-ALT_CONTEXT_BARS);
  if (input.length !== ALT_CONTEXT_BARS || !Number.isFinite(at) || at % 36e5 !== 0) return [];
  if (input.some((b, i) => b.symbol !== symbol || b.timeframe !== "15m" || b.market_type !== "crypto" || b.instrument_type !== "USDT_PERPETUAL" || b.source !== "BINANCE_USDM_KLINES" || ![b.open, b.high, b.low, b.close, b.volume, b.quote_volume].every((x) => typeof x === "number" && Number.isFinite(x) && x >= 0) || b.low <= 0 || b.low > Math.min(b.open, b.close) || b.high < Math.max(b.open, b.close) || !Number.isFinite(Date.parse(b.open_time)) || Date.parse(b.open_time) + 9e5 > at || i > 0 && Date.parse(b.open_time) !== Date.parse(input[i - 1].open_time) + 9e5) || Date.parse(input[0].open_time) % 36e5 || Date.parse(input.at(-1).open_time) + 9e5 !== at) return [];
  const result = [];
  for (let i = 0; i < input.length; i += 4) {
    const g = input.slice(i, i + 4);
    result.push({ ...g[0], timeframe: "1h", open_time: new Date(Date.parse(g[0].open_time)).toISOString(), high: Math.max(...g.map((b) => b.high)), low: Math.min(...g.map((b) => b.low)), close: g[3].close, volume: g.reduce((s, b) => s + b.volume, 0), quote_volume: g.reduce((s, b) => s + b.quote_volume, 0) });
  }
  return result;
}
function evaluateAltRelativeStrength(context) {
  if (context.market !== "crypto" || context.timeframe !== "15m" || !ALT_SYMBOLS.includes(context.symbol)) return rejected("ALT_SYMBOL_OR_TIMEFRAME_INELIGIBLE");
  if (Object.keys(context.strategy_parameters ?? {}).length) return rejected("FROZEN_ALT_PARAMETERS_REQUIRED");
  if (Date.parse(context.evaluated_at) % 36e5 !== 0) return rejected("WAIT_FOR_CLOSED_HOUR");
  const h = altClosedHours(context.candles, context.symbol, context.evaluated_at), peer = altClosedHours(context.reference_candles ?? [], "BTCUSDT", context.evaluated_at);
  if (h.length !== 240 || peer.length !== 240 || h.some((b, i) => b.open_time !== peer[i].open_time)) return rejected("ALIGNED_NATIVE_ALT_BTC_HISTORY_REQUIRED");
  const c = h.at(-1), mean3 = (a) => a.reduce((s, x) => s + x, 0) / a.length;
  const atr2 = mean3(h.slice(-21, -1).map((b, i) => Math.max(b.high - b.low, Math.abs(b.high - h[h.length - 22 + i].close), Math.abs(b.low - h[h.length - 22 + i].close)))), recent = h.slice(-25, -1), ret = c.close / h[h.length - 25].close - 1, btcRet = peer.at(-1).close / peer[peer.length - 25].close - 1, week = c.close / h[h.length - 169].close - 1;
  if (!(atr2 > 0 && btcRet > 0 && ret >= 0.03 && ret - btcRet >= 0.02 && week > 0 && c.close > Math.max(...recent.map((b) => b.high)) && c.quote_volume >= 1.5 * mean3(recent.map((b) => b.quote_volume)))) return rejected("NO_RELATIVE_STRENGTH_BREAKOUT");
  const stop = Math.min(c.close - 2 * atr2, ...recent.map((b) => b.low)), target = c.close + 3 * (c.close - stop), risk = Math.abs(c.close - stop), rr = Math.abs(target - c.close) / risk;
  if (stop <= 0 || target <= 0 || rr < 1.3 || risk / c.close < 0.01 || Math.abs(target - c.close) / c.close < 5 * 25 / 1e4) return rejected("ALT_GEOMETRY_OR_COST_REJECTED");
  return { status: "candidate", direction: "buy", entry_low: c.close, entry_high: c.close, stop_loss: stop, tp1: target, tp2: target, risk_reward: rr, confidence_score: 80, grade: "A", reason: "Hourly altcoin relative-strength breakout; unqualified research", rejection_reason: "", score_breakdown: { research_only: true, score_is_probability: false, relative_strength_policy: "alt-relative-strength/v1", closed_hour_breakout: true, btc_return: btcRet, alt_return: ret, week_return: week, quote_volume_ratio: c.quote_volume / mean3(recent.map((b) => b.quote_volume)), atr: atr2, relative_return: ret - btcRet, estimated_cost_bps: 25, reference_symbol: "BTCUSDT" } };
}
function altResearchDefinitions() {
  return [{ id: ALT_CANDIDATE_ID, version: "1.0.0", legacyName: "AltRelativeStrength", market: "crypto", lifecycle: "DISABLED", publicationMode: "SHADOW", certification: "RESEARCH", config: { strategy_name: "AltRelativeStrength", enabled: false, min_score: 75, min_rr: 1.3, max_bars_in_trade: 96, allowed_symbols: [...ALT_SYMBOLS], allowed_timeframes: ["15m"], params: {} }, evaluate: evaluateAltRelativeStrength }];
}
function altReplayConfiguration() {
  return { researchOnly: true, version: "research/alt-relative-strength/v1", minSignalGrade: "A", outcomeAssumptions: { ...ALT_ASSUMPTIONS }, strategies: [{ id: ALT_CANDIDATE_ID, version: "1.0.0", enabled: true, minScore: 75, minRiskReward: 1.3, maxBarsInTrade: 96, symbols: [...ALT_SYMBOLS], timeframes: ["15m"], parameters: {} }] };
}
function usesAltReference(configuration) {
  return configuration.strategies.some((s) => s.enabled && s.id === ALT_CANDIDATE_ID);
}
function replayContextBars(configuration) {
  return usesAltReference(configuration) ? ALT_CONTEXT_BARS : 110;
}
var canonical = (value) => value === null || typeof value !== "object" ? JSON.stringify(value) : Array.isArray(value) ? `[${value.map(canonical).join(",")}]` : `{${Object.entries(value).sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => `${JSON.stringify(k)}:${canonical(v)}`).join(",")}}`;
function validateAltDatasetSelection(configuration, datasets) {
  if (!usesAltReference(configuration)) return;
  if (configuration.strategies.length !== 1 || canonical(configuration) !== canonical(altReplayConfiguration())) throw Error("ALT_FROZEN_CONFIGURATION_REQUIRED");
  if (datasets.length < 2 || datasets.length > 4 || datasets.filter((d) => d.symbol === "BTCUSDT").length !== 1 || datasets.some((d) => d.timeframe !== "15m" || (d.market_type ?? d.market) !== "crypto" || d.symbol !== "BTCUSDT" && !ALT_SYMBOLS.includes(d.symbol)) || new Set(datasets.map((d) => d.symbol)).size !== datasets.length) throw Error("ALT_REQUIRES_BTC_AND_ONE_TO_THREE_ALTS_15M");
}

// supabase/functions/_shared/daily-trend-profile.ts
var DAILY_ASSUMPTIONS = { entryTiming: "NEXT_OPEN", feeBps: 20, spreadBps: 2, slippageBps: 4, fundingBps: 0, partialExitPct: 0, moveStopToBreakevenAfterTp1: false, trailingStopR: null, sameCandlePolicy: "STOP_FIRST", closeAtHorizon: false };
function dailyConfiguration(id2 = DAILY_TREND_PROFILE) {
  if (!DAILY_PROFILES.includes(id2)) throw Error("DAILY_PROFILE_UNKNOWN");
  return { researchOnly: true, version: id2, minSignalGrade: "A", outcomeAssumptions: id2 === PROMISING_PAIR_PROFILE ? { ...altReplayConfiguration().outcomeAssumptions } : { ...DAILY_ASSUMPTIONS }, strategies: [{ id: DAILY_TREND_ID, version: "1.0.0", enabled: true, minScore: 75, minRiskReward: 0, maxBarsInTrade: 3650, symbols: [...DAILY_SYMBOLS], timeframes: ["1d"], parameters: {} }, ...id2 === PROMISING_PAIR_PROFILE ? altReplayConfiguration().strategies.map((s) => ({ ...s, symbols: ["BNBUSDT", "SOLUSDT", "XRPUSDT"] })) : []] };
}
var hasDaily = (c) => c.strategies.some((s) => s.id === DAILY_TREND_ID);
var stable = (x) => x === null || typeof x !== "object" ? JSON.stringify(x) : Array.isArray(x) ? `[${x.map(stable)}]` : `{${Object.entries(x).sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => `${JSON.stringify(k)}:${stable(v)}`).join(",")}}`;
function validateDailySelection(c, d) {
  if (!DAILY_PROFILES.some((id2) => stable(c) === stable(dailyConfiguration(id2)))) throw Error("DAILY_FROZEN_CONFIGURATION_REQUIRED");
  const pair = c.version === PROMISING_PAIR_PROFILE;
  if (!d.length || d.length > (pair ? 6 : 2) || new Set(d.map((x) => x.symbol + ":" + x.timeframe)).size !== d.length || d.some((x) => (x.market_type ?? x.market) !== "crypto" || !(x.timeframe === "1d" && DAILY_SYMBOLS.includes(x.symbol) || pair && x.timeframe === "15m" && ["BTCUSDT", "BNBUSDT", "SOLUSDT", "XRPUSDT"].includes(x.symbol))) || !d.some((x) => x.timeframe === "1d") || pair && (d.filter((x) => x.timeframe === "15m" && x.symbol === "BTCUSDT").length !== 1 || !d.some((x) => x.timeframe === "15m" && x.symbol !== "BTCUSDT"))) throw Error("DAILY_NATIVE_SCOPE_REQUIRED");
}
function dailyOutcomeAssumptions(id2, fallback) {
  return id2 === DAILY_TREND_ID ? { ...DAILY_ASSUMPTIONS } : fallback;
}

// supabase/functions/_shared/replay-market-window.ts
var ACTIVE_MARKET_WINDOW = 110;
function closedFifteenMinuteContext(input, asOf) {
  const limit = Date.parse(asOf);
  if (!Number.isFinite(limit)) throw new Error("INVALID_HIGHER_TIMEFRAME_BOUNDARY");
  const groups = /* @__PURE__ */ new Map();
  for (const c of input) {
    const at = Date.parse(c.open_time);
    if (c.timeframe !== "5m" || !Number.isFinite(at) || at + 3e5 > limit) continue;
    const bucket = Math.floor(at / 9e5) * 9e5;
    if (bucket + 9e5 > limit) continue;
    const group = groups.get(bucket) ?? [];
    group.push(c);
    groups.set(bucket, group);
  }
  const output = [];
  for (const [at, bars] of [...groups.entries()].sort(([a], [b]) => a - b)) {
    bars.sort((a, b) => Date.parse(a.open_time) - Date.parse(b.open_time));
    if (bars.length !== 3 || bars.some((c, i) => Date.parse(c.open_time) !== at + i * 3e5 || c.symbol !== bars[0].symbol || c.source !== bars[0].source)) continue;
    output.push({ ...bars[0], timeframe: "15m", open_time: new Date(at).toISOString(), open: bars[0].open, high: Math.max(...bars.map((c) => c.high)), low: Math.min(...bars.map((c) => c.low)), close: bars[2].close, volume: bars.reduce((s, c) => s + c.volume, 0), source: bars[0].source + ":CLOSED_5M_AGGREGATE" });
  }
  return output.slice(-ACTIVE_MARKET_WINDOW);
}

// supabase/functions/_shared/daily-trend.ts
var DAY = 864e5;
function dailySeries(rows) {
  const ema2 = (n) => {
    const out = [];
    for (let i = 0; i < rows.length; i++) out.push(i ? out[i - 1] + 2 / (n + 1) * (rows[i].close - out[i - 1]) : rows[i].close);
    return out;
  };
  const atr2 = Array(rows.length).fill(NaN), tr = rows.map((c, i) => i ? Math.max(c.high - c.low, Math.abs(c.high - rows[i - 1].close), Math.abs(c.low - rows[i - 1].close)) : NaN);
  if (rows.length > 14) {
    atr2[14] = tr.slice(1, 15).reduce((a, b) => a + b, 0) / 14;
    for (let i = 15; i < rows.length; i++) atr2[i] = (atr2[i - 1] * 13 + tr[i]) / 14;
  }
  return { fast: ema2(20), slow: ema2(50), regime: ema2(200), atr: atr2 };
}
function admitDailyRows(rows, symbol) {
  return DAILY_SYMBOLS.includes(symbol) && rows.length >= 201 && rows.every((c, i) => c.symbol === symbol && c.timeframe === "1d" && c.market_type === "crypto" && c.instrument_type === "SPOT" && ["BINANCE_KLINES", "BINANCE_SPOT_KLINES"].includes(c.source) && Number.isFinite(Date.parse(c.open_time)) && Date.parse(c.open_time) % DAY === 0 && (!i || Date.parse(c.open_time) - Date.parse(rows[i - 1].open_time) === DAY) && [c.open, c.high, c.low, c.close, c.volume].every(Number.isFinite) && c.low > 0 && c.volume >= 0 && c.low <= Math.min(c.open, c.close) && c.high >= Math.max(c.open, c.close));
}
function evaluateDailyTrend(ctx) {
  const rejected3 = (reason) => ({ status: "rejected", direction: "none", entry_low: 0, entry_high: 0, stop_loss: 0, tp1: 0, tp2: 0, risk_reward: 0, confidence_score: 0, grade: "reject", reason, rejection_reason: reason, score_breakdown: {} });
  if (ctx.market !== "crypto" || ctx.timeframe !== "1d" || Object.keys(ctx.strategy_parameters ?? {}).length || !admitDailyRows(ctx.candles, ctx.symbol) || Date.parse(ctx.candles.at(-1).open_time) + DAY !== Date.parse(ctx.evaluated_at)) return rejected3("DAILY_NATIVE_SPOT_HISTORY_REQUIRED");
  const f = dailySeries(ctx.candles), i = ctx.candles.length - 1, c = ctx.candles[i], stop = c.close - 2 * f.atr[i];
  if (!(f.fast[i] > f.slow[i] && c.close > f.regime[i] && f.atr[i] > 0 && stop > 0)) return rejected3("DAILY_BULL_REGIME_ABSENT");
  return { status: "candidate", direction: "buy", entry_low: c.close, entry_high: c.close, stop_loss: stop, tp1: 0, tp2: 0, risk_reward: 0, confidence_score: 80, grade: "A", reason: "Closed daily EMA20 > EMA50 and close > EMA200; next-open SPOT entry; 2ATR protection and 3ATR closed-bar trail; regime exit next open.", rejection_reason: "", score_breakdown: { exit_policy: DAILY_EXIT_POLICY, research_only: true, instrument_type: "SPOT", score_is_probability: false, rr_status: "NOT_APPLICABLE", ema20: f.fast[i], ema50: f.slow[i], ema200: f.regime[i], atr14: f.atr[i], seed_open_time: ctx.candles[0].open_time, seed_policy: "FIRST_CLOSE_RECURSIVE", cost_bps: 26 } };
}
function dailyTrendDefinitions() {
  return [{ id: DAILY_TREND_ID, version: "1.0.0", legacyName: "DailyEmaTrend", market: "crypto", lifecycle: "DISABLED", publicationMode: "SHADOW", certification: "RESEARCH", config: { strategy_name: "DailyEmaTrend", enabled: false, min_score: 75, min_rr: 0, max_bars_in_trade: 3650, allowed_symbols: [...DAILY_SYMBOLS], allowed_timeframes: ["1d"], params: {} }, evaluate: evaluateDailyTrend }];
}

// supabase/functions/_shared/daily-trend-outcome.ts
function* dailyTrendOutcomeSteps(c, rows, after, costBps = 26) {
  if (!dailyCandidate(c) || !admitDailyRows(rows, c.symbol)) throw Error("DAILY_EXIT_CONTRACT_INVALID");
  const at = Date.parse(after), first = rows.findIndex((r) => Date.parse(r.open_time) === at);
  if (first < 0) return null;
  if (first < 201) throw Error("DAILY_SEED_PREFIX_REQUIRED");
  const f = dailySeries(rows), entry = rows[first].open, risk = entry - c.stop, events = [];
  const result = (status, exit, index, reason) => ({ candidateId: c.id, strategyId: c.strategyId, symbol: c.symbol, timeframe: c.timeframe, status, entryTime: rows[first].open_time, exitTime: index === null ? null : rows[index].open_time, entryPrice: entry, exitPrice: exit, grossR: exit === null ? null : (exit - entry) / risk, netR: exit === null ? null : (exit - entry) / risk - entry * costBps / 1e4 / risk, costR: risk > 0 ? entry * costBps / 1e4 / risk : 0, partialExit: false, conservative: status === "STOP", exclusionReason: reason, cashFlowEvents: events });
  if (!(entry > c.stop && c.stop > 0)) return { ...result("EXCLUDED", null, null, "ENTRY_GAP_BEYOND_STOP"), costR: 0 };
  events.push({ candidateId: c.id, time: rows[first].open_time, kind: "COST", sequence: 0, realizedR: -entry * costBps / 1e4 / risk });
  let stop = c.stop, exitNext = false;
  for (let i = first; i < rows.length; i++) {
    yield;
    const row = rows[i];
    let fill = null, status = "OPEN";
    if (exitNext) {
      fill = row.open;
      status = "REGIME_EXIT";
    } else if (row.low <= stop) {
      fill = Math.min(stop, row.open);
      status = "STOP";
    }
    if (fill !== null) {
      events.push({ candidateId: c.id, time: row.open_time, kind: "EXIT", sequence: 1, realizedR: (fill - entry) / risk });
      return result(status, fill, i);
    }
    stop = Math.max(stop, row.close - 3 * f.atr[i]);
    exitNext = f.fast[i] <= f.slow[i] || row.close < f.regime[i];
  }
  return result("OPEN", null, null);
}

// supabase/functions/_shared/replay-outcomes.ts
function validateReplayAssumptions(a) {
  if (a.tp1StopPolicy !== void 0 && !["NEXT_BAR", "CONSERVATIVE_SAME_BAR"].includes(a.tp1StopPolicy)) throw new Error("INVALID_TP1_STOP_POLICY");
  if (a.entryTiming !== "NEXT_OPEN" || !["STOP_FIRST", "AMBIGUOUS"].includes(a.sameCandlePolicy)) throw new Error("UNSUPPORTED_REPLAY_POLICY");
  if (![a.feeBps, a.spreadBps, a.slippageBps, a.fundingBps].every((x) => Number.isFinite(x) && x >= 0)) throw new Error("INVALID_REPLAY_COSTS");
  if (!Number.isFinite(a.partialExitPct) || a.partialExitPct < 0 || a.partialExitPct > 1) throw new Error("INVALID_PARTIAL_EXIT_PERCENTAGE");
  if (a.trailingStopR !== null && (!Number.isFinite(a.trailingStopR) || a.trailingStopR < 0)) throw new Error("INVALID_TRAILING_STOP");
  if (a.maxBarsInTrade !== void 0 && (!Number.isInteger(a.maxBarsInTrade) || a.maxBarsInTrade < 1)) throw new Error("INVALID_MAX_BARS_IN_TRADE");
}
function* evaluateReplayOutcomeSteps(candidate2, candles, after, a) {
  validateReplayAssumptions(a);
  if (dailyCandidate(candidate2)) {
    const cost = a.feeBps + a.spreadBps + a.slippageBps;
    if (a.fundingBps !== 0 || ![26, 39].includes(cost) || a.partialExitPct !== 0 || a.moveStopToBreakevenAfterTp1 || a.closeAtHorizon) throw Error("DAILY_FROZEN_EXIT_COST_REQUIRED");
    return yield* dailyTrendOutcomeSteps(candidate2, candles, after, cost);
  }
  const path = candles.filter((c) => Date.parse(c.open_time) >= Date.parse(after));
  if (!path.length) return null;
  const entryCandle = path[0], entry = entryCandle.open, sign = candidate2.side === "buy" ? 1 : -1;
  const excluded = (reason) => ({ candidateId: candidate2.id, strategyId: candidate2.strategyId, symbol: candidate2.symbol, timeframe: candidate2.timeframe, status: "EXCLUDED", entryTime: entryCandle.open_time, exitTime: null, entryPrice: entry, exitPrice: null, grossR: null, netR: null, costR: 0, partialExit: false, conservative: true, exclusionReason: reason, cashFlowEvents: [] });
  if (!Number.isFinite(entry) || !Number.isFinite(candidate2.stop) || !candidate2.targets.length || candidate2.targets.some((x) => !Number.isFinite(x))) return excluded("INVALID_ENTRY_GEOMETRY");
  const stopDistance = (entry - candidate2.stop) * sign;
  if (stopDistance <= 0) return excluded((candidate2.stop - entry) * sign >= 0 ? "ENTRY_GAP_BEYOND_STOP" : "INVALID_ENTRY_GEOMETRY");
  const targetDistances = candidate2.targets.map((x) => (x - entry) * sign);
  if (targetDistances.some((x) => x <= 0) || targetDistances.some((x, i) => i > 0 && x < targetDistances[i - 1])) return excluded("ENTRY_GAP_BEYOND_TARGET_OR_INVALID_GEOMETRY");
  const risk = stopDistance, tp1 = candidate2.targets[0], tp2 = candidate2.targets.at(-1);
  const costR = entry * (a.feeBps + a.spreadBps + a.slippageBps + a.fundingBps) / 1e4 / risk;
  let stop = candidate2.stop, tp1Hit = false, gross = 0, seq = 0;
  const events = [{ time: entryCandle.open_time, candidateId: candidate2.id, kind: "COST", sequence: seq++, realizedR: -costR }];
  const realized = (price, qty) => (price - entry) * sign / risk * qty;
  const row = (status, exitTime, exitPrice, ambiguous = false) => ({ candidateId: candidate2.id, strategyId: candidate2.strategyId, symbol: candidate2.symbol, timeframe: candidate2.timeframe, status, entryTime: entryCandle.open_time, exitTime, entryPrice: entry, exitPrice, grossR: status === "OPEN" || ambiguous ? null : gross, netR: status === "OPEN" || ambiguous ? null : gross - costR, costR, partialExit: tp1Hit, conservative: ambiguous || status === "STOP", cashFlowEvents: events });
  const limited = path.slice(0, a.maxBarsInTrade ?? path.length);
  for (const candle of limited) {
    yield;
    const hitStop = sign === 1 ? candle.low <= stop : candle.high >= stop;
    const hitTp1 = !tp1Hit && (sign === 1 ? candle.high >= tp1 : candle.low <= tp1);
    const hitTp2 = sign === 1 ? candle.high >= tp2 : candle.low <= tp2;
    if (hitStop && (hitTp1 || hitTp2)) {
      if (a.sameCandlePolicy === "AMBIGUOUS") return row("AMBIGUOUS", candle.open_time, null, true);
      const fill = sign === 1 ? Math.min(stop, candle.open) : Math.max(stop, candle.open);
      const amount = realized(fill, tp1Hit ? 1 - a.partialExitPct : 1);
      gross += amount;
      events.push({ time: candle.open_time, candidateId: candidate2.id, kind: "EXIT", sequence: seq++, realizedR: amount });
      return row("STOP", candle.open_time, fill);
    }
    if (hitStop) {
      const fill = sign === 1 ? Math.min(stop, candle.open) : Math.max(stop, candle.open);
      const amount = realized(fill, tp1Hit ? 1 - a.partialExitPct : 1);
      gross += amount;
      events.push({ time: candle.open_time, candidateId: candidate2.id, kind: "EXIT", sequence: seq++, realizedR: amount });
      return row("STOP", candle.open_time, fill);
    }
    if (hitTp1) {
      tp1Hit = true;
      const amount = realized(tp1, a.partialExitPct);
      gross += amount;
      events.push({ time: candle.open_time, candidateId: candidate2.id, kind: "TP1", sequence: seq++, realizedR: amount });
      if (a.partialExitPct === 1) return row("TARGET", candle.open_time, tp1);
      if (a.moveStopToBreakevenAfterTp1) stop = entry;
      if (a.trailingStopR !== null) stop = sign === 1 ? Math.max(stop, entry + risk * a.trailingStopR) : Math.min(stop, entry - risk * a.trailingStopR);
    }
    if (hitTp1 && a.tp1StopPolicy === "CONSERVATIVE_SAME_BAR" && (a.moveStopToBreakevenAfterTp1 || a.trailingStopR !== null) && (sign === 1 ? candle.low <= stop : candle.high >= stop)) {
      if (a.sameCandlePolicy === "AMBIGUOUS") return row("AMBIGUOUS", candle.open_time, null, true);
      const amount = realized(stop, 1 - a.partialExitPct);
      gross += amount;
      events.push({ time: candle.open_time, candidateId: candidate2.id, kind: "EXIT", sequence: seq++, realizedR: amount });
      return row("STOP", candle.open_time, stop);
    }
    if (hitTp2) {
      const amount = realized(tp2, tp1Hit ? 1 - a.partialExitPct : 1);
      gross += amount;
      events.push({ time: candle.open_time, candidateId: candidate2.id, kind: "EXIT", sequence: seq++, realizedR: amount });
      return row("TARGET", candle.open_time, tp2);
    }
  }
  if (a.closeAtHorizon && limited.length && (a.maxBarsInTrade === void 0 || limited.length === a.maxBarsInTrade)) {
    const last = limited.at(-1), amount = realized(last.close, tp1Hit ? 1 - a.partialExitPct : 1);
    gross += amount;
    events.push({ time: last.open_time, candidateId: candidate2.id, kind: "EXIT", sequence: seq++, realizedR: amount });
    return row("TIMEOUT", last.open_time, last.close);
  }
  return row("OPEN", null, null);
}
function summarizeReplayOutcomes(rows) {
  const resolved = rows.filter((r) => r.netR !== null), returns = resolved.map((r) => r.netR), wins = returns.filter((x) => x > 0), losses = returns.filter((x) => x < 0), grossProfit = wins.reduce((a, b) => a + b, 0), grossLoss = Math.abs(losses.reduce((a, b) => a + b, 0));
  const events = rows.flatMap((r) => r.cashFlowEvents).sort((a, b) => Date.parse(a.time) - Date.parse(b.time) || a.candidateId.localeCompare(b.candidateId) || a.sequence - b.sequence);
  let equity = 0, peak = 0, drawdown = 0;
  const realizedEquityCurve = events.map((e) => {
    equity += e.realizedR;
    peak = Math.max(peak, equity);
    drawdown = Math.max(drawdown, peak - equity);
    return { ...e, equityR: equity };
  });
  return { analysisMode: "INDEPENDENT_SIGNAL_OUTCOMES", overlapPolicy: "NOT_PORTFOLIO_NETTED", tradeCount: rows.length, resolvedCount: resolved.length, openCount: rows.filter((r) => r.status === "OPEN").length, ambiguousCount: rows.filter((r) => r.status === "AMBIGUOUS").length, excludedCount: rows.filter((r) => r.status === "EXCLUDED").length, expectancyR: returns.length ? returns.reduce((a, b) => a + b, 0) / returns.length : null, profitFactor: grossLoss ? grossProfit / grossLoss : null, profitFactorUndefinedReason: grossLoss ? null : grossProfit > 0 ? "NO_LOSING_TRADES" : "NO_RESOLVED_PROFIT", realizedMaxDrawdownR: events.length ? drawdown : null, realizedEquityCurve };
}
function evaluateReplayOutcome(...input) {
  const steps = evaluateReplayOutcomeSteps(...input);
  let step = steps.next();
  while (step.done === false) step = steps.next();
  return step.value;
}

// supabase/functions/_shared/scanner-replay-lifecycle.ts
var REPLAY_LIFECYCLE_VERSION = "observed-closed-bars/v1";
function replayCandleWidth(timeframe) {
  const match = /^(\d+)(m|h|d)$/.exec(timeframe);
  if (!match) throw Error("LIFECYCLE_TIMEFRAME_INVALID");
  const n = Number(match[1]) * (match[2] === "m" ? 6e4 : match[2] === "h" ? 36e5 : 864e5);
  if (!(n > 0)) throw Error("LIFECYCLE_TIMEFRAME_INVALID");
  return n;
}
function observeReplayPosition(position, candles, asOf) {
  const width2 = replayCandleWidth(position.candidate.timeframe), at = Date.parse(asOf), start = Date.parse(position.decisionAt);
  if (!Number.isFinite(at) || !Number.isFinite(start) || at < start) return null;
  const lower = (time) => {
    let left = 0, right = candles.length;
    while (left < right) {
      const mid = left + right >>> 1;
      if (Date.parse(candles[mid].open_time) < time) left = mid + 1;
      else right = mid;
    }
    return left;
  };
  const from = lower(start), until = lower(at - width2 + 1), path = candles.slice(from, Math.min(until, from + (position.assumptions.maxBarsInTrade ?? candles.length)));
  if (!path.length || Date.parse(path[0].open_time) !== start) return null;
  if (path.some((c, i) => c.symbol !== position.candidate.symbol || c.timeframe !== position.candidate.timeframe || Date.parse(c.open_time) !== start + i * width2 || ![c.open, c.high, c.low, c.close].every(Number.isFinite) || c.low <= 0 || c.low > Math.min(c.open, c.close) || c.high < Math.max(c.open, c.close))) return null;
  const result = evaluateReplayOutcome(position.candidate, dailyCandidate(position.candidate) ? candles.slice(0, until) : path, position.decisionAt, position.assumptions);
  if (!result || result.status === "OPEN" || result.status === "AMBIGUOUS") return null;
  const knownAt = Date.parse(result.exitTime ?? path[0].open_time) + width2;
  return knownAt <= at ? { result, knownAt: new Date(knownAt).toISOString() } : null;
}

// supabase/functions/_shared/indicator-engine.ts
function emaRootV1(values, period) {
  if (values.length < period) return values[values.length - 1] ?? 0;
  const k = 2 / (period + 1);
  let ema2 = values.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < values.length; i++) ema2 = values[i] * k + ema2 * (1 - k);
  return ema2;
}
function rsiRootV1(values, period = 14) {
  if (values.length < period + 2) return 50;
  let gains = 0, losses = 0;
  for (let i = values.length - period; i < values.length; i++) {
    const d = values[i] - values[i - 1];
    if (d > 0) gains += d;
    else losses -= d;
  }
  if (gains === 0 && losses === 0) return 50;
  const rs = losses === 0 ? 100 : gains / losses;
  return 100 - 100 / (1 + rs);
}
function trueRange(candle, previousClose) {
  return previousClose === void 0 ? candle.high - candle.low : Math.max(candle.high - candle.low, Math.abs(candle.high - previousClose), Math.abs(candle.low - previousClose));
}
function atrRootV1(candles, period = 14) {
  if (candles.length < period + 1) return 0;
  const ranges = [];
  for (let i = 1; i < candles.length; i++) ranges.push(trueRange(candles[i], candles[i - 1].close));
  return ranges.slice(-period).reduce((a, b) => a + b, 0) / period;
}
var highestHigh = (candles, lookback) => Math.max(...candles.slice(-lookback).map((c) => c.high));
var lowestLow = (candles, lookback) => Math.min(...candles.slice(-lookback).map((c) => c.low));
var rollingRange = (candles, lookback) => highestHigh(candles, lookback) - lowestLow(candles, lookback);
var rollingAverageVolume = (candles, period) => candles.slice(-period).reduce((sum, c) => sum + c.volume, 0) / period;

// supabase/functions/_shared/coordinated-crypto-contract.ts
var CRYPTO_TEAM_VERSION = "1.0.0";
var CRYPTO_TEAM_PROFILE = "crypto.four-role-v1";
var CRYPTO_TEAM_ROLES = [
  { id: "crypto.team-trend", name: "CryptoTrendContinuation", label: "Trend pullback", regime: "TREND", description: "H1 trend and H4 alignment; pullback reclaim, structural ATR protection." },
  { id: "crypto.team-range", name: "CryptoRangeReversal", label: "Range reversal", regime: "RANGE", description: "Stable H1 balance; rejected boundary, target the mean; no fading trends." },
  { id: "crypto.team-breakout", name: "CryptoExpansionBreakout", label: "Compression breakout", regime: "EXPANSION", description: "Closed H1 range break with native quote-volume expansion and H4 alignment." },
  { id: "crypto.team-alt", name: "CryptoAltRelativeStrength", label: "Altcoin relative strength", regime: "TREND_UP_OR_EXPANSION_UP", description: "Frozen BTC-relative breakout arithmetic, restricted to the shared bullish regime." }
];
var CRYPTO_TEAM_SYMBOLS = Object.freeze(["BTCUSDT", "ETHUSDT", ...ALT_SYMBOLS]);
var CRYPTO_TEAM_ASSUMPTIONS = Object.freeze({ ...ALT_ASSUMPTIONS });
var CRYPTO_TEAM_PROFILE_IDS = Object.freeze([CRYPTO_TEAM_PROFILE, ...CRYPTO_TEAM_ROLES.map((r) => r.id)]);
var CRYPTO_TEAM_CATALOG = Object.freeze([
  { id: CRYPTO_TEAM_PROFILE, label: "Four crypto roles together \xB7 research", symbols: [...CRYPTO_TEAM_SYMBOLS], costBps: 25, warmupBars: 960 },
  ...CRYPTO_TEAM_ROLES.map((r) => ({ id: r.id, label: `${r.label} \xB7 coordinated research`, symbols: r.id === "crypto.team-alt" ? [...ALT_SYMBOLS] : [...CRYPTO_TEAM_SYMBOLS], costBps: 25, warmupBars: 960 }))
]);

// supabase/functions/_shared/coordinated-crypto.ts
var empty = (reason) => ({ state: "UNAVAILABLE", hours: [], atr: 0, trend: 0, efficiency: 0, higherDirection: 0, quoteRatio: 0, high: 0, low: 0, ema: 0, reason });
var mean = (values) => values.reduce((n, x) => n + x, 0) / values.length;
var reject = (reason, state2 = "UNAVAILABLE") => ({ status: "rejected", direction: "none", entry_low: 0, entry_high: 0, stop_loss: 0, tp1: 0, tp2: 0, risk_reward: 0, confidence_score: 0, grade: "reject", reason, rejection_reason: reason, score_breakdown: { research_only: true, score_is_probability: false, team_policy: "crypto-team/v1", team_state: state2 } });
function cryptoTeamFeatures(context) {
  if (context.market !== "crypto" || context.timeframe !== "15m" || !CRYPTO_TEAM_SYMBOLS.includes(context.symbol)) return empty("TEAM_IDENTITY_UNSUPPORTED");
  const at = Date.parse(context.evaluated_at);
  if (!Number.isFinite(at) || at % 36e5 !== 0) return empty("WAIT_FOR_CLOSED_HOUR");
  const h = altClosedHours(context.candles, context.symbol, context.evaluated_at);
  if (h.length !== 240) return empty("TEAM_NATIVE_HISTORY_REQUIRED");
  const prior = h.slice(0, -1), c = h.at(-1), previous = h.at(-2), atr2 = atrRootV1(prior, 14), closes = h.map((b) => b.close), ema2 = emaRootV1(closes, 20), fast = emaRootV1(closes, 20), slow = emaRootV1(closes, 50);
  const groups = /* @__PURE__ */ new Map();
  for (const b of h) {
    const t = Date.parse(b.open_time), bucket = Math.floor(t / 144e5) * 144e5;
    const g = groups.get(bucket) ?? [];
    g.push(b);
    groups.set(bucket, g);
  }
  const four = [...groups].flatMap(([t, g]) => g.length === 4 && g.every((b, i) => Date.parse(b.open_time) === t + i * 36e5) ? [{ ...g[0], timeframe: "4h", high: Math.max(...g.map((b) => b.high)), low: Math.min(...g.map((b) => b.low)), close: g[3].close }] : []);
  if (four.length < 50 || !(atr2 > 0)) return empty("TEAM_HIGHER_HISTORY_REQUIRED");
  const hc = four.map((b) => b.close), hf = emaRootV1(hc, 8), hs = emaRootV1(hc, 21), old = emaRootV1(hc.slice(0, -1), 8), higherDirection = hf > hs && hf > old ? 1 : hf < hs && hf < old ? -1 : 0;
  const path = h.slice(-21), travel = path.slice(1).reduce((s, b, i) => s + Math.abs(b.close - path[i].close), 0), efficiency = travel ? Math.abs(c.close - path[0].close) / travel : 0, trend = (fast - slow) / atr2, recent = h.slice(-25, -1), high = Math.max(...recent.map((b) => b.high)), low = Math.min(...recent.map((b) => b.low)), quoteRatio = c.quote_volume / mean(recent.map((b) => b.quote_volume));
  if (!Number.isFinite(quoteRatio) || !(mean(recent.map((b) => b.quote_volume)) > 0)) return empty("TEAM_NATIVE_VOLUME_REQUIRED");
  const compressed = mean(prior.slice(-6).map((b) => b.high - b.low)) < 0.85 * atr2, up = compressed && c.close > high + 0.1 * atr2 && quoteRatio >= 1.5 && higherDirection >= 0, down = compressed && c.close < low - 0.1 * atr2 && quoteRatio >= 1.5 && higherDirection <= 0;
  let state2 = "TRANSITION";
  if (Math.max(c.high - c.low, Math.abs(c.high - previous.close), Math.abs(c.low - previous.close)) > 3 * atr2 || Math.abs(c.open - previous.close) > atr2) state2 = "SHOCK";
  else if (up) state2 = "EXPANSION_UP";
  else if (down) state2 = "EXPANSION_DOWN";
  else if (trend > 0.6 && efficiency >= 0.25 && higherDirection === 1) state2 = "TREND_UP";
  else if (trend < -0.6 && efficiency >= 0.25 && higherDirection === -1) state2 = "TREND_DOWN";
  else if (Math.abs(trend) < 0.4 && efficiency < 0.2 && Math.abs(hf - hs) / atr2 < 1) state2 = "RANGE";
  return { state: state2, hours: h, atr: atr2, trend, efficiency, higherDirection, quoteRatio, high, low, ema: ema2, reason: state2 };
}
function evaluateCryptoTeam(id2, context, features = cryptoTeamFeatures(context)) {
  if (!CRYPTO_TEAM_ROLES.some((r) => r.id === id2) || Object.keys(context.strategy_parameters ?? {}).length) return reject("TEAM_FROZEN_POLICY_REQUIRED");
  const f = features;
  if (["UNAVAILABLE", "SHOCK", "TRANSITION"].includes(f.state)) return reject(f.reason, f.state);
  const h = f.hours, c = h.at(-1), p = h.at(-2), prior = h.slice(0, -1), atr2 = f.atr;
  let side = 0, stop = 0, target = 0, setup = "";
  if (id2 === "crypto.team-alt") {
    if (!["TREND_UP", "EXPANSION_UP"].includes(f.state)) return reject("ALT_REQUIRES_BULLISH_TEAM_STATE", f.state);
    const original = evaluateAltRelativeStrength(context);
    if (original.status !== "candidate") return original;
    return { ...original, score_breakdown: { ...original.score_breakdown, team_policy: "crypto-team/v1", team_role: id2, team_state: f.state, higher_direction: f.higherDirection, source_close: context.evaluated_at } };
  }
  if (id2 === "crypto.team-trend") {
    side = f.state === "TREND_UP" ? 1 : f.state === "TREND_DOWN" ? -1 : 0;
    if (!side) return reject("TREND_ROLE_INELIGIBLE", f.state);
    const oldEma = emaRootV1(prior.map((b) => b.close), 20), touched = side === 1 ? Math.min(...h.slice(-4, -1).map((b) => b.low)) <= oldEma + 0.25 * atr2 : Math.max(...h.slice(-4, -1).map((b) => b.high)) >= oldEma - 0.25 * atr2;
    if (!touched || side * (c.close - c.open) < 0.15 * atr2 || Math.abs(c.close - f.ema) > 1.5 * atr2 || (side === 1 ? c.close <= p.high || c.close < f.ema : c.close >= p.low || c.close > f.ema)) return reject("NO_CLOSED_TREND_RECLAIM", f.state);
    stop = side === 1 ? Math.min(...h.slice(-5).map((b) => b.low)) - 0.15 * atr2 : Math.max(...h.slice(-5).map((b) => b.high)) + 0.15 * atr2;
    stop = side === 1 ? Math.min(stop, c.close - 1.5 * atr2) : Math.max(stop, c.close + 1.5 * atr2);
    target = c.close + side * 2.5 * Math.abs(c.close - stop);
    setup = "H1_PULLBACK_H4_TREND";
  } else if (id2 === "crypto.team-range") {
    if (f.state !== "RANGE") return reject("RANGE_ROLE_INELIGIBLE", f.state);
    const rsi2 = rsiRootV1(prior.map((b) => b.close), 2);
    const buy = c.low < f.low && c.close > f.low && c.close > c.open && rsi2 < 30, sell = c.high > f.high && c.close < f.high && c.close < c.open && rsi2 > 70;
    if (!buy && !sell || f.high - f.low < 4 * atr2) return reject("NO_BALANCED_RANGE_REJECTION", f.state);
    side = buy ? 1 : -1;
    stop = side === 1 ? Math.min(c.low - 0.15 * atr2, c.close - 1.25 * atr2) : Math.max(c.high + 0.15 * atr2, c.close + 1.25 * atr2);
    target = f.ema;
    setup = "H1_RANGE_SWEEP_TO_MEAN";
  } else {
    side = f.state === "EXPANSION_UP" ? 1 : f.state === "EXPANSION_DOWN" ? -1 : 0;
    if (!side) return reject("BREAKOUT_ROLE_INELIGIBLE", f.state);
    if (side * (c.close - c.open) < 0.25 * atr2 || Math.abs(c.close - c.open) > 2 * atr2) return reject("BREAKOUT_IMPULSE_OR_CHASE", f.state);
    stop = side === 1 ? Math.min(c.close - 2 * atr2, ...h.slice(-7).map((b) => b.low)) : Math.max(c.close + 2 * atr2, ...h.slice(-7).map((b) => b.high));
    target = c.close + side * 3 * Math.abs(c.close - stop);
    setup = "H1_COMPRESSION_ACCEPTANCE";
  }
  const risk = (c.close - stop) * side, rr = (target - c.close) * side / risk, costR = c.close * 25e-4 / risk;
  if (!(risk > 0 && stop > 0 && target > 0 && rr >= 1.5 && costR <= 0.25) || risk / c.close > 0.1) return reject("TEAM_COST_OR_GEOMETRY_REJECTED", f.state);
  return { status: "candidate", direction: side === 1 ? "buy" : "sell", entry_low: c.close, entry_high: c.close, stop_loss: stop, tp1: target, tp2: target, risk_reward: rr, confidence_score: 80, grade: "A", reason: setup, rejection_reason: "", score_breakdown: { team_policy: "crypto-team/v1", team_role: id2, team_state: f.state, higher_direction: f.higherDirection, efficiency: f.efficiency, estimated_cost_r: costR, estimated_cost_bps: 25, score_is_probability: false, research_only: true, source_close: context.evaluated_at } };
}
function coordinatedCryptoDefinitions(resolve) {
  let rows, at = "", features;
  return CRYPTO_TEAM_ROLES.map((role) => {
    const stored = resolve?.(role.name), released = stored?.enabled === true && stored.config_source?.startsWith("measured_release:") === true;
    return { id: role.id, version: CRYPTO_TEAM_VERSION, legacyName: role.name, market: "crypto", lifecycle: released ? "ENABLED" : "DISABLED", publicationMode: released ? "LIVE" : "SHADOW", certification: released ? "PRODUCTION" : "RESEARCH", config: released ? stored : { strategy_name: role.name, enabled: false, min_score: 75, min_rr: 1.5, max_bars_in_trade: 96, allowed_symbols: role.id === "crypto.team-alt" ? [...ALT_SYMBOLS] : [...CRYPTO_TEAM_SYMBOLS], allowed_timeframes: ["15m"], params: {} }, evaluate: (context) => {
      if (rows !== context.candles || at !== context.evaluated_at) {
        rows = context.candles;
        at = context.evaluated_at;
        features = cryptoTeamFeatures(context);
      }
      return evaluateCryptoTeam(role.id, context, features);
    } };
  });
}
function coordinatedConfiguration(selection = CRYPTO_TEAM_PROFILE) {
  const definitions = coordinatedCryptoDefinitions().filter((d) => selection === CRYPTO_TEAM_PROFILE || d.id === selection);
  if (!definitions.length) throw Error("UNKNOWN_CRYPTO_TEAM_SELECTION");
  return { researchOnly: true, version: "research/crypto-team/v1", minSignalGrade: "A", outcomeAssumptions: { ...CRYPTO_TEAM_ASSUMPTIONS }, strategies: definitions.map((d) => ({ id: d.id, version: d.version, enabled: true, minScore: 75, minRiskReward: 1.5, maxBarsInTrade: 96, symbols: [...d.config.allowed_symbols], timeframes: ["15m"], parameters: {} })) };
}

// supabase/functions/_shared/coordinated-crypto-selection.ts
var stable2 = (x) => x === null || typeof x !== "object" ? JSON.stringify(x) : Array.isArray(x) ? `[${x.map(stable2)}]` : `{${Object.entries(x).sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => `${JSON.stringify(k)}:${stable2(v)}`).join(",")}}`;
var isCryptoTeam = (configuration) => configuration.strategies.some((s) => s.enabled && CRYPTO_TEAM_ROLES.some((r) => r.id === s.id));
var needsBtcReference = (configuration) => usesAltReference(configuration) || isCryptoTeam(configuration);
var requiredReplayBars = (configuration) => isCryptoTeam(configuration) ? 960 : replayContextBars(configuration);
var referenceOnly = (configuration, symbol) => symbol === "BTCUSDT" && (usesAltReference(configuration) || configuration.strategies.every((s) => s.id === "crypto.team-alt"));
function validateCoordinatedDatasets(configuration, datasets) {
  if (!isCryptoTeam(configuration)) return validateAltDatasetSelection(configuration, datasets);
  const research = configuration.researchOnly === true;
  if (research && !CRYPTO_TEAM_PROFILE_IDS.some((id2) => stable2(coordinatedConfiguration(id2)) === stable2(configuration))) throw Error("TEAM_FROZEN_CONFIGURATION_REQUIRED");
  if (!research && configuration.strategies.some((s) => !CRYPTO_TEAM_ROLES.some((r) => r.id === s.id) || s.version !== "1.0.0" || Object.keys(s.parameters).length || s.maxBarsInTrade !== 96 || s.minScore < 75 || s.minRiskReward < 1.5 || s.timeframes.length !== 1 || s.timeframes[0] !== "15m" || !s.symbols.length)) throw Error("TEAM_APPROVED_CONFIGURATION_INVALID");
  if (!datasets.length || datasets.length > 4 || datasets.filter((d) => d.symbol === "BTCUSDT").length !== 1 || new Set(datasets.map((d) => d.symbol)).size !== datasets.length || datasets.some((d) => d.timeframe !== "15m" || (d.market_type ?? d.market) !== "crypto" || !configuration.strategies.some((s) => s.symbols.includes(d.symbol)) && d.symbol !== "BTCUSDT")) throw Error("TEAM_BTC_AND_NATIVE_15M_DATASETS_REQUIRED");
  if (datasets.every((d) => referenceOnly(configuration, d.symbol))) throw Error("TEAM_TRADABLE_DATASET_REQUIRED");
}

// supabase/functions/_shared/crypto-signal-ensemble-contract.ts
var SIGNAL_ENSEMBLE_VERSION = "1.0.0";
var SIGNAL_ENSEMBLE_ROLES = [
  { id: "crypto.sleeve-trend", name: "SignalTrendPullback", label: "Trend pullback", role: "TREND_PULLBACK" },
  { id: "crypto.sleeve-breakout", name: "SignalVolatilityBreakout", label: "Volatility breakout", role: "VOLATILITY_BREAKOUT" },
  { id: "crypto.sleeve-reversal", name: "SignalExhaustionReversal", label: "Exhaustion reversal", role: "EXHAUSTION_REVERSAL" },
  { id: "crypto.sleeve-relative", name: "SignalRelativeMomentum", label: "Relative-strength momentum", role: "RELATIVE_MOMENTUM" }
];
var SIGNAL_ENSEMBLE_SYMBOLS = Object.freeze(["BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "XRPUSDT"]);
var SIGNAL_ENSEMBLE_ASSUMPTIONS = Object.freeze({ entryTiming: "NEXT_OPEN", feeBps: 10, spreadBps: 2, slippageBps: 4, fundingBps: 9, partialExitPct: 0, moveStopToBreakevenAfterTp1: false, trailingStopR: null, sameCandlePolicy: "STOP_FIRST", maxBarsInTrade: 96, closeAtHorizon: true });

// supabase/functions/_shared/signal-ensemble-selection.ts
var isSignalEnsemble = (c) => c.strategies.some((s) => s.enabled && SIGNAL_ENSEMBLE_ROLES.some((r) => r.id === s.id));
var requiredReplayBars2 = (c) => hasDaily(c) ? c.strategies.length > 1 ? 960 : 201 : isSignalEnsemble(c) ? 960 : requiredReplayBars(c);
var needsBtcReference2 = (c) => isSignalEnsemble(c) || needsBtcReference(c);
var referenceOnly2 = (c, s, timeframe) => hasDaily(c) ? s === "BTCUSDT" && timeframe === "15m" : isSignalEnsemble(c) ? s === "BTCUSDT" && c.strategies.filter((x) => x.enabled).every((x) => x.id === "crypto.sleeve-relative") : referenceOnly(c, s);
function validateCoordinatedDatasets2(c, datasets) {
  if (hasDaily(c)) return validateDailySelection(c, datasets);
  if (!isSignalEnsemble(c)) return validateCoordinatedDatasets(c, datasets);
  if (c.strategies.some((s) => !SIGNAL_ENSEMBLE_ROLES.some((r) => r.id === s.id) || s.version !== SIGNAL_ENSEMBLE_VERSION || Object.keys(s.parameters).length || s.maxBarsInTrade !== 96 || s.minScore < 75 || s.minRiskReward < (s.id === "crypto.sleeve-reversal" ? 0.8 : 1.5) || s.timeframes.length !== 1 || s.timeframes[0] !== "15m" || !s.symbols.length || s.symbols.some((x) => !SIGNAL_ENSEMBLE_SYMBOLS.includes(x) || s.id === "crypto.sleeve-relative" && x === "BTCUSDT"))) throw Error("SIGNAL_ENSEMBLE_FROZEN_CONFIGURATION_REQUIRED");
  if (!datasets.length || datasets.length > 5 || datasets.filter((d) => d.symbol === "BTCUSDT").length !== 1 || new Set(datasets.map((d) => d.symbol)).size !== datasets.length || datasets.some((d) => d.timeframe !== "15m" || (d.market_type ?? d.market) !== "crypto" || !c.strategies.some((s) => s.enabled && s.symbols.includes(d.symbol)) && d.symbol !== "BTCUSDT") || datasets.every((d) => referenceOnly2(c, d.symbol))) throw Error("SIGNAL_ENSEMBLE_NATIVE_DATASET_SCOPE_REQUIRED");
}

// supabase/functions/_shared/crypto-signal-ensemble.ts
var WIDTH = 9e5;
var timeCache = /* @__PURE__ */ new Map();
var epoch = (s) => {
  const known = timeCache.get(s);
  if (known !== void 0) return known;
  const n = Date.parse(s);
  if (timeCache.size >= 4096) timeCache.clear();
  timeCache.set(s, n);
  return n;
};
var mean2 = (a) => a.reduce((n, x) => n + x, 0) / a.length;
var reject2 = (reason) => ({ status: "rejected", direction: "none", entry_low: 0, entry_high: 0, stop_loss: 0, tp1: 0, tp2: 0, risk_reward: 0, confidence_score: 0, grade: "reject", reason, rejection_reason: reason, score_breakdown: { signal_ensemble_policy: "crypto-signal-ensemble/v1", research_only: true, score_is_probability: false } });
function admitted(rows, symbol, at) {
  return rows.length === 960 && epoch(rows.at(-1).open_time) + WIDTH === at && rows.every((c, i) => c.symbol === symbol && c.market_type === "crypto" && c.timeframe === "15m" && c.source === "BINANCE_USDM_KLINES" && c.instrument_type === "USDT_PERPETUAL" && [c.open, c.high, c.low, c.close, c.volume, c.quote_volume].every((x) => typeof x === "number" && Number.isFinite(x)) && c.low > 0 && c.volume >= 0 && c.quote_volume >= 0 && c.low <= Math.min(c.open, c.close) && c.high >= Math.max(c.open, c.close) && epoch(c.open_time) === at - (960 - i) * WIDTH);
}
function signalSleeveFeatures(ctx) {
  const unavailable = (reason) => ({ valid: false, reason, rows: [], atr: 0, macroDirection: 0, macroStrength: 0, volumeRatio: 0, ema20: 0, previousEma20: 0, ema50: 0, mean20: 0, lowerBand: 0, upperBand: 0, priorRsi2: 50, flow: null, shock: true });
  const at = epoch(ctx.evaluated_at), r = ctx.candles;
  if (ctx.market !== "crypto" || ctx.timeframe !== "15m" || !SIGNAL_ENSEMBLE_SYMBOLS.includes(ctx.symbol) || !Number.isFinite(at) || at % WIDTH || !admitted(r, ctx.symbol, at)) return unavailable("SLEEVE_NATIVE_HISTORY_IDENTITY");
  const h4 = [];
  for (let i = 0; i < r.length; ) {
    const first = epoch(r[i].open_time);
    if (first % 144e5) {
      i++;
      continue;
    }
    if (i + 16 > r.length) break;
    const g = r.slice(i, i + 16);
    h4.push({ ...g[0], timeframe: "4h", high: Math.max(...g.map((c2) => c2.high)), low: Math.min(...g.map((c2) => c2.low)), close: g[15].close, volume: g.reduce((n, c2) => n + c2.volume, 0) });
    i += 16;
  }
  if (h4.length < 55) return unavailable("SLEEVE_CLOSED_H4_HISTORY");
  const prior = r.slice(0, -1), c = r.at(-1), atr2 = atrRootV1(prior, 14), h4Atr = atrRootV1(h4, 14), hc = h4.map((c2) => c2.close), fast = emaRootV1(hc, 8), slow = emaRootV1(hc, 21), previous = emaRootV1(hc.slice(0, -1), 8), macroDirection = fast > slow && fast > previous ? 1 : fast < slow && fast < previous ? -1 : 0, macroStrength = Math.abs(fast - slow) / h4Atr;
  if (!(atr2 > 0 && h4Atr > 0)) return unavailable("SLEEVE_ATR_REQUIRED");
  const closes = prior.slice(-20).map((c2) => c2.close), baseline = mean2(closes), sd = Math.sqrt(mean2(closes.map((x) => (x - baseline) ** 2))), averageQuote = mean2(prior.slice(-20).map((c2) => c2.quote_volume));
  if (!(averageQuote > 0 && baseline > 0)) return unavailable("SLEEVE_QUOTE_VOLUME_REQUIRED");
  const flow = typeof c.taker_buy_quote_volume === "number" && Number.isFinite(c.taker_buy_quote_volume) && c.quote_volume > 0 && c.taker_buy_quote_volume >= 0 && c.taker_buy_quote_volume <= c.quote_volume ? 2 * c.taker_buy_quote_volume / c.quote_volume - 1 : null;
  return { valid: true, reason: "", rows: r, atr: atr2, macroDirection, macroStrength, volumeRatio: c.quote_volume / averageQuote, ema20: ctx.indicators.ema20, ema50: ctx.indicators.ema50, previousEma20: emaRootV1(prior.slice(-110).map((c2) => c2.close), 20), mean20: baseline, lowerBand: baseline - 2 * sd, upperBand: baseline + 2 * sd, priorRsi2: rsiRootV1(prior.map((c2) => c2.close), 2), flow, shock: Math.max(c.high - c.low, Math.abs(c.high - prior.at(-1).close), Math.abs(c.low - prior.at(-1).close)) > 4 * atr2 || Math.abs(c.open - prior.at(-1).close) > 2 * atr2 };
}
function evaluateSignalSleeve(id2, ctx, f = signalSleeveFeatures(ctx)) {
  if (Object.keys(ctx.strategy_parameters ?? {}).length) return reject2("SLEEVE_FROZEN_PARAMETERS");
  if (!f.valid || f.shock) return reject2(f.reason || "SLEEVE_PRICE_SHOCK");
  const r = f.rows, c = r.at(-1), p = r.at(-2), atr2 = f.atr;
  let side = 0, stop = 0, target = 0, setup = "";
  if (id2 === "crypto.sleeve-trend") {
    side = f.macroStrength >= 0.35 ? f.macroDirection : 0;
    if (!side || side * (f.ema20 - f.ema50) <= 0 || side * (p.close - f.previousEma20) > 0 || side * (c.close - f.ema20) <= 0 || side * (c.close - c.open) < 0.25 * atr2 || f.volumeRatio < 1) return reject2("NO_MACRO_PULLBACK_RECLAIM");
    const touched = r.slice(-6, -1).some((b) => side === 1 ? b.low <= f.ema20 : b.high >= f.ema20);
    if (!touched) return reject2("NO_PULLBACK_TOUCH");
    stop = side === 1 ? Math.min(c.close - 2 * atr2, ...r.slice(-6).map((b) => b.low - 0.1 * atr2)) : Math.max(c.close + 2 * atr2, ...r.slice(-6).map((b) => b.high + 0.1 * atr2));
    setup = "CLOSED_H4_NATIVE_PULLBACK";
  } else if (id2 === "crypto.sleeve-breakout") {
    const prior = r.slice(-33, -1), hi = Math.max(...prior.map((b) => b.high)), lo = Math.min(...prior.map((b) => b.low)), compressed = mean2(r.slice(-9, -1).map((b) => b.high - b.low)) <= 0.9 * atr2;
    side = c.close > hi + 0.1 * atr2 ? 1 : c.close < lo - 0.1 * atr2 ? -1 : 0;
    if (!side || !compressed || f.volumeRatio < 1.5 || side * (c.close - c.open) < 0.5 * atr2 || f.macroDirection === -side && f.macroStrength >= 0.35) return reject2("NO_ACCEPTED_VOLATILITY_BREAKOUT");
    stop = side === 1 ? Math.min(c.close - 2 * atr2, ...r.slice(-9, -1).map((b) => b.low - 0.1 * atr2)) : Math.max(c.close + 2 * atr2, ...r.slice(-9, -1).map((b) => b.high + 0.1 * atr2));
    setup = "NATIVE_COMPRESSION_VOLUME_BREAK";
  } else if (id2 === "crypto.sleeve-reversal") {
    if (f.macroStrength > 0.75 || f.flow === null) return reject2("REVERSAL_REQUIRES_BALANCE_AND_FLOW");
    const buy = c.low < f.lowerBand && c.close > f.lowerBand && c.close > c.open && f.priorRsi2 < 15 && f.flow > 0, sell = c.high > f.upperBand && c.close < f.upperBand && c.close < c.open && f.priorRsi2 > 85 && f.flow < 0;
    side = buy ? 1 : sell ? -1 : 0;
    if (!side) return reject2("NO_OBSERVED_EXHAUSTION_REJECTION");
    stop = side === 1 ? Math.min(c.close - 2 * atr2, c.low - 0.1 * atr2) : Math.max(c.close + 2 * atr2, c.high + 0.1 * atr2);
    target = f.mean20;
    setup = "BALANCED_BAND_REJECTION_OBSERVED_FLOW";
  } else if (id2 === "crypto.sleeve-relative") {
    const peer = ctx.reference_candles ?? [];
    if (ctx.symbol === "BTCUSDT" || !admitted(peer, "BTCUSDT", epoch(ctx.evaluated_at))) return reject2("RELATIVE_REQUIRES_ALIGNED_BTC");
    const day = c.close / r.at(-97).close - 1, week = c.close / r.at(-673).close - 1, btc = peer.at(-1).close / peer.at(-97).close - 1, prior = r.slice(-97, -1), hi = Math.max(...prior.map((b) => b.high)), lo = Math.min(...prior.map((b) => b.low));
    side = btc > 0 && day >= 0.03 && day - btc >= 0.02 && week > 0 && c.close > hi ? 1 : btc < 0 && day <= -0.03 && day - btc <= -0.02 && week < 0 && c.close < lo ? -1 : 0;
    if (!side || f.volumeRatio < 1.5) return reject2("NO_RELATIVE_MOMENTUM_ACCEPTANCE");
    stop = side === 1 ? Math.min(c.close - 2 * atr2, lo) : Math.max(c.close + 2 * atr2, hi);
    setup = "NATIVE_RELATIVE_MOMENTUM_LONG_SHORT";
  } else return reject2("UNKNOWN_SIGNAL_SLEEVE");
  const risk = (c.close - stop) * side;
  if (!target) target = c.close + side * 3 * risk;
  const rr = (target - c.close) * side / risk, costR = c.close * 25e-4 / risk, minRR = id2 === "crypto.sleeve-reversal" ? 0.8 : 1.5;
  if (!(risk > 0 && stop > 0 && target > 0 && rr >= minRR && risk / c.close >= 8e-3 && risk / c.close <= 0.06 && costR <= 0.3125)) return reject2("SLEEVE_COST_OR_STRUCTURAL_GEOMETRY");
  return { status: "candidate", direction: side === 1 ? "buy" : "sell", entry_low: c.close, entry_high: c.close, stop_loss: stop, tp1: target, tp2: target, risk_reward: rr, confidence_score: 80, grade: "A", reason: setup, rejection_reason: "", score_breakdown: { signal_ensemble_policy: "crypto-signal-ensemble/v1", sleeve_id: id2, setup, macro_direction: f.macroDirection, macro_strength: f.macroStrength, volume_ratio: f.volumeRatio, estimated_cost_r: costR, estimated_cost_bps: 25, research_only: true, score_is_probability: false, score_meaning: "binary research setup conformance; not a forecast", source_close: ctx.evaluated_at } };
}
function signalEnsembleDefinitions() {
  let rows, at = "", features;
  return SIGNAL_ENSEMBLE_ROLES.map((role) => ({ id: role.id, version: SIGNAL_ENSEMBLE_VERSION, legacyName: role.name, market: "crypto", lifecycle: "DISABLED", publicationMode: "SHADOW", certification: "RESEARCH", config: { strategy_name: role.name, enabled: false, min_score: 75, min_rr: role.id === "crypto.sleeve-reversal" ? 0.8 : 1.5, max_bars_in_trade: 96, allowed_symbols: role.id === "crypto.sleeve-relative" ? SIGNAL_ENSEMBLE_SYMBOLS.filter((s) => s !== "BTCUSDT") : [...SIGNAL_ENSEMBLE_SYMBOLS], allowed_timeframes: ["15m"], params: {} }, evaluate: (ctx) => {
    if (rows !== ctx.candles || at !== ctx.evaluated_at) {
      rows = ctx.candles;
      at = ctx.evaluated_at;
      features = signalSleeveFeatures(ctx);
    }
    return evaluateSignalSleeve(role.id, ctx, features);
  } }));
}
function signalEnsembleMarketPolicy(entries) {
  if (!entries.length || !entries.every((e) => SIGNAL_ENSEMBLE_ROLES.some((r) => r.name === e.name))) return void 0;
  return entries.every((e) => {
    const b = e.result.score_breakdown, role = SIGNAL_ENSEMBLE_ROLES.find((r) => r.name === e.name);
    return b.signal_ensemble_policy === "crypto-signal-ensemble/v1" && b.sleeve_id === role?.id && b.score_is_probability === false && typeof b.estimated_cost_r === "number" && Number.isFinite(b.estimated_cost_r) && b.estimated_cost_r <= 0.3125 && b.estimated_cost_r >= 0;
  }) ? "" : "SIGNAL_ENSEMBLE_POLICY_MISMATCH";
}

// supabase/functions/_shared/micro-scalper-runtime.ts
function microScalperRuntimeParams(cfg, timeframe) {
  const calibrated15m = {
    min_score: 72,
    min_rr: 1.2,
    stop_atr_mult: 1.4,
    tp1_r: 1.2,
    tp2_r: 1.8,
    min_body_atr: 0.3,
    rsi_buy_min: 52,
    rsi_sell_max: 48,
    max_bars_in_trade: 24,
    momentum_lookback: 3,
    min_atr_pct: 0.1,
    max_atr_pct: 3,
    crypto_behavior_tuning: 1
  };
  const calibrated5m = {
    ...calibrated15m,
    // Keep scanner 5m aligned with the successful live-like 5m CSV/backtest
    // path unless DB explicitly provides timeframe-specific overrides.
    rsi_buy_min: calibrated15m.rsi_buy_min,
    rsi_sell_max: calibrated15m.rsi_sell_max,
    stop_atr_mult: calibrated15m.stop_atr_mult,
    max_bars_in_trade: calibrated15m.max_bars_in_trade
  };
  const calibrated = timeframe === "5m" ? calibrated5m : calibrated15m;
  const runtimeOverrides = [];
  const params = { ...calibrated, ...cfg.params };
  if (timeframe === "5m") {
    const timeframeKeys = {
      rsi_buy_min: "rsi_buy_min_5m",
      rsi_sell_max: "rsi_sell_max_5m",
      stop_atr_mult: "stop_atr_mult_5m",
      max_bars_in_trade: "max_bars_in_trade_5m"
    };
    for (const [key, tfKey] of Object.entries(timeframeKeys)) {
      const explicit = cfg.params[tfKey];
      const next = typeof explicit === "number" && Number.isFinite(explicit) ? explicit : calibrated5m[key] ?? params[key] ?? 0;
      if (params[key] !== next) runtimeOverrides.push(key);
      params[key] = next;
    }
  }
  params.min_score = cfg.min_score > 0 ? cfg.min_score : calibrated.min_score;
  params.min_rr = cfg.min_rr > 0 ? cfg.min_rr : calibrated.min_rr;
  if (cfg.max_bars_in_trade > 0 && timeframe !== "5m") params.max_bars_in_trade = cfg.max_bars_in_trade;
  if (timeframe === "5m" && cfg.params.max_bars_in_trade_5m === void 0) params.max_bars_in_trade = calibrated5m.max_bars_in_trade;
  params.crypto_behavior_tuning = 1;
  return {
    params,
    config_source: runtimeOverrides.length > 0 ? "runtime_override" : cfg.config_source === "db" ? "db" : "fallback",
    base_config_source: cfg.config_source === "db" ? "db" : "fallback",
    runtime_overrides: runtimeOverrides
  };
}

// supabase/functions/_shared/regime-opportunities.ts
var REGIME_ENGINE_VERSION = "1.0.0";
var REGIME_IDS = ["crypto.regime-continuation", "crypto.regime-range-rejection", "crypto.regime-channel-breakout"];
var reject3 = (reason, state2) => ({ status: "rejected", direction: "none", entry_low: 0, entry_high: 0, stop_loss: 0, tp1: 0, tp2: 0, risk_reward: 0, confidence_score: 0, grade: "reject", reason, rejection_reason: reason, score_breakdown: { ...state2 ? { regime: state2.regime, efficiency: state2.efficiency, trend_atr: state2.trendAtr, atr_percentile: state2.atrPercentile } : {}, score_is_probability: false } });
var ms = (tf) => {
  const m = /^(\d+)(m|h)$/.exec(tf);
  return m ? Number(m[1]) * (m[2] === "h" ? 36e5 : 6e4) : NaN;
};
function closedAggregate(rows, minutes, asOf) {
  if (!rows.length) return [];
  const base = ms(rows[0].timeframe), width2 = minutes * 6e4;
  if (!Number.isInteger(width2 / base) || width2 < base) return [];
  const groups = /* @__PURE__ */ new Map();
  for (const row of rows) {
    const t = Date.parse(row.open_time);
    if (t + base > Date.parse(asOf)) continue;
    const start = Math.floor(t / width2) * width2;
    const g = groups.get(start) ?? [];
    g.push(row);
    groups.set(start, g);
  }
  return [...groups].sort((a, b) => a[0] - b[0]).flatMap(([t, g]) => t + width2 <= Date.parse(asOf) && g.length === width2 / base && g.every((r, i) => Date.parse(r.open_time) === t + i * base) ? [{ ...g[0], timeframe: minutes % 60 === 0 ? `${minutes / 60}h` : `${minutes}m`, open_time: new Date(t).toISOString(), high: Math.max(...g.map((r) => r.high)), low: Math.min(...g.map((r) => r.low)), close: g.at(-1).close, volume: g.reduce((n, r) => n + r.volume, 0) }] : []);
}
function classifyOpportunity(context) {
  const blank = { regime: "UNAVAILABLE", atr: 0, efficiency: 0, trendAtr: 0, atrPercentile: 0, htfDirection: 0, reason: "WARMUP_OR_DATA_UNAVAILABLE" };
  const rows = context.candles, at = Date.parse(context.evaluated_at), width2 = ms(context.timeframe);
  if (context.market !== "crypto" || !["1h", "4h"].includes(context.timeframe) || rows.length < 100 || !Number.isFinite(at)) return blank;
  if (rows.some((r, i) => r.symbol !== context.symbol || r.timeframe !== context.timeframe || ![r.open, r.high, r.low, r.close, r.volume].every(Number.isFinite) || r.low <= 0 || r.volume < 0 || r.low > Math.min(r.open, r.close) || r.high < Math.max(r.open, r.close) || Date.parse(r.open_time) + width2 > at || i > 0 && Date.parse(r.open_time) - Date.parse(rows[i - 1].open_time) !== width2)) return { ...blank, reason: "INVALID_OR_GAPPED_DATA" };
  if (at - (Date.parse(rows.at(-1).open_time) + width2) > width2) return { ...blank, reason: "STALE_DATA" };
  const closes = rows.map((r) => r.close), atr2 = atrRootV1([...rows], 14);
  if (!(atr2 > 0)) return blank;
  const path = closes.slice(-21), travel = path.slice(1).reduce((n, x, i) => n + Math.abs(x - path[i]), 0), efficiency = travel ? Math.abs(path.at(-1) - path[0]) / travel : 0;
  const ema20 = emaRootV1(closes, 20), ema50 = emaRootV1(closes, 50), trendAtr = (ema20 - ema50) / atr2;
  const history = rows.slice(-80, -1).map((_, i) => atrRootV1(rows.slice(Math.max(0, rows.length - 80 + i - 20), rows.length - 80 + i + 1), 14)).filter((x) => x > 0);
  const atrPercentile = history.filter((x) => x <= atr2).length / Math.max(history.length, 1), higher = closedAggregate(rows, context.timeframe === "4h" ? 720 : 240, context.evaluated_at), hc = higher.map((r) => r.close);
  if (higher.length < 24) return { ...blank, reason: "CLOSED_HIGHER_TIMEFRAME_UNAVAILABLE" };
  const fast = emaRootV1(hc, 8), slow = emaRootV1(hc, 20), oldFast = emaRootV1(hc.slice(0, -2), 8), htfDirection = fast > slow && fast > oldFast ? 1 : fast < slow && fast < oldFast ? -1 : 0;
  const last = rows.at(-1), previous = rows.at(-2), trueRange2 = Math.max(last.high - last.low, Math.abs(last.high - previous.close), Math.abs(last.low - previous.close));
  let regime = "TRANSITION";
  if (trueRange2 / atr2 > 3 || Math.abs(last.open - previous.close) / atr2 > 1 || atrPercentile > 0.98) regime = "SHOCK";
  else if (priorExpansion(rows, atr2, htfDirection) === 1) regime = "EXPANSION_UP";
  else if (priorExpansion(rows, atr2, htfDirection) === -1) regime = "EXPANSION_DOWN";
  else if (trendAtr > 0.5 && efficiency > 0.25 && htfDirection === 1) regime = "TREND_UP";
  else if (trendAtr < -0.5 && efficiency > 0.25 && htfDirection === -1) regime = "TREND_DOWN";
  else if (Math.abs(trendAtr) < 0.6 && efficiency < 0.25 && Math.abs(fast - slow) / atr2 < 1.2) regime = "RANGE";
  return { regime, atr: atr2, efficiency, trendAtr, atrPercentile, htfDirection, reason: regime };
}
function priorExpansion(rows, atr2, htf) {
  const last = rows.at(-1), prior = rows.slice(-21, -1), compressed = prior.slice(-6).reduce((n, r) => n + r.high - r.low, 0) / 6 < atr2 * 0.9, volume = prior.reduce((n, r) => n + r.volume, 0) / prior.length;
  if (!compressed || last.volume < volume * 1.2) return 0;
  return last.close > Math.max(...prior.map((r) => r.high)) && htf >= 0 ? 1 : last.close < Math.min(...prior.map((r) => r.low)) && htf <= 0 ? -1 : 0;
}
var REGIME_DEFAULTS = Object.freeze({ stopAtr: 1.8, targetR: 2.5, tp1R: 1.5, minimumStopBps: 50, maximumStopBps: 400, estimatedCostBps: 20.5, maximumCostR: 0.3, channelBars: 20, pullbackAtr: 0.6, rangeRsi: 35 });
function evaluateRegimeOpportunity(id2, context, overrides = {}) {
  const state2 = classifyOpportunity(context);
  if (state2.regime === "UNAVAILABLE" || state2.regime === "SHOCK" || state2.regime === "TRANSITION") return reject3(state2.reason, state2);
  const p = { ...REGIME_DEFAULTS, ...overrides };
  if (Object.keys(overrides).some((k) => !(k in REGIME_DEFAULTS)) || !Object.values(p).every((x) => Number.isFinite(x) && x > 0) || p.tp1R >= p.targetR || p.channelBars < 10 || p.channelBars > 60) return reject3("INVALID_PARAMETERS", state2);
  const rows = context.candles, last = rows.at(-1), prev = rows.at(-2), prior = rows.slice(-p.channelBars - 1, -1), atr2 = state2.atr, closes = rows.map((r) => r.close), ema2 = emaRootV1(closes, 20), high = Math.max(...prior.map((r) => r.high)), low = Math.min(...prior.map((r) => r.low));
  let direction = 0, setup = "";
  if (id2 === REGIME_IDS[2]) {
    if (context.timeframe !== "4h") return reject3("CHANNEL_REQUIRES_FOUR_HOUR_BARS", state2);
    if (state2.regime === "RANGE") return reject3("CHANNEL_REQUIRES_TREND_OR_EXPANSION", state2);
    const boundary = rows.slice(-56, -1), buy = last.close > Math.max(...boundary.map((r) => r.high)) && state2.htfDirection >= 0 && state2.trendAtr > 0, sell = last.close < Math.min(...boundary.map((r) => r.low)) && state2.htfDirection <= 0 && state2.trendAtr < 0;
    if (!buy && !sell) return reject3("NO_ACCEPTED_CHANNEL_BREAKOUT", state2);
    direction = buy ? 1 : -1;
    setup = "FOUR_HOUR_CHANNEL_BREAKOUT";
    if (direction * (last.close - last.open) / atr2 < 0.1 || Math.abs(last.close - last.open) / atr2 > 2.2) return reject3("IMPULSE_OR_EXTENSION_INVALID", state2);
  } else if (id2 === REGIME_IDS[0]) {
    direction = ["TREND_UP", "EXPANSION_UP"].includes(state2.regime) ? 1 : ["TREND_DOWN", "EXPANSION_DOWN"].includes(state2.regime) ? -1 : 0;
    if (!direction) return reject3("CONTINUATION_REQUIRES_TREND", state2);
    const impulse = direction * (last.close - last.open), body = impulse / atr2;
    const pullback = direction === 1 ? Math.min(...rows.slice(-4, -1).map((r) => r.low)) <= ema2 + atr2 * p.pullbackAtr && last.close > prev.high && last.close > ema2 : Math.max(...rows.slice(-4, -1).map((r) => r.high)) >= ema2 - atr2 * p.pullbackAtr && last.close < prev.low && last.close < ema2;
    const ranges = prior.slice(-6).map((r) => r.high - r.low), compressed = ranges.reduce((n, x) => n + x, 0) / ranges.length < atr2 * 0.9;
    const breakout = compressed && (direction === 1 ? last.close > high : last.close < low) && last.volume >= prior.reduce((n, r) => n + r.volume, 0) / prior.length;
    if (body < 0.2 || body > 1.5 || Math.abs(last.close - ema2) / atr2 > 2.5) return reject3("IMPULSE_OR_EXTENSION_INVALID", state2);
    if (!pullback && !breakout) return reject3("NO_PULLBACK_OR_ACCEPTED_BREAKOUT", state2);
    setup = breakout ? "COMPRESSION_EXPANSION" : "TREND_PULLBACK";
  } else {
    if (state2.regime !== "RANGE") return reject3("RANGE_REQUIRES_BALANCE", state2);
    const range = high - low, rsi2 = rsiRootV1(closes.slice(0, -1), 2), body = last.close - last.open;
    const buy = (prev.low <= low + atr2 * 0.2 || last.low <= low + atr2 * 0.1) && last.close > low + atr2 * 0.15 && last.close > prev.close && body > 0 && rsi2 < p.rangeRsi;
    const sell = (prev.high >= high - atr2 * 0.2 || last.high >= high - atr2 * 0.1) && last.close < high - atr2 * 0.15 && last.close < prev.close && body < 0 && rsi2 > 100 - p.rangeRsi;
    if (range < atr2 * 3 || !buy && !sell) return reject3("NO_RANGE_EDGE_REJECTION", state2);
    direction = buy ? 1 : -1;
    setup = "RANGE_EDGE_REJECTION";
  }
  const entry = last.close, structure = direction === 1 ? Math.min(...rows.slice(-5).map((r) => r.low)) - atr2 * 0.15 : Math.max(...rows.slice(-5).map((r) => r.high)) + atr2 * 0.15;
  const risk = Math.max(Math.abs(entry - structure), atr2 * p.stopAtr, entry * p.minimumStopBps / 1e4), stop = entry - direction * risk, costR = entry * p.estimatedCostBps / 1e4 / risk;
  if (risk / entry * 1e4 > p.maximumStopBps || costR > p.maximumCostR) return reject3("COST_OR_STOP_INFEASIBLE", state2);
  let target = entry + direction * risk * p.targetR;
  if (id2 === REGIME_IDS[1]) {
    const opposite = direction === 1 ? high - atr2 * 0.2 : low + atr2 * 0.2;
    if ((opposite - entry) * direction / risk < 1.8) return reject3("RANGE_REWARD_TOO_SMALL", state2);
    target = direction === 1 ? Math.min(target, opposite) : Math.max(target, opposite);
  }
  const rr = (target - entry) * direction / risk, tp1 = entry + direction * risk * Math.min(p.tp1R, rr * 0.6);
  return { status: "candidate", direction: direction === 1 ? "buy" : "sell", entry_low: entry, entry_high: entry, stop_loss: stop, tp1, tp2: target, risk_reward: rr, confidence_score: 80, grade: "A", reason: setup, rejection_reason: "", score_breakdown: { strategy: id2, regime: state2.regime, regime_policy_version: "regime-opportunity/v1", setup, efficiency: state2.efficiency, trend_atr: state2.trendAtr, atr_percentile: state2.atrPercentile, higher_timeframe_direction: state2.htfDirection, estimated_cost_r: costR, score_is_probability: false, measured_release_required: true, management: "STATIC_PROTECTIVE_STOP" } };
}
function regimeResearchDefinitions() {
  return REGIME_IDS.map((id2) => ({ id: id2, version: REGIME_ENGINE_VERSION, legacyName: id2 === REGIME_IDS[0] ? "RegimeContinuation" : id2 === REGIME_IDS[1] ? "RegimeRangeRejection" : "RegimeChannelBreakout", market: "crypto", lifecycle: "DISABLED", publicationMode: "SHADOW", certification: "RESEARCH", config: { strategy_name: id2, enabled: false, min_score: 75, min_rr: 1.5, max_bars_in_trade: 48, allowed_symbols: ["BTCUSDT", "ETHUSDT"], allowed_timeframes: [id2 === REGIME_IDS[2] ? "4h" : "1h"], params: { ...REGIME_DEFAULTS, ...id2 === REGIME_IDS[2] ? { stopAtr: 2, channelBars: 55, targetR: 3, minimumStopBps: 100, maximumStopBps: 600, estimatedCostBps: 40 } : {} } }, evaluate: (context) => evaluateRegimeOpportunity(id2, context, context.strategy_parameters ?? (id2 === REGIME_IDS[2] ? { stopAtr: 2, channelBars: 55, targetR: 3, minimumStopBps: 100, maximumStopBps: 600, estimatedCostBps: 40 } : {})) }));
}

// supabase/functions/_shared/intraday-opportunities.ts
var INTRADAY_VERSION = "1.0.0";
var INTRADAY_IDS = ["crypto.vwap-reclaim-15m", "crypto.failed-auction-15m"];
var INTRADAY_DEFAULTS = Object.freeze({
  stopAtr: 1.8,
  minimumStopBps: 60,
  maximumStopBps: 350,
  targetR: 2.5,
  tp1R: 1.5,
  estimatedCostBps: 20.5,
  maximumCostR: 0.3
});
var rejected2 = (reason) => ({
  status: "rejected",
  direction: "none",
  entry_low: 0,
  entry_high: 0,
  stop_loss: 0,
  tp1: 0,
  tp2: 0,
  risk_reward: 0,
  confidence_score: 0,
  grade: "reject",
  reason,
  rejection_reason: reason,
  score_breakdown: { score_is_probability: false, measured_release_required: true }
});
function evaluateIntradayOpportunity(id2, context, overrides = {}) {
  if (!INTRADAY_IDS.includes(id2)) return rejected2("UNKNOWN_INTRADAY_STRATEGY");
  const p = { ...INTRADAY_DEFAULTS, ...overrides };
  if (Object.keys(overrides).some((k) => !(k in INTRADAY_DEFAULTS)) || !Object.values(p).every((x) => Number.isFinite(x) && x > 0) || p.tp1R >= p.targetR || p.minimumStopBps >= p.maximumStopBps) return rejected2("INVALID_PARAMETERS");
  const rows = context.candles, at = Date.parse(context.evaluated_at), width2 = 9e5;
  if (context.market !== "crypto" || context.timeframe !== "15m" || rows.length < 110 || !Number.isFinite(at))
    return rejected2("REQUIRES_110_CLOSED_CRYPTO_15M_BARS");
  if (rows.some((r, i) => r.symbol !== context.symbol || r.timeframe !== "15m" || ![r.open, r.high, r.low, r.close, r.volume].every(Number.isFinite) || r.low <= 0 || r.volume < 0 || r.high < Math.max(r.open, r.close) || r.low > Math.min(r.open, r.close) || !Number.isFinite(Date.parse(r.open_time)) || Date.parse(r.open_time) % width2 !== 0 || Date.parse(r.open_time) + width2 > at || i > 0 && Date.parse(r.open_time) - Date.parse(rows[i - 1].open_time) !== width2))
    return rejected2("INVALID_OPEN_OR_GAPPED_DATA");
  if (at - Date.parse(rows.at(-1).open_time) - width2 >= width2) return rejected2("STALE_DATA");
  const last = rows.at(-1), previous = rows.at(-2), prior = rows.slice(0, -1);
  const atr2 = atrRootV1([...prior], 14);
  if (!(atr2 > 0) || Math.max(
    last.high - last.low,
    Math.abs(last.high - previous.close),
    Math.abs(last.low - previous.close)
  ) > 3 * atr2 || Math.abs(last.open - previous.close) > atr2)
    return rejected2("SHOCK_OR_INVALID_VOLATILITY");
  const higher = closedAggregate(rows, 60, context.evaluated_at), closes = higher.map((r) => r.close);
  if (higher.length < 24) return rejected2("CLOSED_HOURLY_CONTEXT_MISSING");
  const fast = emaRootV1(closes, 8), slow = emaRootV1(closes, 20), old = emaRootV1(closes.slice(0, -1), 8);
  const direction = fast > slow && fast > old ? 1 : fast < slow && fast < old ? -1 : 0;
  const path = rows.slice(-17, -1).map((r) => r.close);
  const travel = path.slice(1).reduce((n, x, i) => n + Math.abs(x - path[i]), 0);
  const efficiency = travel ? Math.abs(path.at(-1) - path[0]) / travel : 0;
  const range = prior.slice(-24), high = Math.max(...range.map((r) => r.high)), low = Math.min(...range.map((r) => r.low));
  const volume = range.reduce((n, r) => n + r.volume, 0);
  if (!(volume > 0)) return rejected2("VOLUME_UNAVAILABLE");
  const vwap = range.reduce((n, r) => n + (r.high + r.low + r.close) / 3 * r.volume, 0) / volume;
  let side = 0, setup = "", targetBoundary = null;
  if (id2 === INTRADAY_IDS[0]) {
    if (!direction || efficiency < 0.2 || Math.abs(fast - slow) / atr2 < 0.4)
      return rejected2("RECLAIM_REQUIRES_HOURLY_TREND");
    const touched = direction === 1 ? previous.low <= vwap && previous.close <= vwap : previous.high >= vwap && previous.close >= vwap;
    const reclaimed = direction === 1 ? last.close > vwap && last.close > previous.high : last.close < vwap && last.close < previous.low;
    if (!touched || !reclaimed || direction * (last.close - last.open) < 0.15 * atr2 || Math.abs(last.close - vwap) > 1.5 * atr2) return rejected2("NO_ACCEPTED_VWAP_RECLAIM");
    side = direction;
    setup = "CLOSED_HOURLY_TREND_VWAP_RECLAIM";
  } else {
    if (efficiency > 0.3 || Math.abs(fast - slow) / atr2 > 1.2 || high - low < 4 * atr2)
      return rejected2("FAILED_AUCTION_REQUIRES_BALANCE");
    const buy = last.low < low - 0.1 * atr2 && last.close > low + 0.1 * atr2 && last.close > last.open;
    const sell = last.high > high + 0.1 * atr2 && last.close < high - 0.1 * atr2 && last.close < last.open;
    if (buy === sell || last.volume < volume / range.length) return rejected2("NO_FAILED_AUCTION");
    side = buy ? 1 : -1;
    setup = "PRIOR_RANGE_SWEEP_AND_REJECTION";
    targetBoundary = (high + low) / 2;
  }
  const entry = last.close, structural = side === 1 ? Math.min(...rows.slice(-3).map((r) => r.low)) - 0.15 * atr2 : Math.max(...rows.slice(-3).map((r) => r.high)) + 0.15 * atr2;
  const risk = Math.max((entry - structural) * side, atr2 * p.stopAtr, entry * p.minimumStopBps / 1e4);
  if (risk / entry * 1e4 > p.maximumStopBps || entry * p.estimatedCostBps / 1e4 / risk > p.maximumCostR)
    return rejected2("COST_OR_STOP_INFEASIBLE");
  const reward = targetBoundary === null ? risk * p.targetR : Math.min(risk * p.targetR, (targetBoundary - entry) * side);
  if (reward / risk < 1.5) return rejected2("INSUFFICIENT_STRUCTURAL_REWARD");
  const tp1 = entry + side * Math.min(risk * p.tp1R, reward * 0.6), tp2 = entry + side * reward;
  return {
    status: "candidate",
    direction: side === 1 ? "buy" : "sell",
    entry_low: entry,
    entry_high: entry,
    stop_loss: entry - side * risk,
    tp1,
    tp2,
    risk_reward: reward / risk,
    confidence_score: 80,
    grade: "A",
    reason: setup,
    rejection_reason: "",
    score_breakdown: {
      setup,
      hourly_direction: direction,
      efficiency,
      rolling_vwap: vwap,
      estimated_cost_r: entry * p.estimatedCostBps / 1e4 / risk,
      intraday_policy_version: "intraday-opportunity/v1",
      hourly_trend_atr: Math.abs(fast - slow) / atr2,
      score_is_probability: false,
      measured_release_required: true,
      order_flow_observed: false
    }
  };
}
function intradayResearchDefinitions() {
  return INTRADAY_IDS.map((id2) => ({
    id: id2,
    version: INTRADAY_VERSION,
    legacyName: id2,
    market: "crypto",
    lifecycle: "DISABLED",
    publicationMode: "SHADOW",
    certification: "RESEARCH",
    config: {
      strategy_name: id2,
      enabled: false,
      min_score: 75,
      min_rr: 1.5,
      max_bars_in_trade: 48,
      allowed_symbols: ["BTCUSDT", "ETHUSDT"],
      allowed_timeframes: ["15m"],
      params: { ...INTRADAY_DEFAULTS }
    },
    evaluate: (context) => evaluateIntradayOpportunity(id2, context, context.strategy_parameters)
  }));
}

// supabase/functions/_shared/cost-aware-opportunities.ts
var COST_AWARE_IDS = ["crypto.cost-aware-15m", "forex.cost-aware-hourly"];
var COST_AWARE_VERSION = "1.0.0";
var BASE_FEATURES = [
  "return1_atr",
  "return4_atr",
  "return16_atr",
  "return64_atr",
  "ema_spread_atr",
  "distance_ema_atr",
  "rsi_centered",
  "body_atr",
  "range_atr",
  "close_location",
  "log_relative_volume",
  "atr_fraction",
  "efficiency16",
  "clock_sin",
  "clock_cos",
  "weekday_sin",
  "weekday_cos",
  "estimated_cost_r",
  "trend_volume_interaction"
];
var FLOW_FEATURES = ["taker_imbalance", "taker_imbalance4", "flow_return_interaction"];
var reject4 = (reason) => ({
  status: "rejected",
  direction: "none",
  entry_low: 0,
  entry_high: 0,
  stop_loss: 0,
  tp1: 0,
  tp2: 0,
  risk_reward: 0,
  confidence_score: 0,
  grade: "reject",
  reason,
  rejection_reason: reason,
  score_breakdown: { score_is_probability: false, measured_release_required: true }
});
var forexClock = new Intl.DateTimeFormat("en-US", { timeZone: "America/New_York", weekday: "short", hour: "2-digit", hourCycle: "h23" });
function closedWeekend(t) {
  const parts = forexClock.formatToParts(new Date(t)), day = parts.find((p) => p.type === "weekday")?.value, hour = Number(parts.find((p) => p.type === "hour")?.value);
  return day === "Sat" || day === "Sun" && hour < 17 || day === "Fri" && hour >= 17;
}
function costAwareFeatures(context, costsBps, stopAtr = 2) {
  const rows = context.candles, crypto = context.market === "crypto", width2 = crypto ? 9e5 : 36e5, at = Date.parse(context.evaluated_at);
  if (context.timeframe !== (crypto ? "15m" : "1h") || rows.length < 110 || !Number.isFinite(at) || !Number.isFinite(costsBps) || costsBps < 0 || !Number.isFinite(stopAtr) || stopAtr <= 0) throw Error("MODEL_CONTEXT_INVALID");
  for (let i = 0; i < rows.length; i++) {
    const r = rows[i], t = Date.parse(r.open_time);
    if (r.symbol !== context.symbol || r.market_type !== context.market || r.timeframe !== context.timeframe || ![r.open, r.high, r.low, r.close, r.volume, t].every(Number.isFinite) || t % width2 || t + width2 > at || r.low <= 0 || r.volume < 0 || r.high < Math.max(r.open, r.close) || r.low > Math.min(r.open, r.close)) throw Error("MODEL_CANDLES_INVALID");
    if (i) {
      const previous = Date.parse(rows[i - 1].open_time), gap = t - previous;
      if (gap <= 0 || gap % width2 || gap > 72 * 36e5) throw Error("MODEL_CANDLE_GAP");
      for (let missing = previous + width2; missing < t; missing += width2) if (crypto || !closedWeekend(missing)) throw Error("MODEL_CANDLE_GAP");
    }
  }
  const last = rows.at(-1), time = Date.parse(last.open_time);
  if (at - time - width2 >= width2) throw Error("MODEL_CANDLES_STALE");
  const atr2 = atrRootV1([...rows.slice(0, -1)], 14), closes = rows.map((r) => r.close);
  if (!(atr2 > 0) || last.high - last.low > 3 * atr2 || Math.abs(last.open - rows.at(-2).close) > atr2) throw Error("MODEL_SHOCK_OR_VOLATILITY_INVALID");
  if (!crypto && (!Number.isFinite(last.ask_close) || last.ask_close < last.close || !rows.slice(-4).every((r) => r.source === "DUKASCOPY_BROKER_BID_ASK" || r.source.startsWith("mt5_hashibridge:")))) throw Error("NATIVE_BROKER_QUOTE_EVIDENCE_REQUIRED");
  const spreadBps = crypto ? 0 : (last.ask_close - last.close) / last.close * 1e4;
  const risk = atr2 * stopAtr, costR = last.close * (costsBps + spreadBps) / 1e4 / risk, averageVolume = rows.slice(-25, -1).reduce((n, r) => n + r.volume, 0) / 24;
  if (!(averageVolume > 0) || !(last.volume > 0) || risk >= last.close) throw Error("MODEL_VOLUME_OR_GEOMETRY_INVALID");
  const fast = emaRootV1(closes, 20), slow = emaRootV1(closes, 50), range = last.high - last.low, path = closes.slice(-17), travel = path.slice(1).reduce((n, x, i) => n + Math.abs(x - path[i]), 0);
  const stamp = new Date(time), clock = (stamp.getUTCHours() + stamp.getUTCMinutes() / 60) / 24 * 2 * Math.PI, day = stamp.getUTCDay() / 7 * 2 * Math.PI;
  const values = [1, 4, 16, 64].map((lag) => (last.close - closes.at(-1 - lag)) / atr2);
  values.push(
    (fast - slow) / atr2,
    (last.close - fast) / atr2,
    (rsiRootV1(closes, 14) - 50) / 50,
    (last.close - last.open) / atr2,
    range / atr2,
    range ? (last.close - last.low) / range : 0.5,
    Math.log(Math.max(last.volume / averageVolume, 1e-9)),
    atr2 / last.close,
    travel ? Math.abs(path.at(-1) - path[0]) / travel : 0,
    Math.sin(clock),
    Math.cos(clock),
    Math.sin(day),
    Math.cos(day),
    costR,
    (fast - slow) / atr2 * Math.log(Math.max(last.volume / averageVolume, 1e-9))
  );
  if (crypto) {
    const observed = rows.slice(-4);
    if (observed.some((r) => r.instrument_type !== "USDT_PERPETUAL" || !["BINANCE_USDM_KLINES", "BINANCE_UM_FUTURES_ARCHIVE"].includes(r.source) || !Number.isFinite(r.taker_buy_volume) || r.taker_buy_volume < 0 || r.taker_buy_volume > r.volume || !(r.volume > 0))) throw Error("NATIVE_FUTURES_FLOW_REQUIRED");
    const imbalance = (r) => 2 * r.taker_buy_volume / r.volume - 1, flow = imbalance(last), four = observed.reduce((n, r) => n + r.taker_buy_volume, 0) / observed.reduce((n, r) => n + r.volume, 0) * 2 - 1;
    values.push(flow, four, flow * values[0]);
  }
  if (!values.every(Number.isFinite)) throw Error("MODEL_FEATURE_NONFINITE");
  return { values, names: crypto ? [...BASE_FEATURES, ...FLOW_FEATURES] : [...BASE_FEATURES], atr: atr2, risk, costR };
}
function predictUtility(values, p) {
  if (![1, 2].includes(p.model_schema) || p.feature_count !== values.length) throw Error("MODEL_SCHEMA_MISMATCH");
  const heads = [p.long_intercept, p.short_intercept];
  if (!heads.every(Number.isFinite)) throw Error("MODEL_COEFFICIENTS_MISSING");
  const normalized = [];
  values.forEach((x, i) => {
    const mean3 = p[`mean_${i}`], scale = p[`scale_${i}`], long = p[`long_${i}`], short = p[`short_${i}`];
    if (![x, mean3, scale].every(Number.isFinite) || scale <= 0 || p.model_schema === 1 && ![long, short].every(Number.isFinite)) throw Error("MODEL_COEFFICIENTS_INVALID");
    const z = Math.max(-5, Math.min(5, (x - mean3) / scale));
    normalized.push(Math.fround(z));
    if (p.model_schema === 1) {
      heads[0] += z * long;
      heads[1] += z * short;
    }
  });
  if (p.model_schema === 2) {
    if (!Number.isSafeInteger(p.tree_count) || p.tree_count < 1 || p.tree_count > 100 || !Number.isFinite(p.learning_rate) || p.learning_rate <= 0 || p.learning_rate > 0.1) throw Error("MODEL_TREE_BOUNDS_INVALID");
    for (let head = 0; head < 2; head++) for (let tree = 0; tree < p.tree_count; tree++) {
      const prefix = `h${head}t${tree}`, count = p[`${prefix}_count`];
      let node = 0, leaf = false;
      if (!Number.isSafeInteger(count) || count < 1 || count > 7) throw Error("MODEL_TREE_SIZE_INVALID");
      for (let depth = 0; depth < 4; depth++) {
        const key = `${prefix}n${node}`, feature = p[`${key}f`];
        if (feature === -2) {
          const v = p[`${key}v`];
          if (!Number.isFinite(v)) throw Error("MODEL_LEAF_INVALID");
          heads[head] += p.learning_rate * v;
          leaf = true;
          break;
        }
        const threshold = p[`${key}b`], left = p[`${key}l`], right = p[`${key}r`];
        if (!Number.isSafeInteger(feature) || feature < 0 || feature >= values.length || !Number.isFinite(threshold) || ![left, right].every((x) => Number.isSafeInteger(x) && x >= 0 && x < count)) throw Error("MODEL_TREE_NODE_INVALID");
        node = normalized[feature] <= threshold ? left : right;
      }
      if (!leaf) throw Error("MODEL_TREE_CYCLE_OR_DEPTH_INVALID");
    }
  }
  if (!heads.every(Number.isFinite)) throw Error("MODEL_FORECAST_NONFINITE");
  return { longNetR: heads[0], shortNetR: heads[1] };
}
function evaluateCostAware(context, p = {}) {
  try {
    const at = Date.parse(context.evaluated_at);
    if (![1, 2].includes(p.model_schema) || p.trained_through_ms >= p.valid_from_ms || !Number.isFinite(p.trained_through_ms) || !Number.isFinite(p.valid_from_ms) || !Number.isFinite(p.valid_until_ms) || p.valid_until_ms <= p.valid_from_ms || at < p.valid_from_ms || at >= p.valid_until_ms || p.publication_approved !== 0) throw Error("RESEARCH_MODEL_MISSING_EXPIRED_OR_UNSAFE");
    if (p.minimum_predicted_net_r < 0.15 || !Number.isFinite(p.minimum_predicted_net_r) || p.stop_atr !== 2 || p.max_bars !== 32 || p.target_r !== 2.5 || p.tp1_r !== 1) throw Error("MODEL_POLICY_MISMATCH");
    const features = costAwareFeatures(context, p.estimated_cost_bps, p.stop_atr), prediction = predictUtility(features.values, p);
    const side = prediction.longNetR >= prediction.shortNetR ? 1 : -1, net = side === 1 ? prediction.longNetR : prediction.shortNetR;
    if (net < p.minimum_predicted_net_r) return reject4("PREDICTED_NET_EDGE_INSUFFICIENT");
    const entry = context.candles.at(-1).close;
    return {
      status: "candidate",
      direction: side === 1 ? "buy" : "sell",
      entry_low: entry,
      entry_high: entry,
      stop_loss: entry - side * features.risk,
      tp1: entry + side * features.risk * p.tp1_r,
      tp2: entry + side * features.risk * p.target_r,
      risk_reward: p.target_r,
      confidence_score: 80,
      grade: "A",
      reason: "COST_AWARE_WALK_FORWARD_UTILITY",
      rejection_reason: "",
      score_breakdown: {
        forecast_net_r: net,
        estimated_cost_r: features.costR,
        model_trained_through: p.trained_through_ms,
        model_valid_until: p.valid_until_ms,
        cost_aware_policy_version: "cost-aware-opportunity/v1",
        score_is_probability: false,
        forecast_is_guarantee: false,
        measured_release_required: true
      }
    };
  } catch (e) {
    return reject4(e instanceof Error ? e.message : "MODEL_FAILURE");
  }
}
function costAwareResearchDefinitions() {
  return COST_AWARE_IDS.map((id2, index) => ({
    id: id2,
    version: COST_AWARE_VERSION,
    legacyName: id2,
    market: index === 0 ? "crypto" : "forex",
    lifecycle: "DISABLED",
    publicationMode: "SHADOW",
    certification: "RESEARCH",
    config: { strategy_name: id2, enabled: false, min_score: 75, min_rr: 1.5, max_bars_in_trade: 32, allowed_symbols: index === 0 ? ["BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "XRPUSDT"] : ["EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCAD"], allowed_timeframes: [index === 0 ? "15m" : "1h"], params: {} },
    evaluate: (context) => evaluateCostAware(context, context.strategy_parameters)
  }));
}

// supabase/functions/_shared/forex-runtime-contracts.ts
var FOREX_RUNTIME_INSTRUMENTS = [
  { symbol: "EURUSD", instrument_class: "fx_non_jpy", market: "forex", pip_size: 1e-4, point_size: 1e-5, price_precision: 5, rounding_precision: 5, provider_symbol: "EURUSD", runtime_enabled: true },
  { symbol: "GBPUSD", instrument_class: "fx_non_jpy", market: "forex", pip_size: 1e-4, point_size: 1e-5, price_precision: 5, rounding_precision: 5, provider_symbol: "GBPUSD", runtime_enabled: true },
  { symbol: "USDJPY", instrument_class: "fx_jpy", market: "forex", pip_size: 0.01, point_size: 1e-3, price_precision: 3, rounding_precision: 3, provider_symbol: "USDJPY", runtime_enabled: true },
  { symbol: "AUDUSD", instrument_class: "fx_non_jpy", market: "forex", pip_size: 1e-4, point_size: 1e-5, price_precision: 5, rounding_precision: 5, provider_symbol: "AUDUSD", runtime_enabled: true },
  { symbol: "USDCAD", instrument_class: "fx_non_jpy", market: "forex", pip_size: 1e-4, point_size: 1e-5, price_precision: 5, rounding_precision: 5, provider_symbol: "USDCAD", runtime_enabled: true },
  { symbol: "XAUUSD", instrument_class: "metal_gold", market: "gold", pip_size: 0.1, point_size: 0.01, price_precision: 2, rounding_precision: 2, provider_symbol: "XAUUSD", runtime_enabled: true }
];
var FOREX_RUNTIME_SYMBOLS = FOREX_RUNTIME_INSTRUMENTS.map((instrument2) => instrument2.symbol);
var FX_CLASSES = ["fx_non_jpy", "fx_jpy"];
var FX_STRATEGY_SYMBOLS = FOREX_RUNTIME_INSTRUMENTS.filter((instrument2) => FX_CLASSES.includes(instrument2.instrument_class)).map((instrument2) => instrument2.symbol);
var BASE_INDICATORS = ["ema20", "ema50", "atr14", "rsi14", "recent_high", "recent_low", "body_size", "atr_pct", "momentum_score", "volatility_state", "regime"];
var FOREX_STRATEGY_CONTRACTS = [
  { id: "forex.micro-scalper", legacyName: "ForexMicroScalper", version: "1.0.0", lifecycle: "ENABLED", markets: ["forex"], eligibleInstrumentClasses: FX_CLASSES, symbols: FX_STRATEGY_SYMBOLS, primaryTimeframes: ["15m"], contextTimeframes: [], minimumCandles: 55, requiredIndicators: BASE_INDICATORS },
  { id: "forex.swing-continuation", legacyName: "ForexSwingContinuation", version: "1.0.0", lifecycle: "ENABLED", markets: ["forex"], eligibleInstrumentClasses: FX_CLASSES, symbols: FX_STRATEGY_SYMBOLS, primaryTimeframes: ["1h"], contextTimeframes: [], minimumCandles: 55, requiredIndicators: BASE_INDICATORS },
  { id: "forex.london-breakout", legacyName: "ForexLondonBreakout", version: "1.0.0", lifecycle: "ENABLED", markets: ["forex"], eligibleInstrumentClasses: FX_CLASSES, symbols: FX_STRATEGY_SYMBOLS, primaryTimeframes: ["15m"], contextTimeframes: [], minimumCandles: 55, requiredIndicators: BASE_INDICATORS },
  { id: "forex.new-york-continuation", legacyName: "ForexNewYorkContinuation", version: "1.0.0", lifecycle: "ENABLED", markets: ["forex"], eligibleInstrumentClasses: FX_CLASSES, symbols: FX_STRATEGY_SYMBOLS, primaryTimeframes: ["15m", "1h"], contextTimeframes: [], minimumCandles: 55, requiredIndicators: BASE_INDICATORS },
  { id: "forex.trend-pullback", legacyName: "ForexTrendPullback", version: "1.0.0", lifecycle: "ENABLED", markets: ["forex"], eligibleInstrumentClasses: FX_CLASSES, symbols: FX_STRATEGY_SYMBOLS, primaryTimeframes: ["15m", "1h"], contextTimeframes: [], minimumCandles: 55, requiredIndicators: BASE_INDICATORS },
  { id: "gold.volatility-breakout", legacyName: "GoldVolatilityBreakout", version: "1.0.0", lifecycle: "ENABLED", markets: ["gold"], eligibleInstrumentClasses: ["metal_gold"], symbols: ["XAUUSD"], primaryTimeframes: ["15m"], contextTimeframes: ["1h"], minimumCandles: 64, requiredIndicators: [...BASE_INDICATORS, "range_compression_ratio"] }
];
function runtimeInstrument(value) {
  const normalized = value.replace(/[^A-Za-z]/g, "").toUpperCase();
  return FOREX_RUNTIME_INSTRUMENTS.find((instrument2) => instrument2.symbol === normalized) ?? null;
}
function runtimePipDistance(symbol, from, to) {
  const instrument2 = runtimeInstrument(symbol);
  return instrument2 && Number.isFinite(from) && Number.isFinite(to) ? Number((Math.abs(to - from) / instrument2.pip_size).toFixed(1)) : 0;
}
function roundRuntimePrice(symbol, price) {
  const instrument2 = runtimeInstrument(symbol);
  return instrument2 && Number.isFinite(price) ? Number(price.toFixed(instrument2.rounding_precision)) : 0;
}
function forexStrategyEligibility(contract, symbol) {
  const instrument2 = runtimeInstrument(symbol);
  if (!instrument2?.runtime_enabled) return { eligible: false, reason: "unsupported_symbol" };
  if (instrument2.instrument_class === "metal_gold" && contract.id !== "gold.volatility-breakout") return { eligible: false, reason: "strategy_instrument_class_not_supported" };
  if (contract.id === "gold.volatility-breakout" && instrument2.instrument_class !== "metal_gold") return { eligible: false, reason: "strategy_instrument_class_not_supported" };
  return contract.eligibleInstrumentClasses.includes(instrument2.instrument_class) && contract.symbols.includes(instrument2.symbol) ? { eligible: true, reason: null } : { eligible: false, reason: "unsupported_instrument_class" };
}

// supabase/functions/_shared/forex-legacy-evaluators.ts
function normalizeSymbol(symbol) {
  const clean = symbol.replace(/[^A-Za-z0-9]/g, "").toUpperCase();
  if (clean.includes("EURUSD")) return "EURUSD";
  if (clean.includes("GBPUSD")) return "GBPUSD";
  if (clean.includes("USDJPY")) return "USDJPY";
  if (clean.includes("AUDUSD")) return "AUDUSD";
  if (clean.includes("USDCAD")) return "USDCAD";
  if (clean.includes("XAUUSD") || clean.includes("GOLD")) return "XAUUSD";
  return clean;
}
var calcEMA = emaRootV1;
var calcATR = atrRootV1;
var calcRSI = rsiRootV1;
var clampScore = (v) => Math.min(Math.max(Math.round(v), 0), 100);
var scoreGrade = (v) => v >= 85 ? "A+" : v >= 75 ? "A" : v >= 65 ? "B" : "reject";
var hasInvalidCandles = (c) => c.some((x) => ![x.open, x.high, x.low, x.close].every(Number.isFinite) || x.high < x.low || x.close <= 0);
var pctDistance = (a, b) => a > 0 && Number.isFinite(a) && Number.isFinite(b) ? parseFloat((Math.abs(b - a) / a * 100).toFixed(4)) : 0;
function calcMomentumScore(v, lookback = 3) {
  const r = v.slice(-lookback - 1);
  let up = 0, dn = 0;
  for (let i = 1; i < r.length; i++) r[i] > r[i - 1] ? up++ : r[i] < r[i - 1] ? dn++ : 0;
  return (up - dn) / lookback;
}
function strategyZeroReject(reason) {
  return { status: "rejected", direction: "", entry_low: 0, entry_high: 0, stop_loss: 0, tp1: 0, tp2: 0, risk_reward: 0, confidence_score: 0, grade: "reject", reason, rejection_reason: reason, score_breakdown: { primary_failed_gate: reason } };
}
function forexPairType(symbol) {
  const normalized = normalizeSymbol(symbol);
  const instrument2 = runtimeInstrument(normalized);
  return instrument2?.instrument_class === "metal_gold" ? "metal_gold" : instrument2?.instrument_class === "fx_jpy" ? "fx_jpy" : instrument2?.instrument_class === "fx_non_jpy" ? "fx_non_jpy" : "unknown";
}
function forexSessionContext(date) {
  if (!date) return "Unknown";
  const hour = date.getUTCHours();
  if (hour >= 12 && hour < 16) return "London-NY overlap";
  if (hour >= 7 && hour < 12) return "London";
  if (hour >= 16 && hour < 21) return "New York";
  if (hour >= 0 && hour < 7) return "Asian";
  return "Unknown";
}
function forexAtrPct(symbol, atr2, price) {
  if (price <= 0 || !Number.isFinite(atr2) || !Number.isFinite(price)) return 0;
  return atr2 / price * 100;
}
function forexZeroReject(reason, symbol) {
  return {
    ...strategyZeroReject(reason),
    score_breakdown: {
      primary_failed_gate: reason,
      forex_pair_type: forexPairType(symbol),
      session_context: forexSessionContext()
    }
  };
}
function forexEntryBand(symbol, price, atr2, maxPips) {
  const half = Math.min(atr2 * 0.12, (runtimeInstrument(symbol)?.pip_size ?? 0) * maxPips);
  return {
    entry_low: roundRuntimePrice(symbol, price - half),
    entry_high: roundRuntimePrice(symbol, price + half)
  };
}
function evalForexMicroScalper(candles, ind, timeframe, params) {
  const symbol = normalizeSymbol(candles[candles.length - 1]?.symbol ?? "");
  const min_atr_pct = params.min_atr_pct ?? (runtimeInstrument(symbol)?.instrument_class === "fx_jpy" ? 0.025 : 0.018);
  const max_atr_pct = params.max_atr_pct ?? 0.32;
  const min_body_atr = params.min_body_atr ?? 0.18;
  const stop_atr_mult = Math.max(params.stop_atr_mult ?? 1.15, 1.25);
  const tp1_r = params.tp1_r ?? 1.15;
  const tp2_r = params.tp2_r ?? 1.7;
  const min_rr = params.min_rr ?? 1.25;
  const min_score = params.min_score ?? 74;
  const momentum_lookback = Math.max(2, Math.floor(params.momentum_lookback ?? 3));
  const min_stop_pips = Math.max(params.min_stop_pips ?? 0, runtimeInstrument(symbol)?.instrument_class === "fx_jpy" ? 7 : 6);
  const min_tp1_pips = Math.max(params.min_tp1_pips ?? 0, runtimeInstrument(symbol)?.instrument_class === "fx_jpy" ? 8 : 7);
  const min_tp2_pips = Math.max(params.min_tp2_pips ?? 0, runtimeInstrument(symbol)?.instrument_class === "fx_jpy" ? 12 : 10);
  const max_entry_band_pips = params.max_entry_band_pips ?? (timeframe === "5m" ? 1.2 : 1.8);
  if (!["5m", "15m"].includes(timeframe)) return forexZeroReject("unsupported_timeframe", symbol);
  if (candles.length < 55) return forexZeroReject("insufficient_candles", symbol);
  if (hasInvalidCandles(candles)) return forexZeroReject("invalid_candles", symbol);
  const last = candles[candles.length - 1];
  const prev = candles[candles.length - 2];
  const price = last.close;
  const atr2 = ind.atr14;
  const pip = runtimeInstrument(symbol)?.pip_size ?? 0;
  const atrPips = atr2 / pip;
  const atrPct = forexAtrPct(symbol, atr2, price);
  if (atr2 <= 0 || price <= 0 || !Number.isFinite(atr2) || !Number.isFinite(price)) return forexZeroReject("invalid_atr_or_price", symbol);
  const closes = candles.map((c) => c.close);
  const highs = candles.map((c) => c.high);
  const lows = candles.map((c) => c.low);
  const momentumRaw = calcMomentumScore(closes, momentum_lookback);
  const emaSpreadPips = Math.abs(ind.ema20 - ind.ema50) / pip;
  const emaSpreadAtr = Math.abs(ind.ema20 - ind.ema50) / atr2;
  const recentHigh = Math.max(...highs.slice(-8, -1));
  const recentLow = Math.min(...lows.slice(-8, -1));
  const body = Math.abs(last.close - last.open);
  const bodyAtr = body / atr2;
  const upperWick = last.high - Math.max(last.open, last.close);
  const lowerWick = Math.min(last.open, last.close) - last.low;
  const totalRange = Math.max(last.high - last.low, pip / 10);
  const bodyShare = body / totalRange;
  const buyContext = (ind.ema20 > ind.ema50 ? 2 : 0) + (price > ind.ema20 ? 1 : 0) + (momentumRaw > 0 ? 1 : 0) + (ind.rsi14 >= 50 ? 1 : 0) + (last.close >= recentHigh ? 1 : 0);
  const sellContext = (ind.ema20 < ind.ema50 ? 2 : 0) + (price < ind.ema20 ? 1 : 0) + (momentumRaw < 0 ? 1 : 0) + (ind.rsi14 <= 50 ? 1 : 0) + (last.close <= recentLow ? 1 : 0);
  const direction = buyContext >= sellContext ? "buy" : "sell";
  const directionalMomentum = direction === "buy" ? momentumRaw : -momentumRaw;
  const candleInDirection = direction === "buy" ? last.close > last.open : last.close < last.open;
  const wickOk = direction === "buy" ? upperWick <= body * 1.8 : lowerWick <= body * 1.8;
  const trendConfirmed = direction === "buy" ? ind.ema20 > ind.ema50 && price > ind.ema20 : ind.ema20 < ind.ema50 && price < ind.ema20;
  const structureAligned = direction === "buy" ? last.close > prev.close && last.low >= recentLow - atr2 * 0.25 : last.close < prev.close && last.high <= recentHigh + atr2 * 0.25;
  const microBreakoutAligned = direction === "buy" ? price >= recentHigh - atr2 * 0.08 && last.close > prev.close : price <= recentLow + atr2 * 0.08 && last.close < prev.close;
  const trendQualityPass = trendConfirmed || emaSpreadPips >= 0.8 && (direction === "buy" ? buyContext >= 4 : sellContext >= 4) && price > 0;
  const structureQualityPass = structureAligned || microBreakoutAligned && bodyAtr >= min_body_atr * 0.8;
  const rsiConfirmed = direction === "buy" ? ind.rsi14 >= 48 && ind.rsi14 <= 72 : ind.rsi14 <= 52 && ind.rsi14 >= 28;
  const spikeOnly = bodyAtr > 1.25 && Math.abs(last.close - prev.close) > atr2 * 1.15 && Math.sign(last.close - last.open) !== Math.sign(prev.close - prev.open);
  const { entry_low, entry_high } = forexEntryBand(symbol, price, atr2, max_entry_band_pips);
  const rawRisk = Math.max(atr2 * stop_atr_mult, pip * min_stop_pips);
  const structureStop = direction === "buy" ? Math.min(recentLow - atr2 * 0.12, price - rawRisk) : Math.max(recentHigh + atr2 * 0.12, price + rawRisk);
  const stop_loss = roundRuntimePrice(symbol, structureStop);
  const risk = Math.abs(price - stop_loss);
  const tp1 = roundRuntimePrice(symbol, direction === "buy" ? price + risk * tp1_r : price - risk * tp1_r);
  const tp2 = roundRuntimePrice(symbol, direction === "buy" ? price + risk * tp2_r : price - risk * tp2_r);
  const risk_reward = risk > 0 ? parseFloat((Math.abs(tp2 - price) / risk).toFixed(2)) : 0;
  const stopPips = runtimePipDistance(symbol, price, stop_loss);
  const tp1Pips = runtimePipDistance(symbol, price, tp1);
  const tp2Pips = runtimePipDistance(symbol, price, tp2);
  const trendScore = clampScore((trendConfirmed ? 45 : 15) + Math.min(emaSpreadAtr, 0.8) * 35 + (structureAligned ? 20 : 0));
  const momentumScore = clampScore(Math.max(0, directionalMomentum) * 55 + (candleInDirection ? 20 : 0) + (structureAligned ? 15 : 0) + Math.min(bodyAtr, 0.8) * 12);
  const candleScore = clampScore((candleInDirection ? 35 : 8) + Math.min(bodyAtr / Math.max(min_body_atr, 0.01), 1.2) * 35 + (bodyShare >= 0.35 ? 20 : 5) + (wickOk ? 10 : 0));
  const rsiScore = direction === "buy" ? clampScore(100 - Math.abs(ind.rsi14 - 58) * 4) : clampScore(100 - Math.abs(ind.rsi14 - 42) * 4);
  let volatilityScore = 85;
  if (atrPct < min_atr_pct) volatilityScore = clampScore(atrPct / Math.max(min_atr_pct, 1e-3) * 55);
  else if (atrPct > max_atr_pct) volatilityScore = clampScore(Math.max(20, 85 - (atrPct - max_atr_pct) / Math.max(max_atr_pct, 1e-3) * 120));
  const spreadOrDistanceScore = clampScore(Math.min(stopPips / Math.max(min_stop_pips, 0.1), 1.4) * 45 + Math.min(tp1Pips / Math.max(min_tp1_pips, 0.1), 1.4) * 25 + Math.min(tp2Pips / Math.max(min_tp2_pips, 0.1), 1.4) * 20 + Math.min(atrPips / Math.max(min_stop_pips, 0.1), 1.2) * 10);
  const rrScore = clampScore(Math.min(risk_reward / Math.max(min_rr, 0.01), 1.45) * 70);
  let primaryFailedGate = "";
  if (atrPct < min_atr_pct) primaryFailedGate = "volatility_too_low";
  else if (atrPct > max_atr_pct) primaryFailedGate = "volatility_too_high";
  else if (emaSpreadPips < 0.8 || stopPips < min_stop_pips || tp1Pips < min_tp1_pips || tp2Pips < min_tp2_pips) primaryFailedGate = "distance_guard_failed";
  else if (!trendQualityPass || !structureQualityPass) primaryFailedGate = "trend_filter_failed";
  else if (directionalMomentum < 0.15) primaryFailedGate = "momentum_failed";
  else if (!candleInDirection || bodyAtr < min_body_atr || bodyShare < 0.32 || !wickOk || spikeOnly) primaryFailedGate = "candle_body_too_small";
  else if (!rsiConfirmed) primaryFailedGate = "momentum_failed";
  else if (risk_reward < min_rr) primaryFailedGate = "rr_too_low";
  const finalScore = clampScore(trendScore * 0.22 + momentumScore * 0.19 + candleScore * 0.17 + rsiScore * 0.12 + volatilityScore * 0.12 + spreadOrDistanceScore * 0.1 + rrScore * 0.08);
  if (!primaryFailedGate && finalScore < min_score) primaryFailedGate = "confidence_too_low";
  const score_breakdown = {
    primary_failed_gate: primaryFailedGate || "passed",
    trend_score: trendScore,
    momentum_score: momentumScore,
    volatility_score: volatilityScore,
    candle_score: candleScore,
    rsi_score: rsiScore,
    spread_or_distance_score: spreadOrDistanceScore,
    rr_score: rrScore,
    rr: risk_reward,
    direction,
    ema_alignment: direction === "buy" ? "ema20_above_ema50" : "ema20_below_ema50",
    trend_quality_pass: trendQualityPass,
    structure_quality_pass: structureQualityPass,
    micro_breakout_aligned: microBreakoutAligned,
    ema_spread_pips: parseFloat(emaSpreadPips.toFixed(1)),
    atr_pips: parseFloat(atrPips.toFixed(1)),
    atr_pct: parseFloat(atrPct.toFixed(4)),
    body_atr: parseFloat(bodyAtr.toFixed(3)),
    body_share: parseFloat(bodyShare.toFixed(3)),
    structure_aligned: structureAligned,
    spike_only: spikeOnly,
    rsi: parseFloat(ind.rsi14.toFixed(2)),
    stop_distance_pct: pctDistance(price, stop_loss),
    tp1_distance_pct: pctDistance(price, tp1),
    tp2_distance_pct: pctDistance(price, tp2),
    stop_distance_pips: stopPips,
    tp1_distance_pips: tp1Pips,
    tp2_distance_pips: tp2Pips,
    forex_pair_type: forexPairType(symbol),
    session_context: forexSessionContext(new Date(candles.at(-1).open_time)),
    final_score: finalScore
  };
  const grade2 = scoreGrade(finalScore);
  const reason = `ForexMicroScalper ${direction}: EMA context=${trendScore}, momentum=${momentumScore}, candle=${candleScore}, ATR=${atrPips.toFixed(1)} pips, rr=${risk_reward.toFixed(2)}R, score=${finalScore}`;
  if (primaryFailedGate) return { status: "rejected", direction, entry_low, entry_high, stop_loss, tp1, tp2, risk_reward, confidence_score: finalScore, grade: "reject", reason, rejection_reason: primaryFailedGate, score_breakdown };
  return { status: "candidate", direction, entry_low, entry_high, stop_loss, tp1, tp2, risk_reward, confidence_score: finalScore, grade: grade2, reason, rejection_reason: "", score_breakdown };
}
function evalForexSwingContinuation(candles, ind, timeframe, params) {
  const symbol = normalizeSymbol(candles[candles.length - 1]?.symbol ?? "");
  const min_atr_pct = params.min_atr_pct ?? 0.018;
  const max_atr_pct = params.max_atr_pct ?? 0.42;
  const pullback_bars = Math.max(3, Math.floor(params.pullback_bars ?? 6));
  const stop_atr_mult = Math.max(params.stop_atr_mult ?? 1.35, 1.35);
  const tp1_r = params.tp1_r ?? 1.25;
  const tp2_r = params.tp2_r ?? 1.85;
  const min_rr = params.min_rr ?? 1.45;
  const min_score = params.min_score ?? 78;
  const momentum_lookback = Math.max(2, Math.floor(params.momentum_lookback ?? 4));
  const atr_len = Math.max(2, Math.floor(params.atr_len ?? 14));
  const rsi_len = Math.max(2, Math.floor(params.rsi_len ?? 14));
  const ema_fast = Math.max(2, Math.floor(params.ema_fast ?? 20));
  const ema_slow = Math.max(ema_fast + 1, Math.floor(params.ema_slow ?? 50));
  const min_stop_pips = Math.max(params.min_stop_pips ?? 0, runtimeInstrument(symbol)?.instrument_class === "fx_jpy" ? 13 : 11);
  const min_tp1_pips = Math.max(params.min_tp1_pips ?? 0, runtimeInstrument(symbol)?.instrument_class === "fx_jpy" ? 15 : 13);
  if (!["1h", "15m"].includes(timeframe)) return forexZeroReject("unsupported_timeframe", symbol);
  const minLen = Math.max(ema_slow + 8, atr_len + 2, rsi_len + 2, pullback_bars + 12, 60);
  if (candles.length < minLen) return forexZeroReject("insufficient_candles", symbol);
  if (hasInvalidCandles(candles)) return forexZeroReject("invalid_candles", symbol);
  const closes = candles.map((c) => c.close);
  const last = candles[candles.length - 1];
  const price = last.close;
  const atr2 = calcATR(candles, atr_len);
  const pip = runtimeInstrument(symbol)?.pip_size ?? 0;
  const atrPct = forexAtrPct(symbol, atr2, price);
  const atrPips = atr2 / pip;
  const rsi2 = calcRSI(closes, rsi_len);
  const emaFast = calcEMA(closes, ema_fast);
  const emaSlow = calcEMA(closes, ema_slow);
  const priorEmaFast = calcEMA(closes.slice(0, -pullback_bars), ema_fast);
  if (atr2 <= 0 || price <= 0 || !Number.isFinite(atr2) || !Number.isFinite(price)) return forexZeroReject("invalid_atr_or_price", symbol);
  const emaSpreadPct = emaSlow > 0 ? (emaFast - emaSlow) / emaSlow * 100 : 0;
  const emaSpreadPips = (emaFast - emaSlow) / pip;
  const emaSlope = priorEmaFast > 0 ? (emaFast - priorEmaFast) / priorEmaFast * 100 : 0;
  const bullBias = emaSpreadPct * 2 + emaSlope * 1.5 + (price > emaFast ? 0.15 : -0.15) + (rsi2 - 50) / 120;
  const bearBias = -emaSpreadPct * 2 + -emaSlope * 1.5 + (price < emaFast ? 0.15 : -0.15) + (50 - rsi2) / 120;
  const direction = bullBias >= bearBias ? "buy" : "sell";
  const directionalSpreadPct = direction === "buy" ? emaSpreadPct : -emaSpreadPct;
  const directionalSlope = direction === "buy" ? emaSlope : -emaSlope;
  const directionalSpreadPips = direction === "buy" ? emaSpreadPips : -emaSpreadPips;
  const emaAligned = direction === "buy" ? emaFast > emaSlow : emaFast < emaSlow;
  const emaAlignment = direction === "buy" ? emaAligned ? "bullish" : "not_bullish" : emaAligned ? "bearish" : "not_bearish";
  const priceVsEma = direction === "buy" ? (price - emaFast) / price * 100 : (emaFast - price) / price * 100;
  const pullbackWindow = candles.slice(-(pullback_bars + 1), -1);
  const pullbackLow = Math.min(...pullbackWindow.map((c) => c.low));
  const pullbackHigh = Math.max(...pullbackWindow.map((c) => c.high));
  const pullbackCloseMin = Math.min(...pullbackWindow.map((c) => c.close));
  const pullbackCloseMax = Math.max(...pullbackWindow.map((c) => c.close));
  const touchedBuyZone = pullbackLow <= emaFast + atr2 * 0.8 && pullbackLow >= emaSlow - atr2 * 0.6 || pullbackCloseMin <= emaFast + atr2 * 0.35 && pullbackCloseMin >= emaSlow - atr2 * 0.75;
  const touchedSellZone = pullbackHigh >= emaFast - atr2 * 0.8 && pullbackHigh <= emaSlow + atr2 * 0.6 || pullbackCloseMax >= emaFast - atr2 * 0.35 && pullbackCloseMax <= emaSlow + atr2 * 0.75;
  const reclaimedBuy = price > emaFast && price > pullbackCloseMin + atr2 * 0.18 && (last.close > last.open || Math.abs(last.close - last.open) >= atr2 * 0.18);
  const reclaimedSell = price < emaFast && price < pullbackCloseMax - atr2 * 0.18 && (last.close < last.open || Math.abs(last.close - last.open) >= atr2 * 0.18);
  const pullbackReady = direction === "buy" ? touchedBuyZone : touchedSellZone;
  const reclaimConfirmed = direction === "buy" ? reclaimedBuy : reclaimedSell;
  const momentum = calcMomentumScore(closes, momentum_lookback);
  const directionalMomentum = direction === "buy" ? momentum : -momentum;
  const bodyAtr = Math.abs(last.close - last.open) / atr2;
  const rsiOk = direction === "buy" ? rsi2 >= 48 && rsi2 <= 70 : rsi2 <= 52 && rsi2 >= 30;
  const recentHigh = Math.max(...candles.slice(-14, -1).map((c) => c.high));
  const recentLow = Math.min(...candles.slice(-14, -1).map((c) => c.low));
  const structureContinuation = direction === "buy" ? price > emaFast && recentLow > emaSlow - atr2 * 0.6 : price < emaFast && recentHigh < emaSlow + atr2 * 0.6;
  const { entry_low, entry_high } = forexEntryBand(symbol, price, atr2, timeframe === "1h" ? 2.5 : 1.8);
  const minRisk = pip * min_stop_pips;
  const stopBuffer = Math.max(atr2 * 0.2, pip * 2);
  const stop_loss = roundRuntimePrice(symbol, direction === "buy" ? Math.min(pullbackLow - stopBuffer, price - Math.max(atr2 * stop_atr_mult, minRisk)) : Math.max(pullbackHigh + stopBuffer, price + Math.max(atr2 * stop_atr_mult, minRisk)));
  const risk = Math.abs(price - stop_loss);
  const tp1 = roundRuntimePrice(symbol, direction === "buy" ? price + risk * tp1_r : price - risk * tp1_r);
  const tp2 = roundRuntimePrice(symbol, direction === "buy" ? price + risk * tp2_r : price - risk * tp2_r);
  const risk_reward = risk > 0 ? parseFloat((Math.abs(tp2 - price) / risk).toFixed(2)) : 0;
  const stopPips = runtimePipDistance(symbol, price, stop_loss);
  const tp1Pips = runtimePipDistance(symbol, price, tp1);
  const tp2Pips = runtimePipDistance(symbol, price, tp2);
  const trendScore = clampScore((emaAligned ? 42 : 8) + Math.min(Math.max(directionalSpreadPct, 0) / 0.18, 1) * 28 + Math.min(Math.max(directionalSlope, 0) / 0.08, 1) * 22 + (directionalSpreadPips >= 2 ? 8 : 0));
  const emaSlopeScore = clampScore(35 + Math.min(Math.max(directionalSlope, -0.04) + 0.04, 0.16) / 0.16 * 65);
  const pullbackScore = direction === "buy" ? clampScore((touchedBuyZone ? 42 : 12) + (reclaimedBuy ? 38 : price > emaFast ? 18 : 0) + (pullbackLow > emaSlow - atr2 * 0.45 ? 20 : 5)) : clampScore((touchedSellZone ? 42 : 12) + (reclaimedSell ? 38 : price < emaFast ? 18 : 0) + (pullbackHigh < emaSlow + atr2 * 0.45 ? 20 : 5));
  const momentumScore = clampScore(Math.max(0, directionalMomentum) * 52 + ((direction === "buy" ? last.close > last.open : last.close < last.open) ? 18 : 0) + Math.min(bodyAtr, 0.9) * 20 + (rsiOk ? 10 : 0));
  let volatilityScore = 86;
  if (atrPct < min_atr_pct) volatilityScore = clampScore(atrPct / Math.max(min_atr_pct, 1e-3) * 55);
  else if (atrPct > max_atr_pct) volatilityScore = clampScore(Math.max(20, 86 - (atrPct - max_atr_pct) / Math.max(max_atr_pct, 1e-3) * 120));
  const distanceScore = clampScore(Math.min(stopPips / Math.max(min_stop_pips, 0.1), 1.35) * 45 + Math.min(tp1Pips / Math.max(min_tp1_pips, 0.1), 1.35) * 25 + Math.min(tp2Pips / Math.max(min_tp1_pips * 1.4, 0.1), 1.35) * 20 + Math.min(atrPips / Math.max(min_stop_pips * 0.7, 0.1), 1.2) * 10);
  const rrScore = clampScore(Math.min(risk_reward / Math.max(min_rr, 0.01), 1.35) * 74);
  const trendQualityPass = emaAligned && (trendScore >= 58 && directionalSlope > -0.015 && directionalSpreadPips >= 1.5 || trendScore >= 52 && emaSlopeScore >= 50 && directionalSlope > -0.025 && (directionalSpreadPips >= 1 || priceVsEma > 0) && structureContinuation);
  const reclaimQualityPass = reclaimConfirmed || pullbackScore >= 62 && momentumScore >= 42 && structureContinuation && (direction === "buy" ? price > emaFast : price < emaFast);
  let primaryFailedGate = "";
  if (atrPct < min_atr_pct) primaryFailedGate = "volatility_too_low";
  else if (atrPct > max_atr_pct) primaryFailedGate = "volatility_too_high";
  else if (!trendQualityPass) primaryFailedGate = "trend_filter_failed";
  else if (!pullbackReady || pullbackScore < 50) primaryFailedGate = "pullback_not_ready";
  else if (!reclaimQualityPass) primaryFailedGate = "reclaim_not_confirmed";
  else if (!structureContinuation) primaryFailedGate = "trend_filter_failed";
  else if (directionalMomentum < 0.05 || momentumScore < 42 || !rsiOk) primaryFailedGate = "momentum_failed";
  else if (stopPips < min_stop_pips || tp1Pips < min_tp1_pips) primaryFailedGate = "distance_guard_failed";
  else if (risk_reward < min_rr) primaryFailedGate = "rr_too_low";
  const finalScore = clampScore(trendScore * 0.23 + emaSlopeScore * 0.11 + pullbackScore * 0.21 + momentumScore * 0.15 + volatilityScore * 0.1 + distanceScore * 0.1 + rrScore * 0.1);
  if (!primaryFailedGate && finalScore < min_score) primaryFailedGate = "confidence_too_low";
  const score_breakdown = {
    primary_failed_gate: primaryFailedGate || "passed",
    trend_direction: direction,
    trend_score: trendScore,
    ema_alignment: emaAlignment,
    ema_slope: parseFloat(directionalSlope.toFixed(4)),
    ema_slope_score: emaSlopeScore,
    ema_spread_pips: parseFloat(directionalSpreadPips.toFixed(1)),
    price_vs_ema: parseFloat(priceVsEma.toFixed(4)),
    trend_quality_pass: trendQualityPass,
    pullback_score: pullbackScore,
    pullback_ready: pullbackReady,
    reclaim_confirmed: reclaimConfirmed,
    reclaim_quality_pass: reclaimQualityPass,
    momentum_score: momentumScore,
    volatility_score: volatilityScore,
    spread_or_distance_score: distanceScore,
    rr_score: rrScore,
    rr: risk_reward,
    atr_pips: parseFloat(atrPips.toFixed(1)),
    atr_pct: parseFloat(atrPct.toFixed(4)),
    body_atr: parseFloat(bodyAtr.toFixed(3)),
    rsi: parseFloat(rsi2.toFixed(2)),
    stop_distance_pct: pctDistance(price, stop_loss),
    tp1_distance_pct: pctDistance(price, tp1),
    tp2_distance_pct: pctDistance(price, tp2),
    stop_distance_pips: stopPips,
    tp1_distance_pips: tp1Pips,
    tp2_distance_pips: tp2Pips,
    session_context: forexSessionContext(new Date(candles.at(-1).open_time)),
    forex_pair_type: forexPairType(symbol),
    final_score: finalScore
  };
  const grade2 = scoreGrade(finalScore);
  const reason = `ForexSwingContinuation ${direction}: EMA ${emaAlignment}, pullback=${pullbackScore}, reclaim=${reclaimConfirmed}, momentum=${momentumScore}, ATR=${atrPips.toFixed(1)} pips, rr=${risk_reward.toFixed(2)}R, score=${finalScore}`;
  if (primaryFailedGate) return { status: "rejected", direction, entry_low, entry_high, stop_loss, tp1, tp2, risk_reward, confidence_score: finalScore, grade: "reject", reason, rejection_reason: primaryFailedGate, score_breakdown };
  return { status: "candidate", direction, entry_low, entry_high, stop_loss, tp1, tp2, risk_reward, confidence_score: finalScore, grade: grade2, reason, rejection_reason: "", score_breakdown };
}

// supabase/functions/_shared/trading-domain/market-view.ts
var WIDTH2 = { "1m": 6e4, "5m": 3e5, "15m": 9e5, "30m": 18e5, "1h": 36e5, "4h": 144e5, "1d": 864e5 };
function buildCanonicalMarketView(input) {
  const asOf = Date.parse(input.asOf);
  if (!Number.isFinite(asOf)) throw new Error("INVALID_AS_OF");
  const views = {};
  for (const timeframe of [.../* @__PURE__ */ new Set([input.primaryTimeframe, ...input.requiredTimeframes])]) {
    const rows = [...input.datasets[timeframe] ?? []].filter((c) => c.symbol === input.symbol && c.timeframe === timeframe && Date.parse(c.openTime) + WIDTH2[timeframe] <= asOf).sort((a, b) => Date.parse(a.openTime) - Date.parse(b.openTime));
    views[timeframe] = { timeframe, datasetId: rows[0]?.datasetId ?? "missing", candles: rows, lastClosed: rows[rows.length - 1] ?? null, warmupComplete: rows.length >= input.warmupBars };
  }
  return { version: "market-view/v1", symbol: input.symbol, asOf: new Date(asOf).toISOString(), primaryTimeframe: input.primaryTimeframe, views, session: input.session ?? { open: true, code: "CALLER_CONFIRMED" } };
}

// supabase/functions/_shared/trading-domain/indicators.ts
function canonicalIndicatorSnapshot(candles) {
  const closes = candles.map((c) => c.close), last = candles[candles.length - 1];
  return { ema20: emaRootV1(closes, 20), ema50: emaRootV1(closes, 50), rsi14: rsiRootV1(closes, 14), atr14: atrRootV1(candles, 14), recentHigh: Math.max(...candles.slice(-20).map((c) => c.high)), recentLow: Math.min(...candles.slice(-20).map((c) => c.low)), averageVolume: rollingAverageVolume(candles, Math.min(20, candles.length)), range20: rollingRange(candles, Math.min(20, candles.length)), body: last ? Math.abs(last.close - last.open) : 0 };
}

// supabase/functions/_shared/forex-domain.ts
var FOREX_INSTRUMENT_IDS = ["EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCAD", "USDCHF", "NZDUSD", "EURJPY", "GBPJPY", "XAUUSD"];
function instrument(id2, baseCurrency, quoteCurrency, sessionTimezone, marketCategory, volatilityProfile, productionEnabled) {
  const jpy = quoteCurrency === "JPY", metal = marketCategory === "metal";
  const typical = metal ? 3 : marketCategory === "cross" ? 1.8 : volatilityProfile === "high" ? 1.5 : 1;
  return { id: id2, providerSymbol: `${baseCurrency}/${quoteCurrency}`, displaySymbol: `${baseCurrency}/${quoteCurrency}`, assetClass: metal ? "gold" : "forex", baseCurrency, quoteCurrency, pipSize: metal ? 0.1 : jpy ? 0.01 : 1e-4, pointSize: metal ? 0.01 : jpy ? 1e-3 : 1e-5, pricePrecision: metal ? 2 : jpy ? 3 : 5, sessionTimezone, supportedTimeframes: ["15m", "1h"], productionEnabled, volatilityProfile, expectedSpreadPips: { typical, maximum: metal ? 8 : typical * 2.5 }, riskProfile: metal ? "metals" : volatilityProfile === "high" ? "elevated" : "standard", tradingHours: "Sunday 22:00-Friday 22:00 UTC (holiday exceptions)", marketCategory, tradingSessions: metal ? ["LONDON", "NEW_YORK", "LONDON_NEW_YORK_OVERLAP"] : ["SYDNEY", "TOKYO", "LONDON", "NEW_YORK", "LONDON_NEW_YORK_OVERLAP"] };
}
var FOREX_INSTRUMENTS = {
  EURUSD: instrument("EURUSD", "EUR", "USD", "Europe/London", "major", "medium", true),
  GBPUSD: instrument("GBPUSD", "GBP", "USD", "Europe/London", "major", "high", true),
  USDJPY: instrument("USDJPY", "USD", "JPY", "Asia/Tokyo", "major", "medium", true),
  AUDUSD: instrument("AUDUSD", "AUD", "USD", "Australia/Sydney", "major", "medium", true),
  USDCAD: instrument("USDCAD", "USD", "CAD", "America/New_York", "major", "medium", true),
  USDCHF: instrument("USDCHF", "USD", "CHF", "Europe/Zurich", "major", "low", true),
  NZDUSD: instrument("NZDUSD", "NZD", "USD", "Pacific/Auckland", "major", "medium", true),
  EURJPY: instrument("EURJPY", "EUR", "JPY", "Europe/London", "cross", "high", true),
  GBPJPY: instrument("GBPJPY", "GBP", "JPY", "Europe/London", "cross", "high", true),
  XAUUSD: instrument("XAUUSD", "XAU", "USD", "America/New_York", "metal", "metals", true)
};
function normalizeForexInstrument(value) {
  const normalized = value.trim().toUpperCase().replace(/[^A-Z0-9]/g, "").replace(/(?:PRO|RAW)$/i, "");
  if (["GOLD", "XAUUSD", "XAUUSDM", "XAUUSDA"].includes(normalized)) return "XAUUSD";
  return FOREX_INSTRUMENT_IDS.find((id2) => normalized === id2 || normalized === `${id2}M` || normalized === `${id2}A`) ?? null;
}
function instrumentFor(value) {
  const id2 = normalizeForexInstrument(value);
  return id2 ? FOREX_INSTRUMENTS[id2] : null;
}
function roundInstrumentPrice(id2, value) {
  return Number(value.toFixed(FOREX_INSTRUMENTS[id2].pricePrecision));
}
function priceToPips(id2, value) {
  return value / FOREX_INSTRUMENTS[id2].pipSize;
}
var zoneFormatters = /* @__PURE__ */ new Map();
function zonedParts(at, timeZone) {
  let formatter = zoneFormatters.get(timeZone);
  if (!formatter) {
    formatter = new Intl.DateTimeFormat("en-GB", { timeZone, weekday: "short", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" });
    if (zoneFormatters.size >= 16) zoneFormatters.delete(zoneFormatters.keys().next().value);
    zoneFormatters.set(timeZone, formatter);
  }
  const parts = formatter.formatToParts(at);
  const get = (type) => parts.find((part) => part.type === type)?.value ?? "";
  return { weekday: get("weekday"), year: Number(get("year")), month: Number(get("month")), day: Number(get("day")), hour: Number(get("hour")), minute: Number(get("minute")) };
}
function sessionOpenAt(at, timeZone, hour) {
  const local = zonedParts(at, timeZone), targetWallClock = Date.UTC(local.year, local.month - 1, local.day, hour);
  const offsetAt = (instant) => {
    const parts = zonedParts(instant, timeZone);
    return Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour, parts.minute) - instant.getTime();
  };
  let candidate2 = new Date(targetWallClock - offsetAt(new Date(Date.UTC(local.year, local.month - 1, local.day, 12))));
  candidate2 = new Date(targetWallClock - offsetAt(candidate2));
  const verified = zonedParts(candidate2, timeZone);
  return verified.year === local.year && verified.month === local.month && verified.day === local.day && verified.hour === hour && verified.minute === 0 ? candidate2.toISOString() : null;
}
function sessionWindow(at, timeZone, startHour, endHour) {
  const part = zonedParts(at, timeZone);
  if (["Sat", "Sun"].includes(part.weekday)) return false;
  const clock = part.hour + part.minute / 60;
  return clock >= startHour && clock < endHour;
}
function forexSessionContext2(at, holidays = []) {
  const date = typeof at === "string" ? new Date(at) : at;
  if (!Number.isFinite(date.getTime())) return { primary: "CLOSED", active: [], overlap: false, marketOpen: false, weekend: false, holiday: false, volatility: "closed", reason: "invalid_time" };
  const utc = zonedParts(date, "UTC"), clock = utc.hour + utc.minute / 60;
  const weekend = utc.weekday === "Sat" || utc.weekday === "Fri" && clock >= 22 || utc.weekday === "Sun" && clock < 22;
  const holiday = holidays.includes(date.toISOString().slice(0, 10));
  if (weekend || holiday) return { primary: "CLOSED", active: [], overlap: false, marketOpen: false, weekend, holiday, volatility: "closed", reason: holiday ? "market_holiday" : "weekly_close" };
  const active = [];
  if (sessionWindow(date, "Australia/Sydney", 8, 17)) active.push("SYDNEY");
  if (sessionWindow(date, "Asia/Tokyo", 9, 18)) active.push("TOKYO");
  if (sessionWindow(date, "Europe/London", 8, 16)) active.push("LONDON");
  if (sessionWindow(date, "America/New_York", 8, 17)) active.push("NEW_YORK");
  const overlap = active.includes("LONDON") && active.includes("NEW_YORK");
  const primary = overlap ? "LONDON_NEW_YORK_OVERLAP" : active.includes("LONDON") ? "LONDON" : active.includes("NEW_YORK") ? "NEW_YORK" : active.includes("TOKYO") ? "TOKYO" : active.includes("SYDNEY") ? "SYDNEY" : "ASIA";
  return { primary, active, overlap, marketOpen: true, weekend: false, holiday: false, volatility: overlap ? "high" : active.includes("LONDON") || active.includes("NEW_YORK") ? "normal" : "low", reason: null };
}
function forexSession(at) {
  return forexSessionContext2(at).primary;
}
function timeframeMilliseconds(timeframe) {
  const match = /^(\d+)(m|h|d)$/.exec(timeframe);
  if (!match) return null;
  return Number(match[1]) * (match[2] === "m" ? 6e4 : match[2] === "h" ? 36e5 : 864e5);
}
function buildForexMarketContext(input) {
  const instrument2 = instrumentFor(input.symbol);
  if (!instrument2) return null;
  const interval = timeframeMilliseconds(input.timeframe);
  if (!interval) return null;
  const now = Date.parse(input.evaluatedAt);
  const normalized = input.candles.map((c) => ({ ...c, symbol: instrument2.id, market_type: "forex", timeframe: input.timeframe })).filter((c) => Date.parse(c.open_time) + interval <= now).sort((a, b) => Date.parse(a.open_time) - Date.parse(b.open_time));
  const malformed = normalized.length === 0 || normalized.some((c, index) => ![c.open, c.high, c.low, c.close].every(Number.isFinite) || c.close <= 0 || c.low > Math.min(c.open, c.close) || c.high < Math.max(c.open, c.close) || c.high < c.low || index > 0 && Date.parse(c.open_time) <= Date.parse(normalized[index - 1].open_time));
  const current = normalized[normalized.length - 1] ?? null;
  const stale = !current || now - (Date.parse(current.open_time) + interval) > interval * 2;
  const closes = normalized.map((c) => c.close), ema200 = emaRootV1(closes, 200), price = current?.close ?? 0, atr2 = input.indicators.atr14;
  const trendState2 = input.indicators.ema20 > input.indicators.ema50 && price > input.indicators.ema20 ? "UP" : input.indicators.ema20 < input.indicators.ema50 && price < input.indicators.ema20 ? "DOWN" : "FLAT";
  const extension = atr2 > 0 ? Math.abs(price - input.indicators.ema20) / atr2 : Infinity;
  const pullbackState = trendState2 === "FLAT" ? "NONE" : extension <= 0.7 ? "CONTROLLED" : extension > 1.8 ? "EXTENDED" : "NONE";
  const ratio = price > 0 ? atr2 / price : Infinity;
  const gold = instrument2.assetClass === "gold";
  const volatilityState = ratio < (gold ? 7e-4 : 25e-5) ? "LOW" : ratio > (gold ? 0.012 : 6e-3) ? "ABNORMAL" : ratio > (gold ? 6e-3 : 3e-3) ? "HIGH" : "NORMAL";
  const session = forexSession(input.evaluatedAt);
  const rangeRows = normalized.slice(-49, -1);
  const breakoutRange = rangeRows.length ? { high: Math.max(...rangeRows.map((c) => c.high)), low: Math.min(...rangeRows.map((c) => c.low)), candles: rangeRows.length } : null;
  const spreadPrice = input.spreadPrice ?? null, spreadPips = spreadPrice === null ? null : priceToPips(instrument2.id, spreadPrice), maximumPips = input.maximumSpreadPips ?? (gold ? 8 : 2.5);
  const spread = { model: input.spreadModel ?? (spreadPrice === null ? "unavailable" : "provider"), spreadPrice, spreadPips, maximumPips, eligible: spreadPips === null || spreadPips <= maximumPips };
  const budgetRemaining = input.budgetRemaining ?? null;
  const providerCost = { provider: input.provider ?? "twelvedata", requestCost: input.requestCost ?? 1, cacheHit: input.cacheHit ?? false, budgetRemaining, budgetEligible: budgetRemaining === null || budgetRemaining >= (input.requestCost ?? 1) };
  const evaluationDate = new Date(input.evaluatedAt);
  return { instrument: instrument2, symbol: instrument2.id, timeframe: input.timeframe, evaluatedAt: input.evaluatedAt, normalizedCandles: normalized, currentClosedCandle: current, previousClosedCandles: normalized.slice(0, -1), indicators: input.indicators, ema200, session, sessionMetadata: { londonOpen: session === "LONDON" || session === "LONDON_NEW_YORK_OVERLAP", newYorkOpen: session === "NEW_YORK" || session === "LONDON_NEW_YORK_OVERLAP", overlap: session === "LONDON_NEW_YORK_OVERLAP", londonOpenAt: sessionOpenAt(evaluationDate, "Europe/London", 8), newYorkOpenAt: sessionOpenAt(evaluationDate, "America/New_York", 8), timezone: instrument2.sessionTimezone }, breakoutRange, volatilityState, trendState: trendState2, pullbackState, stale, malformed, marketOpen: session !== "CLOSED", spread, providerCost, evidence: { instrument_id: instrument2.id, provider_symbol: instrument2.providerSymbol, asset_class: instrument2.assetClass, closed_candle_time: current?.open_time ?? null, candle_count: normalized.length, atr: atr2, ema20: input.indicators.ema20, ema50: input.indicators.ema50, ema200, rsi: input.indicators.rsi14, session, stale, malformed, spread_eligible: spread.eligible, provider_budget_eligible: providerCost.budgetEligible } };
}

// supabase/functions/_shared/forex-research-strategies.ts
function reject5(reason, evidence = {}) {
  return { status: "rejected", direction: "none", entry_low: 0, entry_high: 0, stop_loss: 0, tp1: 0, tp2: 0, risk_reward: 0, confidence_score: 0, grade: "reject", reason, rejection_reason: reason, score_breakdown: { primary_failed_gate: reason, research_only: true, ...evidence } };
}
function contextFor(input) {
  return buildForexMarketContext({ symbol: input.symbol, timeframe: input.timeframe, candles: input.candles, indicators: input.indicators, evaluatedAt: input.evaluated_at });
}
function preflight(strategy, input, market) {
  if (!market) return reject5("unsupported_symbol");
  if (!strategy.symbols.includes(market.symbol)) return reject5("unsupported_symbol", { symbol: market.symbol });
  if (!strategy.timeframes.includes(input.timeframe)) return reject5("unsupported_timeframe", { timeframe: input.timeframe });
  if (market.malformed) return reject5("malformed_candles");
  if (market.stale) return reject5("stale_candles");
  if (market.normalizedCandles.length < 55) return reject5("insufficient_candles", { candle_count: market.normalizedCandles.length });
  if (!strategy.sessions.includes(market.session)) return reject5("session_not_eligible", { session: market.session });
  if (!market.spread.eligible) return reject5("spread_too_wide");
  if (!market.providerCost.budgetEligible) return reject5("provider_budget_exhausted");
  if (!Number.isFinite(market.indicators.atr14) || market.indicators.atr14 <= 0 || !market.currentClosedCandle) return reject5("invalid_atr_or_price");
  return null;
}
function candidate(strategy, market, direction, stopDistance, tp1R, tp2R, confidence, evidence) {
  const price = market.currentClosedCandle.close, sign = direction === "buy" ? 1 : -1;
  if (!Number.isFinite(stopDistance) || stopDistance < market.instrument.pointSize * 5) return reject5("invalid_stop", { stop_distance: stopDistance });
  if (tp2R < 1.5) return reject5("rr_too_low", { rr: tp2R });
  const stop = roundInstrumentPrice(market.symbol, price - sign * stopDistance), tp1 = roundInstrumentPrice(market.symbol, price + sign * stopDistance * tp1R), tp2 = roundInstrumentPrice(market.symbol, price + sign * stopDistance * tp2R);
  const risk = Math.abs(price - stop), reward = Math.abs(tp2 - price), rr = risk > 0 ? Number((reward / risk).toFixed(2)) : 0;
  if (!risk || rr < 1.45) return reject5("rr_too_low", { rr, risk });
  return { status: "candidate", direction, entry_low: roundInstrumentPrice(market.symbol, price - market.instrument.pointSize * 2), entry_high: roundInstrumentPrice(market.symbol, price + market.instrument.pointSize * 2), stop_loss: stop, tp1, tp2, risk_reward: rr, confidence_score: confidence, grade: confidence >= 85 ? "A+" : confidence >= 75 ? "A" : "B", reason: `${strategy.id} ${direction} research setup`, rejection_reason: "", score_breakdown: { research_only: true, strategy_id: strategy.id, strategy_version: strategy.version, session: market.session, asset_class: market.instrument.assetClass, ...evidence, ...market.evidence } };
}
var liquidSessions = ["LONDON", "NEW_YORK", "LONDON_NEW_YORK_OVERLAP"];
var forexSymbols = ["EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCAD"];
var ForexLondonBreakout = {
  id: "forex.london-breakout",
  version: "0.1.0-research",
  symbols: forexSymbols,
  timeframes: ["15m"],
  sessions: ["LONDON", "LONDON_NEW_YORK_OVERLAP"],
  evaluate(input) {
    const market = contextFor(input), blocked = preflight(this, input, market);
    if (blocked || !market) return blocked;
    const interval = timeframeMilliseconds(input.timeframe);
    const londonOpen = Date.parse(market.sessionMetadata.londonOpenAt ?? ""), dayStart = Date.parse(input.evaluated_at.slice(0, 10) + "T00:00:00Z");
    const prior = market.normalizedCandles.slice(0, -1).filter((row) => {
      const opened = Date.parse(row.open_time), closed = opened + interval;
      return opened >= dayStart && closed <= londonOpen;
    }).slice(-32);
    if (prior.length < 8) return reject5("range_incomplete", { asian_candles: prior.length });
    const high = Math.max(...prior.map((c) => c.high)), low = Math.min(...prior.map((c) => c.low)), last = market.currentClosedCandle, atr2 = market.indicators.atr14;
    const direction = last.close > high ? "buy" : last.close < low ? "sell" : null;
    if (!direction) return reject5("breakout_unconfirmed", { range_high: high, range_low: low });
    const extension = direction === "buy" ? last.close - high : low - last.close;
    const body = Math.abs(last.close - last.open);
    const bodyAtr = input.strategy_parameters?.bodyAtr ?? 0.45, extensionAtr = input.strategy_parameters?.extensionAtr ?? 0.9;
    if (body < atr2 * bodyAtr) return reject5("breakout_unconfirmed", { breakout_body_atr: body / atr2 });
    if (extension > atr2 * extensionAtr) return reject5("breakout_overextended", { extension_atr: extension / atr2 });
    const rangeSize = high - low;
    if (rangeSize <= 0 || rangeSize > atr2 * 8) return reject5("range_invalid", { range_atr: rangeSize / atr2 });
    return candidate(this, market, direction, Math.max(atr2 * 1.35, rangeSize * 0.25), 1.2, 1.9, 82, { asian_range_high: high, asian_range_low: low, asian_range_candles: prior.length, breakout_extension_atr: extension / atr2, closed_candle_confirmation: true });
  }
};
var ForexNewYorkContinuation = {
  id: "forex.new-york-continuation",
  version: "0.1.0-research",
  symbols: forexSymbols,
  timeframes: ["15m", "1h"],
  sessions: ["NEW_YORK", "LONDON_NEW_YORK_OVERLAP"],
  evaluate(input) {
    const market = contextFor(input), blocked = preflight(this, input, market);
    if (blocked || !market) return blocked;
    const last = market.currentClosedCandle, atr2 = market.indicators.atr14, recent = market.previousClosedCandles.slice(-12);
    if (market.trendState === "FLAT") return reject5("no_directional_structure");
    const direction = market.trendState === "UP" ? "buy" : "sell";
    const sessionMove = recent.length ? (last.close - recent[0].open) / atr2 : 0;
    const minimumMoveAtr = input.strategy_parameters?.minimumMoveAtr ?? 0.25, maximumMoveAtr = input.strategy_parameters?.maximumMoveAtr ?? 3.2;
    if (direction === "buy" && sessionMove <= minimumMoveAtr || direction === "sell" && sessionMove >= -minimumMoveAtr) return reject5("session_direction_conflict", { session_move_atr: sessionMove });
    if (Math.abs(sessionMove) > maximumMoveAtr) return reject5("move_exhausted", { session_move_atr: sessionMove });
    const confirms = direction === "buy" ? last.close > last.open && last.close > market.indicators.ema20 : last.close < last.open && last.close < market.indicators.ema20;
    if (!confirms) return reject5("continuation_unconfirmed");
    return candidate(this, market, direction, atr2 * 1.3, 1.15, 1.85, 80, { prior_direction: market.trendState, session_move_atr: sessionMove, continuation_confirmed: true });
  }
};
var ForexTrendPullback = {
  id: "forex.trend-pullback",
  version: "0.1.0-research",
  symbols: forexSymbols,
  timeframes: ["15m", "1h"],
  sessions: liquidSessions,
  evaluate(input) {
    const market = contextFor(input), blocked = preflight(this, input, market);
    if (blocked || !market) return blocked;
    if (market.trendState === "FLAT") return reject5("trend_not_established");
    if (market.pullbackState === "EXTENDED") return reject5("chase_extension");
    const direction = market.trendState === "UP" ? "buy" : "sell", last = market.currentClosedCandle, atr2 = market.indicators.atr14;
    const depth = Math.abs(last.close - market.indicators.ema20) / atr2;
    const maximumPullbackAtr = input.strategy_parameters?.maximumPullbackAtr ?? 0.8, stopAtr = input.strategy_parameters?.stopAtr ?? 1.4;
    if (depth > maximumPullbackAtr) return reject5("pullback_invalid", { pullback_depth_atr: depth });
    const momentum = direction === "buy" ? last.close > last.open && market.indicators.rsi14 >= 45 : last.close < last.open && market.indicators.rsi14 <= 55;
    if (!momentum) return reject5("momentum_unconfirmed", { rsi: market.indicators.rsi14 });
    const swing = direction === "buy" ? Math.min(...market.normalizedCandles.slice(-12).map((c) => c.low)) : Math.max(...market.normalizedCandles.slice(-12).map((c) => c.high));
    const stop = Math.max(atr2 * stopAtr, Math.abs(last.close - swing) + atr2 * 0.15);
    if (stop > atr2 * 4) return reject5("stop_too_wide", { stop_atr: stop / atr2 });
    return candidate(this, market, direction, stop, 1.2, 2.1, 84, { trend_state: market.trendState, pullback_depth_atr: depth, momentum_confirmed: true, swing_stop: swing });
  }
};

// supabase/functions/_shared/gold-volatility-breakout.ts
var GOLD_STRATEGY_ID = "gold.volatility-breakout";
var GOLD_STRATEGY_VERSION = "1.0.0";
var GOLD_EVALUATOR_ID = "evaluateGoldVolatilityBreakout";
var GOLD_CERTIFICATION_PROVENANCE = "FOREX_AND_GOLD_STRATEGY_AUTHENTICITY_20260730";
function fingerprint(evidence) {
  const input = JSON.stringify(Object.entries(evidence).sort(([a], [b]) => a.localeCompare(b)));
  let hash3 = 2166136261;
  for (let i = 0; i < input.length; i++) hash3 = Math.imul(hash3 ^ input.charCodeAt(i), 16777619);
  return `fnv1a32:${(hash3 >>> 0).toString(16).padStart(8, "0")}`;
}
function provenance(input, evidence) {
  const base = { strategy_id: GOLD_STRATEGY_ID, strategy_version: GOLD_STRATEGY_VERSION, evaluator_identity: GOLD_EVALUATOR_ID, certification: "MEASURED_RELEASE_REQUIRED", certification_provenance: GOLD_CERTIFICATION_PROVENANCE, symbol: input.symbol, instrument_class: "metal_gold", provider: "mt5", primary_timeframe: "15m", context_timeframe: "1h", ...evidence };
  return { ...base, deterministic_fingerprint: fingerprint(base) };
}
function reject6(input, reason, evidence = {}) {
  return { status: "rejected", direction: "none", entry_low: 0, entry_high: 0, stop_loss: 0, tp1: 0, tp2: 0, risk_reward: 0, confidence_score: 0, grade: "reject", reason, rejection_reason: reason, score_breakdown: provenance(input, { primary_failed_gate: reason, ...evidence }) };
}
function evaluateGoldVolatilityBreakout(input) {
  const context = input;
  if (input.symbol !== "XAUUSD") return reject6(input, "gold_symbol_not_supported", { received_symbol: input.symbol });
  if (input.market !== "forex") return reject6(input, "strategy_instrument_class_not_supported", { received_market: input.market });
  if (input.timeframe !== "15m") return reject6(input, "unsupported_timeframe", { received_timeframe: input.timeframe });
  if (input.candles.some((c) => c.symbol !== "XAUUSD" || !c.source.toLowerCase().startsWith("mt5"))) return reject6(input, "gold_provider_or_symbol_metadata_invalid");
  const market = buildForexMarketContext({ symbol: input.symbol, timeframe: input.timeframe, candles: input.candles, indicators: input.indicators, evaluatedAt: input.evaluated_at, spreadPrice: context.spread_price, provider: "mt5" });
  if (!market || market.instrument.assetClass !== "gold") return reject6(input, "strategy_instrument_class_not_supported");
  if (market.malformed) return reject6(input, "gold_malformed_candles");
  if (market.stale) return reject6(input, "stale_candles");
  if (market.normalizedCandles.length < 64) return reject6(input, "insufficient_candles", { candle_count: market.normalizedCandles.length });
  const session = forexSessionContext2(input.evaluated_at);
  if (!session.marketOpen) return reject6(input, session.weekend ? "gold_weekend_closed" : "gold_session_not_eligible");
  const evaluated = new Date(input.evaluated_at);
  if (evaluated.getUTCDay() === 5 && evaluated.getUTCHours() >= 20) return reject6(input, "gold_friday_close_risk");
  if (!["LONDON", "NEW_YORK", "LONDON_NEW_YORK_OVERLAP"].includes(market.session)) return reject6(input, "gold_session_not_eligible", { session: market.session });
  if (!market.spread.eligible) return reject6(input, "gold_spread_too_wide", { spread_pips: market.spread.spreadPips ?? -1 });
  const eventRisk = context.event_risk;
  if (eventRisk?.protection_required && !eventRisk.available) return reject6(input, "gold_event_risk_unavailable");
  if (eventRisk?.available && eventRisk.high_impact_usd) return reject6(input, "gold_event_risk_blocked");
  const rows = market.normalizedCandles, last = rows[rows.length - 1], follow = rows[rows.length - 2];
  const atr2 = input.indicators.atr14;
  if (!Number.isFinite(atr2) || atr2 <= market.instrument.pointSize * 10) return reject6(input, "gold_volatility_invalid");
  const box = rows.slice(-26, -2);
  const high = Math.max(...box.map((c) => c.high)), low = Math.min(...box.map((c) => c.low));
  const width2 = high - low, widthAtr = width2 / atr2;
  if (widthAtr < 0.8 || widthAtr > 5.5) return reject6(input, "gold_range_quality_failed", { range_width_atr: widthAtr });
  const avgRange = box.reduce((sum, c) => sum + c.high - c.low, 0) / box.length;
  const compression = avgRange / atr2;
  if (compression > 1.05) return reject6(input, "gold_compression_missing", { compression_ratio: compression });
  const buy = follow.close > high && last.close > high;
  const sell = follow.close < low && last.close < low;
  if (!buy && !sell) return reject6(input, "gold_setup_not_present", { range_high: high, range_low: low });
  const direction = buy ? "buy" : "sell";
  const boundary = buy ? high : low;
  const breakoutBody = Math.abs(follow.close - follow.open), breakoutRange = follow.high - follow.low;
  const displacement = Math.abs(follow.close - boundary) / atr2;
  const acceptance = Math.abs(last.close - boundary) / atr2;
  const adverseWick = buy ? follow.high - follow.close : follow.close - follow.low;
  if (breakoutRange <= 0 || adverseWick / breakoutRange > 0.48) return reject6(input, "gold_false_breakout", { wick_ratio: breakoutRange > 0 ? adverseWick / breakoutRange : 1 });
  const minimumBodyAtr = input.strategy_parameters?.minimumBodyAtr ?? 0.55;
  const minimumAcceptanceAtr = input.strategy_parameters?.minimumAcceptanceAtr ?? 0.08;
  if (breakoutBody / atr2 < minimumBodyAtr || displacement < 0.12 || acceptance < minimumAcceptanceAtr) return reject6(input, "gold_failed_follow_through", { breakout_body_atr: breakoutBody / atr2, displacement_atr: displacement, acceptance_atr: acceptance });
  const extension = Math.abs(last.close - input.indicators.ema20) / atr2;
  const climactic = Math.max(breakoutRange, last.high - last.low) / atr2;
  if (extension > 2.4 || displacement > 1.35 || climactic > 2.8) return reject6(input, "gold_exhaustion_detected", { extension_atr: extension, displacement_atr: displacement, climactic_range_atr: climactic });
  if (buy ? input.indicators.ema20 < input.indicators.ema50 : input.indicators.ema20 > input.indicators.ema50) return reject6(input, "gold_higher_timeframe_conflict");
  const price = last.close;
  const entryBuffer = Math.min(atr2 * 0.08, width2 * 0.04);
  const entry_low = roundInstrumentPrice("XAUUSD", price - entryBuffer), entry_high = roundInstrumentPrice("XAUUSD", price + entryBuffer);
  const structural = buy ? Math.min(boundary - atr2 * 0.18, follow.low - atr2 * 0.08) : Math.max(boundary + atr2 * 0.18, follow.high + atr2 * 0.08);
  const stopDistance = Math.max(Math.abs(price - structural), atr2 * 1.15, market.instrument.pointSize * 50);
  if (stopDistance > atr2 * 2.6) return reject6(input, "gold_stop_too_wide", { stop_atr: stopDistance / atr2 });
  const stop_loss = roundInstrumentPrice("XAUUSD", buy ? price - stopDistance : price + stopDistance);
  const tp1R = Math.max(1.25, Math.min(1.6, width2 / stopDistance));
  const tp2R = Math.max(2.05, Math.min(2.8, width2 * 1.25 / stopDistance));
  const tp1 = roundInstrumentPrice("XAUUSD", buy ? price + stopDistance * tp1R : price - stopDistance * tp1R);
  const tp2 = roundInstrumentPrice("XAUUSD", buy ? price + stopDistance * tp2R : price - stopDistance * tp2R);
  const sessionScore = market.session === "LONDON_NEW_YORK_OVERLAP" ? 100 : 82;
  const rangeScore = Math.max(0, 100 - Math.abs(widthAtr - 2.5) * 22), compressionScore = Math.max(0, 100 - compression * 70);
  const expansionScore = Math.min(100, breakoutBody / atr2 * 80), acceptanceScore = Math.min(100, acceptance * 130);
  const trendScore = 88, spreadScore = market.spread.spreadPips === null ? 65 : Math.max(0, 100 - market.spread.spreadPips * 8);
  const rrScore = Math.min(100, tp2R / 2.05 * 85), exhaustionPenalty = Math.max(0, extension - 1.5) * 18;
  const score = Math.round(Math.max(0, Math.min(100, rangeScore * 0.12 + compressionScore * 0.12 + expansionScore * 0.17 + acceptanceScore * 0.14 + trendScore * 0.12 + sessionScore * 0.09 + spreadScore * 0.07 + rrScore * 0.12 + 5 - exhaustionPenalty)));
  if (score < 74) return reject6(input, "confidence_too_low", { final_score: score });
  const evidence = provenance(input, { primary_failed_gate: "passed", direction, range_high: high, range_low: low, range_width_atr: widthAtr, compression_score: compressionScore, range_quality_score: rangeScore, volatility_expansion_score: expansionScore, breakout_acceptance_score: acceptanceScore, higher_timeframe_alignment_score: trendScore, session_quality_score: sessionScore, spread_quality_score: spreadScore, structure_clearance_score: acceptanceScore, reward_risk_score: rrScore, exhaustion_penalty: exhaustionPenalty, false_breakout_penalty: 0, event_risk_status: eventRisk?.available ? "clear" : "capability_unavailable_not_required", final_score: score, risk_distance: stopDistance, holding_profile: "intraday_4_to_16_bars" });
  return { status: "candidate", direction, entry_low, entry_high, stop_loss, tp1, tp2, risk_reward: Number(tp2R.toFixed(2)), confidence_score: score, grade: score >= 88 ? "A+" : score >= 80 ? "A" : "B", reason: `Gold volatility breakout ${direction}: accepted ${acceptance.toFixed(2)} ATR beyond a ${widthAtr.toFixed(2)} ATR compression range`, rejection_reason: "", score_breakdown: evidence };
}

// supabase/functions/_shared/strategy-plan.ts
var STRATEGY_PLAN_SCHEMA_VERSION = "strategy-plan/v1";
var STRATEGY_CONFIG_SCHEMA_VERSION = "strategy-config/v1";
var INDICATOR_ENGINE_VERSION = "indicator.root-v1/ema-rsi-atr";
function canonical2(value) {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonical2).join(",")}]`;
  return `{${Object.entries(value).sort(([a], [b]) => a.localeCompare(b)).map(([key, item]) => `${JSON.stringify(key)}:${canonical2(item)}`).join(",")}}`;
}
function stableFingerprint(value) {
  let hash3 = 0xcbf29ce484222325n;
  for (const byte of new TextEncoder().encode(canonical2(value))) {
    hash3 ^= BigInt(byte);
    hash3 = BigInt.asUintN(64, hash3 * 0x100000001b3n);
  }
  return `fnv1a64:${hash3.toString(16).padStart(16, "0")}`;
}
function clone(value) {
  return structuredClone(value);
}
function deepFreeze(value) {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    for (const item of Object.values(value)) deepFreeze(item);
    Object.freeze(value);
  }
  return value;
}
function timeframeMilliseconds2(timeframe) {
  const match = /^(\d+)(m|h|d)$/.exec(timeframe);
  if (!match) return null;
  return Number(match[1]) * (match[2] === "m" ? 6e4 : match[2] === "h" ? 36e5 : 864e5);
}
function isClosedBoundary(context) {
  const last = context.candles[context.candles.length - 1], interval = timeframeMilliseconds2(context.timeframe);
  return Boolean(last && interval && Date.parse(last.open_time) + interval <= Date.parse(context.evaluated_at));
}
function assetClass(definition2, legacy) {
  const explicit = String(legacy.score_breakdown.asset_class ?? "").toLowerCase();
  return definition2.id.startsWith("gold.") || explicit === "gold" ? "GOLD" : definition2.market === "forex" ? "FOREX" : "CRYPTO";
}
function trendState(indicators) {
  return indicators.ema20 > indicators.ema50 ? "UP" : indicators.ema20 < indicators.ema50 ? "DOWN" : Number.isFinite(indicators.ema20) && Number.isFinite(indicators.ema50) ? "FLAT" : "UNKNOWN";
}
var CATEGORY_BY_REASON = {
  unsupported_symbol: "ELIGIBILITY",
  unsupported_timeframe: "ELIGIBILITY",
  insufficient_candles: "DATA",
  invalid_candles: "DATA",
  malformed_candles: "DATA",
  stale_candles: "DATA",
  invalid_atr_or_price: "VOLATILITY",
  volatility_too_low: "VOLATILITY",
  volatility_too_high: "VOLATILITY",
  volatility_unstable: "VOLATILITY",
  trend_filter_failed: "TREND",
  trend_not_established: "TREND",
  no_directional_structure: "TREND",
  htf_trend_not_confirmed: "TREND",
  momentum_failed: "MOMENTUM",
  momentum_unconfirmed: "MOMENTUM",
  rsi_not_confirmed: "MOMENTUM",
  candle_body_too_small: "MOMENTUM",
  compression_not_ready: "STRUCTURE",
  breakout_not_confirmed: "STRUCTURE",
  breakout_unconfirmed: "STRUCTURE",
  pullback_not_ready: "STRUCTURE",
  pullback_invalid: "STRUCTURE",
  reclaim_not_confirmed: "STRUCTURE",
  spread_too_wide: "LIQUIDITY",
  provider_budget_exhausted: "DATA",
  rr_too_low: "RISK_REWARD",
  confidence_too_low: "CONFIDENCE",
  runtime_error: "EVALUATOR"
};
function rejectionCategory(reason) {
  return CATEGORY_BY_REASON[reason] ?? (reason ? "STRATEGY_SPECIFIC" : "NONE");
}
function qualificationLedger(definition2, context, legacy) {
  const primary = String(legacy.score_breakdown.primary_failed_gate ?? legacy.rejection_reason ?? (legacy.status === "candidate" ? "passed" : "rejected"));
  const gates = [
    { id: "closed_candle", category: "DATA", status: isClosedBoundary(context) ? "PASS" : "FAIL", reason: isClosedBoundary(context) ? "latest candle is closed at evaluation boundary" : "latest candle close is after evaluation boundary", source: "CONTEXT" },
    { id: "candle_integrity", category: "DATA", status: ["invalid_candles", "malformed_candles", "insufficient_candles", "stale_candles"].includes(primary) ? "FAIL" : "PASS", reason: ["invalid_candles", "malformed_candles", "insufficient_candles", "stale_candles"].includes(primary) ? primary : "evaluator accepted candle preflight", source: "EVALUATOR" },
    { id: "symbol_eligible", category: "ELIGIBILITY", status: primary === "unsupported_symbol" ? "FAIL" : "PASS", reason: primary === "unsupported_symbol" ? primary : "registry symbol eligibility passed", source: "CONFIG" },
    { id: "timeframe_eligible", category: "ELIGIBILITY", status: primary === "unsupported_timeframe" ? "FAIL" : "PASS", reason: primary === "unsupported_timeframe" ? primary : "registry timeframe eligibility passed", source: "CONFIG" },
    { id: "atr_valid", category: "VOLATILITY", status: Number.isFinite(context.indicators.atr14) && context.indicators.atr14 > 0 ? "PASS" : "FAIL", reason: Number.isFinite(context.indicators.atr14) && context.indicators.atr14 > 0 ? "ATR is finite and positive" : "ATR unavailable or invalid", observed: context.indicators.atr14, source: "CONTEXT" },
    { id: "liquidity_context", category: "LIQUIDITY", status: "UNKNOWN", reason: "authoritative liquidity context unavailable to strategy", source: "UNAVAILABLE" },
    { id: "news_context", category: "NEWS", status: "UNKNOWN", reason: "authoritative news context unavailable to strategy", source: "UNAVAILABLE" },
    { id: "risk_reward", category: "RISK_REWARD", status: dailyEvidence(legacy.score_breakdown) ? "NOT_APPLICABLE" : legacy.status === "candidate" ? "PASS" : primary === "rr_too_low" ? "FAIL" : "NOT_APPLICABLE", reason: dailyEvidence(legacy.score_breakdown) ? "Target-free regime/trailing exit; fixed risk/reward is not applicable" : legacy.status === "candidate" ? "risk/reward gate passed" : primary === "rr_too_low" ? primary : "evaluation rejected before risk/reward became the deciding gate", observed: legacy.risk_reward, required: definition2.config.min_rr, source: "EVALUATOR" },
    { id: "confidence", category: "CONFIDENCE", status: legacy.status === "candidate" ? "PASS" : ["confidence_too_low", "score_below_min"].includes(primary) ? "FAIL" : "NOT_APPLICABLE", reason: legacy.status === "candidate" ? "confidence gate passed" : ["confidence_too_low", "score_below_min"].includes(primary) ? primary : "evaluation rejected before confidence became the deciding gate", observed: legacy.confidence_score, required: definition2.config.min_score, source: "EVALUATOR" },
    { id: "evaluator_decision", category: CATEGORY_BY_REASON[primary] ?? "EVALUATOR", status: legacy.status === "candidate" ? "PASS" : "FAIL", reason: legacy.status === "candidate" ? "all evaluator gates passed" : primary, source: "EVALUATOR" }
  ];
  const already = new Set(gates.map((gate) => gate.id));
  for (const [key, value] of Object.entries(legacy.score_breakdown)) {
    if (already.has(key) || key === "primary_failed_gate" || !/_confirmed$|_ready$|_pass$|_gate$/.test(key) || typeof value !== "boolean") continue;
    gates.push({ id: key, category: /trend|ema|reclaim/.test(key) ? "TREND" : /momentum|rsi|body/.test(key) ? "MOMENTUM" : /atr|volatility/.test(key) ? "VOLATILITY" : "STRUCTURE", status: value ? "PASS" : legacy.status === "candidate" ? "NOT_APPLICABLE" : "FAIL", reason: value ? `${key} confirmed` : legacy.status === "candidate" ? `${key} was not required by the accepted evaluator path` : `${key} not confirmed`, observed: value, source: "EVALUATOR" });
  }
  return gates;
}
function managementIntent(definition2, maxBars) {
  if (definition2.id === DAILY_TREND_ID) return { break_even: "No break-even or partial-exit mutation.", trailing: "Raise protection to the greater of the existing stop and closed daily close minus 3 Wilder ATR14; apply from the following candle.", partial_exits: ["No fixed take-profit levels. One full virtual exit; no account sizing or execution authority."], cancel_conditions: ["Cancel if next-open entry gaps below the initial 2ATR protection.", "Missing/non-native SPOT daily history blocks evaluation."], time_exit: "Exit next open after EMA20 <= EMA50 or close < EMA200. No arbitrary bar-age liquidation; unfinished positions remain OPEN." };
  if (definition2.id.startsWith("crypto.team-")) return {
    break_even: "No break-even mutation in the tested signal contract.",
    trailing: "Static protective stop; no trailing in the tested signal contract.",
    partial_exits: ["One full-position signal target; no partial exits. Account quantities remain Phase-D owned."],
    cancel_conditions: ["Cancel unfilled invalid/expired entry plans; never infer a provider fill."],
    time_exit: `Virtual close after ${maxBars} native 15m bars; missing future candles remain unresolved.`
  };
  const scalp = definition2.id.includes("scalp");
  return {
    break_even: "Use the currently certified downstream protection policy; strategy does not authorize an independent level mutation.",
    trailing: "No strategy-specific trailing rule is encoded; downstream must record the applied protection policy.",
    partial_exits: ["TP1 and TP2 are the strategy-owned target levels; quantities remain downstream-owned."],
    cancel_conditions: ["Cancel if the entry plan expires before fill.", "Cancel if downstream qualification or risk authorization refuses the plan."],
    time_exit: `Exit or escalate under the existing downstream time-stop policy after ${maxBars} ${definition2.config.allowed_timeframes.join("/") || "eligible-timeframe"} bars; do not extend ${scalp ? "a scalp" : "the trade"} silently.`
  };
}
function createStrategyPlan(definition2, context, legacy, runtimeMs = null) {
  const direction = legacy.direction.toLowerCase();
  const action = legacy.status === "candidate" && direction === "buy" ? "BUY" : legacy.status === "candidate" && direction === "sell" ? "SELL" : "NO_TRADE";
  const rejection = legacy.rejection_reason || (legacy.status === "rejected" ? legacy.reason : "");
  const sources2 = [...new Set(context.candles.map((row) => row.source).filter(Boolean))];
  const last = context.candles[context.candles.length - 1] ?? null, first = context.candles[0] ?? null;
  const configHash = stableFingerprint(definition2.config);
  const expiresAt = action === "NO_TRADE" ? null : expiryFromBars(context.evaluated_at, context.timeframe, definition2.config.max_bars_in_trade);
  const evidence = clone(legacy.score_breakdown);
  const sessionEvidence = evidence.session ?? evidence.session_context;
  const session = typeof sessionEvidence === "string" || typeof sessionEvidence === "number" ? String(sessionEvidence) : "UNKNOWN";
  const warnings = ["liquidity_context_unknown", "news_context_unknown"];
  if (definition2.lifecycle !== "ENABLED") warnings.push("research_shadow_non_publishable");
  if (runtimeMs === null) warnings.push("runtime_duration_unavailable");
  const plan = {
    schema_version: STRATEGY_PLAN_SCHEMA_VERSION,
    identity: { strategy_id: definition2.id, strategy_name: definition2.legacyName, strategy_version: definition2.version, asset_class: assetClass(definition2, legacy), lifecycle: definition2.lifecycle, certification_status: definition2.certification ?? (definition2.lifecycle === "RESEARCH" ? "RESEARCH" : "PRODUCTION"), publication_mode: definition2.publicationMode ?? "LIVE" },
    provenance: { evaluation_id: stableFingerprint({ strategy: definition2.id, version: definition2.version, evaluated_at: context.evaluated_at, symbol: context.symbol, timeframe: context.timeframe, candle: last?.open_time ?? null, config: configHash }), evaluated_at: context.evaluated_at, config_version: STRATEGY_CONFIG_SCHEMA_VERSION, config_hash: configHash, measured_release_id: definition2.config.config_source?.startsWith("measured_release:") ? definition2.config.config_source.slice("measured_release:".length) : null, evaluated_parameters: clone(definition2.config.params), indicator_engine_version: INDICATOR_ENGINE_VERSION, market_data_source: sources2.length === 1 ? sources2[0] : sources2.length ? `mixed:${sources2.sort().join(",")}` : "unknown", candle_boundary: { first_open_time: first?.open_time ?? null, last_open_time: last?.open_time ?? null, candle_count: context.candles.length, closed_only: isClosedBoundary(context) } },
    market_context: { symbol: context.symbol.replace(/[^A-Za-z0-9]/g, "").toUpperCase(), timeframe: context.timeframe, market_regime: context.indicators.regime || "UNKNOWN", volatility_state: context.indicators.volatility_state || "UNKNOWN", trend_state: trendState(context.indicators), session, liquidity: { status: "UNKNOWN", value: null }, news: { status: "UNKNOWN", value: null } },
    decision: { action, qualified: action !== "NO_TRADE", reasons: rejection ? [rejection] : [legacy.reason] },
    qualification_ledger: qualificationLedger(definition2, context, legacy),
    entry_plan: { type: action === "NO_TRADE" ? "NONE" : "ZONE", zone: action === "NO_TRADE" ? null : { low: legacy.entry_low, high: legacy.entry_high }, expires_at: expiresAt, maximum_slippage: { status: "UNKNOWN", value: null, unit: "PERCENT" }, order_validity: action === "NO_TRADE" ? "NOT_APPLICABLE" : "UNTIL_ENTRY_EXPIRY" },
    risk_proposal: { initial_stop: action === "NO_TRADE" ? null : legacy.stop_loss, invalidation_thesis: action === "NO_TRADE" ? `No risk proposal: ${rejection || "strategy rejected"}` : `The strategy thesis is invalidated at the certified initial stop (${legacy.stop_loss}); basis: ${legacy.reason}.`, tp1: action === "NO_TRADE" || dailyEvidence(legacy.score_breakdown) ? null : legacy.tp1, tp2: action === "NO_TRADE" || dailyEvidence(legacy.score_breakdown) ? null : legacy.tp2, additional_targets: [], proposed_risk_reward: legacy.risk_reward, maximum_holding: action === "NO_TRADE" || dailyEvidence(legacy.score_breakdown) ? null : { bars: definition2.config.max_bars_in_trade, timeframe: context.timeframe } },
    management_intent: managementIntent(definition2, definition2.config.max_bars_in_trade),
    evidence: { indicators: clone(context.indicators), strategy_specific: evidence, explanation: legacy.reason },
    diagnostics: { warnings, runtime_ms: runtimeMs, confidence: legacy.confidence_score, grade: legacy.grade, evaluator_status: legacy.status === "candidate" ? "CANDIDATE" : rejection === "runtime_error" || legacy.score_breakdown.runtime_error === true ? "RUNTIME_ERROR" : "REJECTED", rejection_category: action === "NO_TRADE" ? rejectionCategory(legacy.rejection_reason || String(legacy.score_breakdown.primary_failed_gate ?? "")) : null }
  };
  return deepFreeze(plan);
}
function expiryFromBars(evaluatedAt, timeframe, bars) {
  const interval = timeframeMilliseconds2(timeframe), value = Date.parse(evaluatedAt);
  return interval && bars > 0 && Number.isFinite(value) ? new Date(value + interval * bars).toISOString() : null;
}

// supabase/functions/_shared/professional-strategies.ts
function finite(value) {
  return Number.isFinite(value) && value !== 0 ? value : null;
}
function normalizeSymbol2(value) {
  return value.replace(/[^A-Za-z0-9]/g, "").toUpperCase();
}
function staleCandles(context) {
  const last = context.candles[context.candles.length - 1];
  const match = /^(\d+)(m|h|d)$/.exec(context.timeframe);
  if (!last || !match) return true;
  const unit = match[2] === "m" ? 6e4 : match[2] === "h" ? 36e5 : 864e5;
  return Date.parse(context.evaluated_at) - Date.parse(last.open_time) > Number(match[1]) * unit * 3;
}
function reject7(reason, diagnostics = {}) {
  return { status: "rejected", direction: "none", entry_low: 0, entry_high: 0, stop_loss: 0, tp1: 0, tp2: 0, risk_reward: 0, confidence_score: 0, grade: "reject", reason, rejection_reason: reason, score_breakdown: { primary_failed_gate: reason, ...diagnostics } };
}
function expiryFromBars2(evaluatedAt, timeframe, bars) {
  const match = /^(\d+)(m|h|d)$/.exec(timeframe);
  if (!match || bars <= 0) return null;
  const unit = match[2] === "m" ? 6e4 : match[2] === "h" ? 36e5 : 864e5;
  const value = Date.parse(evaluatedAt);
  return Number.isFinite(value) ? new Date(value + Number(match[1]) * unit * bars).toISOString() : null;
}
function toProfessionalResult(definition2, context, legacy) {
  const direction = legacy.direction.toLowerCase();
  const decision = legacy.status === "candidate" && direction === "buy" ? "BUY" : legacy.status === "candidate" && direction === "sell" ? "SELL" : "NO_TRADE";
  const rejection = legacy.rejection_reason || (legacy.status === "rejected" ? legacy.reason : "");
  return {
    strategy_id: definition2.id,
    strategy_version: definition2.version,
    market: definition2.market,
    symbol: normalizeSymbol2(context.symbol),
    timeframe: context.timeframe,
    decision,
    rejection_reasons: rejection ? [rejection] : [],
    confidence: legacy.confidence_score,
    grade: legacy.grade,
    entry: legacy.status === "candidate" ? { low: legacy.entry_low, high: legacy.entry_high } : null,
    stop: finite(legacy.stop_loss),
    tp1: finite(legacy.tp1),
    tp2: finite(legacy.tp2),
    risk_reward: legacy.risk_reward,
    expires_at: expiryFromBars2(context.evaluated_at, context.timeframe, definition2.config.max_bars_in_trade),
    evidence: { ...legacy.score_breakdown },
    diagnostics: { lifecycle: definition2.lifecycle, publication_mode: definition2.publicationMode ?? "LIVE", certification: definition2.certification ?? "PRODUCTION", legacy_name: definition2.legacyName, legacy_status: legacy.status },
    legacy
  };
}
var StrategyDiagnostics = class {
  values = /* @__PURE__ */ new Map();
  row(definition2) {
    let row = this.values.get(definition2.id);
    if (!row) {
      row = { strategy_id: definition2.id, strategy_version: definition2.version, lifecycle: definition2.lifecycle, evaluations: 0, eligible_evaluations: 0, candidates: 0, buy_count: 0, sell_count: 0, no_trade_count: 0, published_signals: 0, rejections: 0, rejection_reasons: {}, runtime_failures: 0, last_evaluation: null, last_candidate: null, last_publication: null, session_exclusions: 0, stale_exclusions: 0, malformed_exclusions: 0, symbol_coverage: {}, timeframe_coverage: {} };
      this.values.set(definition2.id, row);
    }
    return row;
  }
  evaluated(definition2, at, eligible, symbol, timeframe) {
    const row = this.row(definition2);
    row.evaluations++;
    if (eligible) row.eligible_evaluations++;
    row.last_evaluation = at;
    row.symbol_coverage[symbol] = (row.symbol_coverage[symbol] ?? 0) + 1;
    row.timeframe_coverage[timeframe] = (row.timeframe_coverage[timeframe] ?? 0) + 1;
  }
  result(definition2, result, at) {
    const row = this.row(definition2);
    if (result.decision === "NO_TRADE") {
      row.no_trade_count++;
      row.rejections++;
      for (const reason of result.rejection_reasons) {
        row.rejection_reasons[reason] = (row.rejection_reasons[reason] ?? 0) + 1;
        if (reason === "session_not_eligible") row.session_exclusions++;
        if (reason === "stale_candles") row.stale_exclusions++;
        if (reason === "malformed_candles" || reason === "invalid_candles") row.malformed_exclusions++;
      }
    } else {
      row.candidates++;
      if (result.decision === "BUY") row.buy_count++;
      else row.sell_count++;
      row.last_candidate = at;
    }
  }
  failure(definition2, at) {
    const row = this.row(definition2);
    row.runtime_failures++;
    row.last_evaluation = at;
  }
  published(strategyId, at) {
    const row = this.values.get(strategyId);
    if (row) {
      row.published_signals++;
      row.last_publication = at;
    }
  }
  snapshot() {
    return Object.fromEntries([...this.values].map(([key, value]) => [key, { ...value, rejection_reasons: { ...value.rejection_reasons }, symbol_coverage: { ...value.symbol_coverage }, timeframe_coverage: { ...value.timeframe_coverage } }]));
  }
};
var ProfessionalStrategyRegistry = class {
  constructor(definitions, diagnostics = new StrategyDiagnostics()) {
    this.definitions = definitions;
    this.diagnostics = diagnostics;
    const ids = /* @__PURE__ */ new Set();
    for (const definition2 of definitions) {
      if (ids.has(definition2.id)) throw new Error(`duplicate_strategy_id:${definition2.id}`);
      ids.add(definition2.id);
    }
  }
  definitions;
  diagnostics;
  list() {
    return this.definitions;
  }
  eligible(definition2, context) {
    if (definition2.market !== context.market) return false;
    if (definition2.config.allowed_symbols.length && !definition2.config.allowed_symbols.map(normalizeSymbol2).includes(normalizeSymbol2(context.symbol))) return false;
    if (definition2.config.allowed_timeframes.length && !definition2.config.allowed_timeframes.includes(context.timeframe)) return false;
    return true;
  }
  evaluate(context) {
    const output = [];
    for (const definition2 of this.definitions) {
      if (definition2.market !== context.market) continue;
      const eligible = this.eligible(definition2, context);
      this.diagnostics.evaluated(definition2, context.evaluated_at, eligible, context.symbol, context.timeframe);
      if (!eligible) continue;
      const lifecycleEnabled = definition2.lifecycle === "ENABLED" && definition2.config.enabled;
      if (!lifecycleEnabled && !["SHADOW", "RESEARCH"].includes(definition2.lifecycle)) continue;
      try {
        const legacy = definition2.evaluate(context);
        const professional = toProfessionalResult(definition2, context, legacy);
        this.diagnostics.result(definition2, professional, context.evaluated_at);
        output.push({ definition: definition2, professional, plan: createStrategyPlan(definition2, context, legacy), publishable: lifecycleEnabled });
      } catch (error) {
        this.diagnostics.failure(definition2, context.evaluated_at);
        const message = error instanceof Error ? error.message : String(error ?? "unknown runtime error");
        const legacy = reject7("runtime_error", { runtime_error: true, error_message: message.slice(0, 300) });
        legacy.reason = `${definition2.legacyName} runtime error: ${message}`;
        output.push({ definition: definition2, professional: toProfessionalResult(definition2, context, legacy), plan: createStrategyPlan(definition2, context, legacy), publishable: lifecycleEnabled });
      }
    }
    return output;
  }
};
function researchCandidate(context, direction, confidence, stopMultiple, tp1R, tp2R, evidence) {
  const last = context.candles[context.candles.length - 1];
  const atr2 = context.indicators.atr14;
  const stop = direction === "buy" ? last.close - atr2 * stopMultiple : last.close + atr2 * stopMultiple;
  const risk = Math.abs(last.close - stop);
  return { status: "candidate", direction, entry_low: last.close * 0.9998, entry_high: last.close * 1.0002, stop_loss: stop, tp1: direction === "buy" ? last.close + risk * tp1R : last.close - risk * tp1R, tp2: direction === "buy" ? last.close + risk * tp2R : last.close - risk * tp2R, risk_reward: tp2R, confidence_score: confidence, grade: confidence >= 85 ? "A+" : confidence >= 75 ? "A" : "B", reason: `${evidence.strategy} research candidate`, rejection_reason: "", score_breakdown: { ...evidence, research_only: true } };
}
function evaluateCryptoTrendPullback(context) {
  if (!["15m", "1h"].includes(context.timeframe)) return reject7("unsupported_timeframe");
  if (context.candles.length < 55) return reject7("insufficient_candles");
  if (staleCandles(context)) return reject7("stale_candles");
  if (context.candles.some((c) => !Number.isFinite(c.close) || c.close <= 0 || c.high < c.low)) return reject7("invalid_candles");
  const last = context.candles[context.candles.length - 1], i = context.indicators;
  if (!Number.isFinite(i.atr14) || i.atr14 <= 0) return reject7("invalid_atr_or_price");
  const pullbackAtr = context.strategy_parameters?.pullbackAtr ?? 0.55;
  const stopAtr = context.strategy_parameters?.stopAtr ?? 1.65;
  const buy = i.ema20 > i.ema50 && last.close >= i.ema20 - i.atr14 * 0.35 && last.close <= i.ema20 + i.atr14 * pullbackAtr && i.rsi14 >= 45 && i.rsi14 <= 65;
  const sell = i.ema20 < i.ema50 && last.close <= i.ema20 + i.atr14 * 0.35 && last.close >= i.ema20 - i.atr14 * pullbackAtr && i.rsi14 <= 55 && i.rsi14 >= 35;
  if (!buy && !sell) return reject7("pullback_invalid", { strategy: "CryptoTrendPullback", ema20: i.ema20, ema50: i.ema50, rsi: i.rsi14 });
  return researchCandidate(context, buy ? "buy" : "sell", 80, stopAtr, 1, 1.75, { strategy: "CryptoTrendPullback", trend_aligned: true, pullback_confirmed: true, rsi: i.rsi14 });
}
function evaluateReversalExhaustion(context) {
  if (!["15m", "1h"].includes(context.timeframe)) return reject7("unsupported_timeframe");
  if (context.candles.length < 55) return reject7("insufficient_candles");
  if (staleCandles(context)) return reject7("stale_candles");
  if (context.candles.some((c) => !Number.isFinite(c.close) || c.close <= 0 || c.high < c.low)) return reject7("invalid_candles");
  const last = context.candles[context.candles.length - 1], i = context.indicators;
  if (!Number.isFinite(i.atr14) || i.atr14 <= 0) return reject7("invalid_atr_or_price");
  const rsiExtreme = context.strategy_parameters?.rsiExtreme ?? 32;
  const stopAtr = context.strategy_parameters?.stopAtr ?? 1.4;
  const buy = i.rsi14 <= rsiExtreme && last.close <= i.recent_low + i.atr14 * 0.4;
  const sell = i.rsi14 >= 100 - rsiExtreme && last.close >= i.recent_high - i.atr14 * 0.4;
  if (!buy && !sell) return reject7("exhaustion_unconfirmed", { strategy: "ReversalExhaustion", rsi: i.rsi14 });
  return researchCandidate(context, buy ? "buy" : "sell", 79, stopAtr, 1, 1.8, { strategy: "ReversalExhaustion", exhaustion_confirmed: true, rsi: i.rsi14 });
}

// supabase/functions/_shared/trading-domain/strategies.ts
function hash(value) {
  let h = 2166136261;
  for (let i = 0; i < value.length; i++) {
    h ^= value.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16).padStart(8, "0");
}
var CANONICAL_STRATEGY_PARAMETER_DEFAULTS = Object.freeze({
  "forex.london-breakout": Object.freeze({ bodyAtr: 0.45, extensionAtr: 0.9 }),
  "forex.new-york-continuation": Object.freeze({ minimumMoveAtr: 0.25, maximumMoveAtr: 3.2 }),
  "forex.trend-pullback": Object.freeze({ maximumPullbackAtr: 0.8, stopAtr: 1.4 }),
  "gold.volatility-breakout": Object.freeze({ minimumBodyAtr: 0.55, minimumAcceptanceAtr: 0.08 }),
  "crypto.trend-pullback": Object.freeze({ pullbackAtr: 0.55, stopAtr: 1.65 }),
  "crypto.reversal-exhaustion": Object.freeze({ rsiExtreme: 32, stopAtr: 1.4 })
});
function resolveCanonicalStrategyParameters(id2, supplied = {}) {
  const defaults = CANONICAL_STRATEGY_PARAMETER_DEFAULTS[id2];
  if (!defaults) throw new Error(`UNKNOWN_STRATEGY:${id2}`);
  for (const key of Object.keys(supplied)) if (!(key in defaults)) throw new Error(`INVALID_STRATEGY_PARAMETER:${id2}:${key}`);
  const resolved = Object.freeze({ ...defaults, ...supplied });
  if (Object.values(resolved).some((value) => !Number.isFinite(value) || value <= 0)) throw new Error(`INVALID_STRATEGY_PARAMETERS:${id2}:NON_POSITIVE`);
  if (id2 === "forex.new-york-continuation" && resolved.minimumMoveAtr >= resolved.maximumMoveAtr) throw new Error(`INVALID_STRATEGY_PARAMETERS:${id2}:MOVE_RANGE`);
  if (id2 === "crypto.reversal-exhaustion" && resolved.rsiExtreme >= 50) throw new Error(`INVALID_STRATEGY_PARAMETERS:${id2}:RSI_EXTREME`);
  return resolved;
}
function adapter(id2, version, legacy, input) {
  const view = input.market.views[input.market.primaryTimeframe], candles = view?.candles ?? [], indicator = canonicalIndicatorSnapshot(candles.map((c) => ({ open_time: c.openTime, open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume }))), last = candles[candles.length - 1], snapshot = { ema20: indicator.ema20, ema50: indicator.ema50, atr14: indicator.atr14, rsi14: indicator.rsi14, recent_high: indicator.recentHigh, recent_low: indicator.recentLow, avg_volume: indicator.averageVolume, body_size: indicator.body, atr_pct: last ? indicator.atr14 / last.close : 0, range_compression_ratio: indicator.atr14 ? indicator.range20 / indicator.atr14 : 0, momentum_score: 0, volatility_state: "CANONICAL", regime: "CANONICAL" }, evidence = { reasonCodes: [], indicators: indicator, observations: { marketViewVersion: input.market.version, warmupComplete: Boolean(view?.warmupComplete) } };
  if (!view?.warmupComplete || !last) return { decision: "NO_TRADE", strategyId: id2, strategyVersion: version, timestamp: input.market.asOf, reasonCodes: ["INSUFFICIENT_WARMUP"], evidence: { ...evidence, reasonCodes: ["INSUFFICIENT_WARMUP"] } };
  if (!input.market.session.open) return { decision: "NO_TRADE", strategyId: id2, strategyVersion: version, timestamp: input.market.asOf, reasonCodes: ["SESSION_CLOSED"], evidence: { ...evidence, reasonCodes: ["SESSION_CLOSED"] } };
  const crypto = id2.startsWith("crypto."), result = legacy({ symbol: input.market.symbol, market: crypto ? "crypto" : "forex", timeframe: input.market.primaryTimeframe, candles: candles.map((c) => ({ symbol: c.symbol, market_type: crypto ? "crypto" : "forex", timeframe: c.timeframe, open_time: c.openTime, open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume, source: c.datasetId })), indicators: snapshot, evaluated_at: input.market.asOf, strategy_parameters: resolveCanonicalStrategyParameters(id2, input.parameters) });
  if (result.status !== "candidate") {
    const codes = [result.rejection_reason || result.reason];
    return { decision: "NO_TRADE", strategyId: id2, strategyVersion: version, timestamp: input.market.asOf, reasonCodes: codes, evidence: { ...evidence, reasonCodes: codes, observations: { ...evidence.observations, ...result.score_breakdown } } };
  }
  const side = result.direction === "buy" ? "BUY" : "SELL", candidate2 = { id: `candidate_${hash(`${id2}|${version}|${input.market.symbol}|${input.market.asOf}|${side}`)}`, strategyId: id2, strategyVersion: version, configurationVersion: input.configurationVersion, timestamp: input.market.asOf, symbol: input.market.symbol, primaryTimeframe: input.market.primaryTimeframe, side, entry: (result.entry_low + result.entry_high) / 2, stop: result.stop_loss, targets: [result.tp1, result.tp2], score: result.confidence_score, evidence: { ...evidence, reasonCodes: [result.reason], observations: { ...evidence.observations, ...result.score_breakdown } } };
  return { decision: "CANDIDATE", strategyId: id2, strategyVersion: version, timestamp: input.market.asOf, candidate: candidate2, evidence: candidate2.evidence };
}
var FOREX = ["EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCAD"];
function definition(id2, market, instruments, primary, required, legacy) {
  return { id: id2, version: "1.0.0", status: "CANONICAL", market, instruments, requirements: { primaryTimeframe: primary, supportedPrimaryTimeframes: ["forex.new-york-continuation", "forex.trend-pullback"].includes(id2) ? ["15m", "1h"] : [primary], requiredTimeframes: required, warmupBars: 55, closeConfirmation: true }, parameterDefaults: CANONICAL_STRATEGY_PARAMETER_DEFAULTS[id2], reasonCodes: ["INSUFFICIENT_WARMUP", "SESSION_CLOSED", "NO_SETUP"], evaluate: (input) => adapter(id2, "1.0.0", legacy, input) };
}
var cryptoDefinition = (id2, legacy) => ({ id: id2, version: "0.1.0-research-frozen", status: "RESEARCH_ONLY", market: "CRYPTO", instruments: ["*"], requirements: { primaryTimeframe: "15m", requiredTimeframes: ["15m", "1h"], warmupBars: 55, closeConfirmation: true }, parameterDefaults: CANONICAL_STRATEGY_PARAMETER_DEFAULTS[id2], reasonCodes: ["INSUFFICIENT_WARMUP", "SESSION_CLOSED", "unsupported_timeframe", "pullback_invalid", "exhaustion_unconfirmed"], evaluate: (input) => adapter(id2, "0.1.0-research-frozen", legacy, input) });
var CANONICAL_STRATEGIES = { "forex.london-breakout": definition("forex.london-breakout", "FOREX", FOREX, "15m", ["15m", "1h"], (c) => ForexLondonBreakout.evaluate(c)), "forex.new-york-continuation": definition("forex.new-york-continuation", "FOREX", FOREX, "15m", ["15m", "1h"], (c) => ForexNewYorkContinuation.evaluate(c)), "forex.trend-pullback": definition("forex.trend-pullback", "FOREX", FOREX, "15m", ["15m", "1h"], (c) => ForexTrendPullback.evaluate(c)), "gold.volatility-breakout": definition("gold.volatility-breakout", "METALS", ["XAUUSD"], "15m", ["15m", "1h", "4h"], evaluateGoldVolatilityBreakout), "crypto.trend-pullback": cryptoDefinition("crypto.trend-pullback", evaluateCryptoTrendPullback), "crypto.reversal-exhaustion": cryptoDefinition("crypto.reversal-exhaustion", evaluateReversalExhaustion) };
var PRODUCTION_CANONICAL_IDS = Object.freeze(Object.values(CANONICAL_STRATEGIES).filter((s) => s.status === "CANONICAL").map((s) => s.id));
function strategyById(id2) {
  const found = CANONICAL_STRATEGIES[id2];
  if (!found) throw new Error(`UNKNOWN_STRATEGY:${id2}`);
  return found;
}

// supabase/functions/_shared/trading-domain/arbitrator.ts
function arbitrateCanonical(candidates, policy) {
  const ranked = [...candidates].sort((a, b) => b.score - a.score || a.id.localeCompare(b.id)), eligible = ranked.filter((c) => c.score >= policy.minimumScore && !policy.blockedSymbols.includes(c.symbol)), chosen = eligible[0] ?? null;
  return { version: "arbitration/v1", decision: chosen ? chosen.side : "NO_TRADE", chosen, rejected: ranked.filter((c) => c !== chosen).map((c) => ({ candidateId: c.id, reasonCodes: c.score < policy.minimumScore ? ["BELOW_SCORE"] : policy.blockedSymbols.includes(c.symbol) ? ["SYMBOL_BLOCKED"] : ["LOWER_RANK"] })), scoreBreakdown: Object.fromEntries(ranked.map((c) => [c.id, c.score])) };
}

// supabase/functions/_shared/trading-domain/production-eligibility-router.ts
var rank = Object.freeze({ FORWARD_VALIDATION_CANDIDATE: 1, FORWARD_VALIDATED: 2, PRODUCTION_APPROVED: 3 });

// supabase/functions/_shared/trading-domain/scanner-runtime.ts
var CANONICAL_SCANNER_AUTHORITY = "trading-domain.scanner-runtime/v1";
function stable3(value) {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stable3).join(",")}]`;
  return `{${Object.entries(value).sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => `${JSON.stringify(k)}:${stable3(v)}`).join(",")}}`;
}
function id(value) {
  let h = 2166136261;
  for (const c of stable3(value)) {
    h ^= c.charCodeAt(0);
    h = Math.imul(h, 16777619);
  }
  return `signal_${(h >>> 0).toString(16).padStart(8, "0")}`;
}
function immutable(value) {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    for (const child of Object.values(value)) immutable(child);
    Object.freeze(value);
  }
  return value;
}
function materializeCanonicalSignal(arbitration, asOf) {
  const chosen = arbitration.chosen;
  return chosen ? immutable({ version: "canonical-signal/v1", id: id({ candidateId: chosen.id, arbitration, asOf }), candidateId: chosen.id, decisionTimestamp: asOf, symbol: chosen.symbol, timeframe: chosen.primaryTimeframe, side: chosen.side, entry: chosen.entry, stop: chosen.stop, targets: [...chosen.targets], strategy: { id: chosen.strategyId, version: chosen.strategyVersion, configurationVersion: chosen.configurationVersion }, evidence: chosen.evidence, arbitration: { authority: "trading-domain.arbitrateCanonical", version: arbitration.version, reasonCodes: [], rejected: arbitration.rejected } }) : null;
}
function runCanonicalScanner(input) {
  const identities = input.strategies.map((request) => {
    const strategy = strategyById(request.strategyId);
    if (strategy.status !== "CANONICAL") throw new Error(`NON_PRODUCTION_STRATEGY:${strategy.id}`);
    return { strategyId: strategy.id, strategyVersion: strategy.version, configurationVersion: request.configurationVersion, parameters: resolveCanonicalStrategyParameters(strategy.id, request.parameters) };
  });
  const evaluations = identities.map((identity) => {
    const strategy = strategyById(identity.strategyId), requested = input.primaryTimeframe ?? strategy.requirements.primaryTimeframe;
    if (!(strategy.requirements.supportedPrimaryTimeframes ?? [strategy.requirements.primaryTimeframe]).includes(requested)) throw new Error(`UNSUPPORTED_PRIMARY_TIMEFRAME:${identity.strategyId}:${requested}`);
    const market = buildCanonicalMarketView({ symbol: input.symbol, asOf: input.asOf, primaryTimeframe: requested, requiredTimeframes: strategy.requirements.requiredTimeframes, warmupBars: strategy.requirements.warmupBars, datasets: input.datasets, session: input.session });
    return strategy.evaluate({ market, configurationVersion: identity.configurationVersion, parameters: identity.parameters });
  });
  const candidates = evaluations.flatMap((e) => e.decision === "CANDIDATE" ? [e.candidate] : []), arbitration = arbitrateCanonical(candidates, { minimumScore: input.minimumScore, blockedSymbols: input.blockedSymbols ?? [] }), signal = materializeCanonicalSignal(arbitration, input.asOf);
  return immutable({ version: "canonical-scanner-result/v1", authority: CANONICAL_SCANNER_AUTHORITY, asOf: input.asOf, identities, evaluations, candidates, arbitration, signal, outcome: signal ? "SIGNAL" : "NO_TRADE" });
}

// supabase/functions/_shared/trading-domain/phase-k.ts
var PHASE_K_LIMITS = Object.freeze({ symbols: 31, cryptoSymbols: 25, forexSymbols: 6, timeframes: 4, requests: 124, retries: 2, concurrency: 4 });
var PHASE_K_FOREX_UNIVERSE = Object.freeze(["EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCAD", "XAUUSD"]);

// supabase/functions/_shared/forex-production-strategies.ts
function compatibility(id2, context, parameters = {}) {
  const definition2 = CANONICAL_STRATEGIES[id2], tf = context.timeframe, datasetId = context.candles[0]?.source ?? "scanner-input", configurationVersion = `scanner-config/${id2}`, canonicalParameters = Object.fromEntries(Object.keys(definition2.parameterDefaults).filter((key) => parameters[key] !== void 0).map((key) => [key, parameters[key]])), run = runCanonicalScanner({ primaryTimeframe: tf, symbol: context.symbol, asOf: context.evaluated_at, datasets: { [tf]: context.candles.map((c2) => ({ datasetId, symbol: context.symbol, timeframe: tf, openTime: c2.open_time, open: c2.open, high: c2.high, low: c2.low, close: c2.close, volume: c2.volume })) }, strategies: [{ strategyId: id2, configurationVersion, parameters: canonicalParameters }], minimumScore: 0, session: { open: true, code: "SCANNER_SESSION" } }), result = run.evaluations[0], provenance2 = { canonical_domain: true, canonical_scanner_authority: run.authority, canonical_arbitration_authority: "trading-domain.arbitrateCanonical", strategy_version: definition2.version, configuration_version: configurationVersion, canonical_candidate_id: run.candidates[0]?.id ?? null, canonical_signal_id: run.signal?.id ?? null, certification: "MEASURED_RELEASE_REQUIRED" };
  if (result.decision === "NO_TRADE") return { status: "rejected", direction: "none", entry_low: 0, entry_high: 0, stop_loss: 0, tp1: 0, tp2: 0, risk_reward: 0, confidence_score: 0, grade: "reject", reason: result.reasonCodes[0] ?? "no_trade", rejection_reason: result.reasonCodes[0] ?? "no_trade", score_breakdown: provenance2 };
  const c = result.candidate, risk = Math.abs(c.entry - c.stop);
  return { status: "candidate", direction: c.side.toLowerCase(), entry_low: c.entry, entry_high: c.entry, stop_loss: c.stop, tp1: c.targets[0], tp2: c.targets[1], risk_reward: risk ? Math.abs(c.targets[1] - c.entry) / risk : 0, confidence_score: c.score, grade: c.score >= 85 ? "A+" : "A", reason: c.evidence.reasonCodes[0] ?? "canonical_candidate", rejection_reason: "", score_breakdown: { ...c.evidence.observations, ...provenance2 } };
}
var FOREX_PRODUCTION_EVALUATORS = { "forex.micro-scalper": (c, p = {}) => evalForexMicroScalper(c.candles, c.indicators, c.timeframe, p), "forex.swing-continuation": (c, p = {}) => evalForexSwingContinuation(c.candles, c.indicators, c.timeframe, p), "forex.london-breakout": (c, p = {}) => compatibility("forex.london-breakout", c, p), "forex.new-york-continuation": (c, p = {}) => compatibility("forex.new-york-continuation", c, p), "forex.trend-pullback": (c, p = {}) => compatibility("forex.trend-pullback", c, p), "gold.volatility-breakout": (c, p = {}) => compatibility("gold.volatility-breakout", c, p) };

// supabase/functions/_shared/hmm-regime-classifier.ts
function calculateGarmanKlassVolatility(candles) {
  if (!candles || candles.length === 0) return 3e-4;
  const CONST_2LN2_MINUS_1 = 2 * Math.LN2 - 1;
  let sumVar = 0;
  let count = 0;
  for (const c of candles.slice(-20)) {
    if (c.low <= 0 || c.open <= 0) continue;
    const logHL = Math.log(Math.max(c.high, c.low * 1.00001) / c.low);
    const logCO = Math.log(Math.max(c.close, 1e-8) / Math.max(c.open, 1e-8));
    const gkVar = 0.5 * (logHL * logHL) - CONST_2LN2_MINUS_1 * (logCO * logCO);
    sumVar += Math.max(0, gkVar);
    count++;
  }
  if (count === 0) return 3e-4;
  return Math.sqrt(sumVar / count);
}

// supabase/functions/_shared/crypto-production-evaluators.ts
var calcEMA2 = (v, p) => emaRootV1(v, p);
var calcATR2 = (c, p = 14) => atrRootV1(c, p);
var calcRSI2 = (v, p = 14) => rsiRootV1(v, p);
function calcMomentumScore2(v, lookback = 3) {
  const r = v.slice(-lookback - 1);
  let up = 0, dn = 0;
  for (let i = 1; i < r.length; i++) r[i] > r[i - 1] ? up++ : r[i] < r[i - 1] ? dn++ : 0;
  return (up - dn) / lookback;
}
var clampScore2 = (v) => Math.min(Math.max(Math.round(v), 0), 100);
var scoreGrade2 = (v) => v >= 85 ? "A+" : v >= 75 ? "A" : v >= 65 ? "B" : "reject";
var hasInvalidCandles2 = (c) => c.some((x) => ![x.open, x.high, x.low, x.close].every(Number.isFinite) || x.high < x.low || x.close <= 0);
var pctDistance2 = (a, b) => a > 0 && Number.isFinite(a) && Number.isFinite(b) ? parseFloat(Math.abs((b - a) / a * 100).toFixed(4)) : 0;
function strategyZeroReject2(reason) {
  return { status: "rejected", direction: "none", entry_low: 0, entry_high: 0, stop_loss: 0, tp1: 0, tp2: 0, risk_reward: 0, confidence_score: 0, grade: "reject", reason, rejection_reason: reason, score_breakdown: { primary_failed_gate: reason } };
}
function higherTimeframeTrendConfirmed(candles, direction) {
  if (!candles || candles.length < 55 || hasInvalidCandles2(candles)) return false;
  const closes = candles.map((c) => c.close), ema20 = calcEMA2(closes, 20), ema50 = calcEMA2(closes, 50), last = candles.at(-1);
  return direction === "buy" ? ema20 > ema50 && last.close > ema20 : ema20 < ema50 && last.close < ema20;
}
function directionalPressure(candles, direction, lookback = 3) {
  const slice = candles.slice(-Math.max(2, lookback));
  let aligned = 0;
  let pressure = 0;
  for (const candle of slice) {
    const range = Math.max(candle.high - candle.low, 0);
    const body = Math.abs(candle.close - candle.open);
    const directional = direction === "buy" ? candle.close > candle.open : candle.close < candle.open;
    if (directional) aligned++;
    pressure += range > 0 ? body / range * (directional ? 1 : -0.45) : 0;
  }
  return { confirmed: aligned >= Math.min(2, slice.length), aligned_count: aligned, pressure_score: parseFloat((pressure / Math.max(slice.length, 1)).toFixed(3)) };
}
function evalMicroScalper(candles, ind, timeframe, params, higherTimeframeCandles) {
  const rsi_buy_min = params.rsi_buy_min ?? 52, rsi_sell_max = params.rsi_sell_max ?? 48;
  const min_atr_pct = params.min_atr_pct ?? 0.05, max_atr_pct = params.max_atr_pct ?? 3;
  const min_body_atr = params.min_body_atr ?? 0.25, stop_atr_mult = params.stop_atr_mult ?? 1.2;
  const tp1_r = params.tp1_r ?? 0.9, tp2_r = params.tp2_r ?? 1.5;
  const min_rr = params.min_rr ?? 1.2, min_score = params.min_score ?? 75;
  const crypto_behavior_tuning = params.crypto_behavior_tuning === 1;
  const min_continuation_body_atr = params.min_continuation_body_atr ?? 0.15;
  const max_chase_extension_atr = params.max_chase_extension_atr ?? 1.8;
  const momentum_lookback = Math.max(1, Math.floor(params.momentum_lookback ?? 3));
  if (!["5m", "15m"].includes(timeframe)) return strategyZeroReject2("unsupported_timeframe");
  if (candles.length < 55) return strategyZeroReject2("insufficient_candles");
  if (hasInvalidCandles2(candles)) return strategyZeroReject2("invalid_candles");
  const last = candles[candles.length - 1];
  const price = last.close;
  const atr2 = ind.atr14;
  if (atr2 <= 0 || price <= 0 || !Number.isFinite(atr2) || !Number.isFinite(price)) return strategyZeroReject2("invalid_atr_or_price");
  const closes = candles.map((c) => c.close);
  const momentumRaw = calcMomentumScore2(closes, momentum_lookback);
  const bodyAtr = atr2 > 0 ? ind.body_size / atr2 : 0;
  const buyContext = (ind.ema20 > ind.ema50 ? 2 : 0) + (last.close > ind.ema20 ? 1 : 0) + (ind.rsi14 >= rsi_buy_min ? 1 : 0) + (momentumRaw > 0 ? 1 : 0);
  const sellContext = (ind.ema20 < ind.ema50 ? 2 : 0) + (last.close < ind.ema20 ? 1 : 0) + (ind.rsi14 <= rsi_sell_max ? 1 : 0) + (momentumRaw < 0 ? 1 : 0);
  const direction = buyContext >= sellContext ? "buy" : "sell";
  const directionalMomentum = direction === "buy" ? momentumRaw : -momentumRaw;
  const rsiConfirmed = direction === "buy" ? ind.rsi14 >= rsi_buy_min : ind.rsi14 <= rsi_sell_max;
  const trendConfirmed = direction === "buy" ? ind.ema20 > ind.ema50 && last.close > ind.ema20 : ind.ema20 < ind.ema50 && last.close < ind.ema20;
  const candleConfirmed = direction === "buy" ? last.close > last.open : last.close < last.open;
  const momentumConfirmed = directionalMomentum > 0.2;
  const pressure = directionalPressure(candles, direction, 3);
  const volatilityHealthy = ind.atr_pct >= min_atr_pct && ind.atr_pct <= max_atr_pct;
  const strongChop = ["range_chop", "ranging"].includes(ind.regime) && Math.abs(ind.momentum_score) < 0.3 && ind.range_compression_ratio > 0.78;
  const priceExtensionAtr = atr2 > 0 ? (direction === "buy" ? price - ind.ema20 : ind.ema20 - price) / atr2 : 0;
  const overextended = priceExtensionAtr > max_chase_extension_atr;
  const chaseRisk = crypto_behavior_tuning && overextended && bodyAtr < min_body_atr * 1.25 && directionalMomentum < 0.7;
  const fifteenMinuteTrendConfirmed = timeframe === "5m" ? higherTimeframeTrendConfirmed(higherTimeframeCandles, direction) : true;
  const smallBodyQualityWaiver = crypto_behavior_tuning && bodyAtr < min_body_atr && bodyAtr >= min_continuation_body_atr && trendConfirmed && fifteenMinuteTrendConfirmed && volatilityHealthy && rsiConfirmed && !overextended && !strongChop && pressure.confirmed && pressure.pressure_score >= 0.28;
  const continuationBodyConfirmed = bodyAtr >= min_body_atr || crypto_behavior_tuning && candleConfirmed && directionalMomentum >= 0.45 && bodyAtr >= min_continuation_body_atr || smallBodyQualityWaiver;
  const entry_low = price * 0.9998, entry_high = price * 1.0002;
  const stop_loss = direction === "buy" ? price - atr2 * stop_atr_mult : price + atr2 * stop_atr_mult;
  const tp1 = direction === "buy" ? price + atr2 * tp1_r : price - atr2 * tp1_r;
  const tp2 = direction === "buy" ? price + atr2 * tp2_r : price - atr2 * tp2_r;
  const risk = Math.abs(price - stop_loss), reward = Math.abs(tp2 - price);
  const risk_reward = risk > 0 ? parseFloat((reward / risk).toFixed(2)) : 0;
  const trendScore = trendConfirmed ? 75 : clampScore2(35 + Math.max(buyContext, sellContext) * 8);
  const momentumScore = clampScore2(Math.max(0, directionalMomentum) * 65 + Math.min(bodyAtr, 1) * 20 + (candleConfirmed ? 15 : 0));
  const rsiScore = direction === "buy" ? clampScore2(Math.min(Math.max((ind.rsi14 - 45) / Math.max(rsi_buy_min - 45, 1), 0), 1.25) * 80) : clampScore2(Math.min(Math.max((55 - ind.rsi14) / Math.max(55 - rsi_sell_max, 1), 0), 1.25) * 80);
  const bodyScore = smallBodyQualityWaiver ? 65 : clampScore2(Math.min(bodyAtr / Math.max(min_body_atr, 0.01), 1.25) * 80);
  let volatilityScore = 85;
  if (ind.atr_pct < min_atr_pct) volatilityScore = clampScore2(ind.atr_pct / Math.max(min_atr_pct, 0.01) * 55);
  else if (ind.atr_pct > max_atr_pct) volatilityScore = clampScore2(Math.max(20, 80 - (ind.atr_pct - max_atr_pct) / Math.max(max_atr_pct, 0.01) * 80));
  const rrScore = clampScore2(Math.min(risk_reward / Math.max(min_rr, 0.01), 1.5) * 66);
  let primaryFailedGate = "";
  if (ind.atr_pct < min_atr_pct) primaryFailedGate = "volatility_too_low";
  else if (ind.atr_pct > max_atr_pct) primaryFailedGate = "volatility_too_high";
  else if (!continuationBodyConfirmed) primaryFailedGate = "candle_body_too_small";
  else if (timeframe === "5m" && !fifteenMinuteTrendConfirmed) primaryFailedGate = "htf_trend_not_confirmed";
  else if (!trendConfirmed || !rsiConfirmed) primaryFailedGate = "rsi_not_confirmed";
  else if (!momentumConfirmed || !pressure.confirmed || chaseRisk || strongChop) primaryFailedGate = "momentum_failed";
  else if (risk_reward < min_rr) primaryFailedGate = "rr_too_low";
  const finalScore = clampScore2(trendScore * 0.24 + momentumScore * 0.22 + rsiScore * 0.18 + bodyScore * 0.12 + volatilityScore * 0.12 + rrScore * 0.12);
  if (!primaryFailedGate && finalScore < min_score) primaryFailedGate = "confidence_too_low";
  const rawRejectionReason = primaryFailedGate || "passed";
  const score_breakdown = {
    primary_failed_gate: rawRejectionReason,
    raw_rejection_reason: rawRejectionReason,
    strategy_config_loaded: true,
    timeframe_allowed: true,
    evaluator_called: true,
    raw_evaluator_status: primaryFailedGate ? "failed" : "passed",
    score_gate: finalScore >= min_score ? "passed" : "failed",
    rr_gate: risk_reward >= min_rr ? "passed" : "failed",
    distance_guard: "pending",
    arbitration: "pending",
    duplicate_guard: "pending",
    signal_insert: "pending",
    telegram_eligibility: "pending",
    min_score,
    required_score: min_score,
    min_rr,
    stop_atr_mult,
    tp1_r,
    tp2_r,
    min_body_atr,
    required_min_body_atr: min_body_atr,
    rsi_buy_min,
    rsi_sell_max,
    rsi_threshold: direction === "buy" ? rsi_buy_min : rsi_sell_max,
    max_bars_in_trade: params.max_bars_in_trade ?? (timeframe === "5m" ? 30 : 24),
    momentum_lookback,
    min_atr_pct,
    max_atr_pct,
    crypto_behavior_tuning,
    trend_score: trendScore,
    rsi_score: rsiScore,
    momentum_score: momentumScore,
    candle_body_score: bodyScore,
    candle_body_ratio: parseFloat(bodyAtr.toFixed(3)),
    volatility_score: volatilityScore,
    rr_score: rrScore,
    direction_basis: direction === "buy" ? buyContext : sellContext,
    buy_context: buyContext,
    sell_context: sellContext,
    trend_context: `${direction}:ema20_${direction === "buy" ? ind.ema20 > ind.ema50 ? "above" : "not_above" : ind.ema20 < ind.ema50 ? "below" : "not_below"}_ema50:price_${direction === "buy" ? last.close > ind.ema20 ? "above" : "not_above" : last.close < ind.ema20 ? "below" : "not_below"}_ema20`,
    rsi: parseFloat(ind.rsi14.toFixed(2)),
    atr_pct: parseFloat(ind.atr_pct.toFixed(4)),
    body_atr: parseFloat(bodyAtr.toFixed(3)),
    continuation_body_confirmed: continuationBodyConfirmed,
    small_body_quality_waiver: smallBodyQualityWaiver,
    directional_pressure_confirmed: pressure.confirmed,
    directional_pressure_aligned_count: pressure.aligned_count,
    directional_pressure_score: pressure.pressure_score,
    fifteen_minute_trend_confirmed: fifteenMinuteTrendConfirmed,
    volatility_healthy: volatilityHealthy,
    strong_chop: strongChop,
    overextended,
    price_extension_atr: parseFloat(priceExtensionAtr.toFixed(3)),
    chase_risk: chaseRisk,
    rr: risk_reward,
    stop_distance_pct: pctDistance2(price, stop_loss),
    tp1_distance_pct: pctDistance2(price, tp1),
    tp2_distance_pct: pctDistance2(price, tp2),
    final_score: finalScore
  };
  const grade2 = scoreGrade2(finalScore);
  const reason = `MicroScalper ${direction}: rsi=${ind.rsi14.toFixed(1)}, momentum=${directionalMomentum.toFixed(2)}, body=${bodyAtr.toFixed(2)} ATR, rr=${risk_reward.toFixed(2)}R, score=${finalScore}`;
  if (primaryFailedGate) {
    return { status: "rejected", direction, entry_low, entry_high, stop_loss, tp1, tp2, risk_reward, confidence_score: finalScore, grade: "reject", reason, rejection_reason: primaryFailedGate, score_breakdown };
  }
  return { status: "candidate", direction, entry_low, entry_high, stop_loss, tp1, tp2, risk_reward, confidence_score: finalScore, grade: grade2, reason, rejection_reason: "", score_breakdown };
}
function evalQuickScalp(candles, ind, timeframe, params) {
  if (!["5m", "15m"].includes(timeframe)) return strategyZeroReject2("unsupported_timeframe");
  if (candles.length < 55) return strategyZeroReject2("insufficient_candles");
  if (hasInvalidCandles2(candles)) return strategyZeroReject2("invalid_candles");
  const last = candles[candles.length - 1];
  const prev = candles[candles.length - 2] ?? last;
  const price = last.close;
  const atr2 = ind.atr14;
  if (atr2 <= 0 || price <= 0) return strategyZeroReject2("invalid_atr_or_price");
  const minScore = params.min_score ?? 82;
  const minRr = params.min_rr ?? 1.15;
  const maxBars = params.max_bars_in_trade ?? (timeframe === "5m" ? 9 : 4);
  const stopAtr = params.stop_atr_mult ?? 0.95;
  const tp1R = params.tp1_r ?? 0.55;
  const tp2R = params.tp2_r ?? 1.15;
  const direction = ind.ema20 >= ind.ema50 && last.close >= prev.close ? "buy" : "sell";
  const candleOk = direction === "buy" ? last.close > last.open : last.close < last.open;
  const emaOk = direction === "buy" ? last.close > ind.ema20 && ind.ema20 >= ind.ema50 : last.close < ind.ema20 && ind.ema20 <= ind.ema50;
  const closes = candles.map((c) => c.close);
  const mom1 = calcMomentumScore2(closes, 1);
  const mom3 = calcMomentumScore2(closes, 3);
  const directionalMomentum = direction === "buy" ? mom3 : -mom3;
  const accelerating = direction === "buy" ? mom1 > mom3 * 0.45 : -mom1 > -mom3 * 0.45;
  const volumeExpansion = ind.avg_volume > 0 ? last.volume / ind.avg_volume : 0;
  const bodyAtr = Math.abs(last.close - last.open) / atr2;
  const rangeAtr = (last.high - last.low) / atr2;
  const extensionAtr = direction === "buy" ? (price - ind.ema20) / atr2 : (ind.ema20 - price) / atr2;
  const spreadProxy = price > 0 ? (last.high - last.low) / price * 100 : 0;
  const entry_low = price * 0.9999, entry_high = price * 1.0001;
  const stop_loss = direction === "buy" ? price - atr2 * stopAtr : price + atr2 * stopAtr;
  const tp1 = direction === "buy" ? price + atr2 * tp1R : price - atr2 * tp1R;
  const tp2 = direction === "buy" ? price + atr2 * tp2R : price - atr2 * tp2R;
  const risk = Math.abs(price - stop_loss), reward = Math.abs(tp2 - price);
  const risk_reward = risk > 0 ? parseFloat((reward / risk).toFixed(2)) : 0;
  const volumeScore = clampScore2(Math.min(volumeExpansion / 1.45, 1.25) * 80);
  const liquidityScore = clampScore2(ind.avg_volume > 0 ? 82 : 35);
  const emaScore = emaOk ? 86 : 35;
  const momentumScore = clampScore2(Math.max(0, directionalMomentum) * 70 + (accelerating ? 18 : 0) + (candleOk ? 12 : 0));
  const atrScore = clampScore2(ind.atr_pct >= 0.12 && ind.atr_pct <= 2.5 ? 84 : ind.atr_pct < 0.12 ? 30 : 58);
  const impulseScore = clampScore2(Math.min(bodyAtr / 0.45, 1.2) * 54 + Math.min(rangeAtr / 1.1, 1.2) * 26 + (extensionAtr < 1.05 ? 18 : 0));
  const finalScore = clampScore2(volumeScore * 0.18 + liquidityScore * 0.12 + emaScore * 0.18 + momentumScore * 0.24 + atrScore * 0.14 + impulseScore * 0.14);
  let primaryFailedGate = "";
  if (volumeExpansion < 1.15) primaryFailedGate = "volume_expansion_failed";
  else if (!emaOk) primaryFailedGate = "ema_alignment_failed";
  else if (!candleOk || !accelerating || directionalMomentum < 0.25) primaryFailedGate = "momentum_acceleration_failed";
  else if (ind.atr_pct < 0.12) primaryFailedGate = "dead_market_rejected";
  else if (extensionAtr > 1.15) primaryFailedGate = "late_entry_overextended";
  else if (spreadProxy > 1.6) primaryFailedGate = "spread_quality_failed";
  else if (risk_reward < minRr) primaryFailedGate = "rr_too_low";
  else if (finalScore < minScore) primaryFailedGate = "confidence_too_low";
  const raw = primaryFailedGate || "passed";
  const score_breakdown = {
    primary_failed_gate: raw,
    raw_rejection_reason: raw,
    evaluator_called: true,
    volume_expansion_score: volumeScore,
    liquidity_score: liquidityScore,
    ema_alignment_score: emaScore,
    momentum_acceleration_score: momentumScore,
    atr_expansion_score: atrScore,
    impulse_quality_score: impulseScore,
    spread_quality_score: clampScore2(100 - spreadProxy * 45),
    price_extension_atr: parseFloat(extensionAtr.toFixed(3)),
    body_atr: parseFloat(bodyAtr.toFixed(3)),
    volume_expansion: parseFloat(volumeExpansion.toFixed(3)),
    max_bars_in_trade: maxBars,
    no_entry_timeout_bars: timeframe === "5m" ? 3 : 2,
    early_cancellation_logic: "cancel_if_momentum_or_volume_fails_before_entry",
    stale_setup_detection: "extension_gt_1.15_atr_or_no_entry_timeout",
    momentum_failure_exit: "exit_if_directional_momentum_turns_negative",
    volatility_collapse_exit: "exit_if_atr_pct_below_0.12",
    trend_failure_exit: "exit_if_ema20_alignment_lost"
  };
  const reason = primaryFailedGate ? `QuickScalp rejected: ${primaryFailedGate}` : `QuickScalp ${direction}: volume expansion, EMA alignment, momentum acceleration, ATR expansion and impulse quality confirmed.`;
  const grade2 = finalScore >= 90 ? "A+" : finalScore >= 82 ? "A" : finalScore >= 75 ? "B" : "C";
  return { status: primaryFailedGate ? "rejected" : "candidate", direction, entry_low, entry_high, stop_loss, tp1, tp2, risk_reward, confidence_score: finalScore, grade: primaryFailedGate ? "reject" : grade2, reason, rejection_reason: primaryFailedGate, score_breakdown };
}
function evalCompressionBreakout(candles, ind, timeframe, params) {
  const box_lookback = Math.max(10, Math.floor(params.box_lookback ?? 36));
  const min_box_bars = Math.max(5, Math.floor(params.min_box_bars ?? 8));
  const max_box_atr_range = params.max_box_atr_range ?? 8;
  const atr_expansion_lookback = Math.max(5, Math.floor(params.atr_expansion_lookback ?? 48));
  const min_atr_expansion = params.min_atr_expansion ?? 0.95;
  const breakout_buffer_atr = params.breakout_buffer_atr ?? 0.05;
  const momentum_lookback = Math.max(1, Math.floor(params.momentum_lookback ?? 3));
  const stop_atr_mult = params.stop_atr_mult ?? 1.1;
  const tp1_r = params.tp1_r ?? 1.2;
  const tp2_r = params.tp2_r ?? 2.2;
  const min_rr = params.min_rr ?? 1.3;
  const min_score = params.min_score ?? 72;
  const crypto_behavior_tuning = params.crypto_behavior_tuning === 1;
  const atr_len = Math.max(2, Math.floor(params.atr_len ?? 14));
  const rsi_len = Math.max(2, Math.floor(params.rsi_len ?? 14));
  const ema_fast = Math.max(2, Math.floor(params.ema_fast ?? 20));
  const ema_slow = Math.max(ema_fast + 1, Math.floor(params.ema_slow ?? 50));
  const max_late_breakout_atr = params.max_late_breakout_atr ?? 1.45;
  if (!["15m", "1h"].includes(timeframe)) return strategyZeroReject2("unsupported_timeframe");
  const minLen = Math.max(box_lookback + 5, atr_expansion_lookback + 2, ema_slow + 5, atr_len + 2, rsi_len + 2, 60);
  if (candles.length < minLen) return strategyZeroReject2("insufficient_candles");
  if (hasInvalidCandles2(candles)) return strategyZeroReject2("invalid_candles");
  const closes = candles.map((c) => c.close);
  const last = candles[candles.length - 1];
  const price = last.close;
  const atr2 = calcATR2(candles, atr_len);
  const rsi2 = calcRSI2(closes, rsi_len);
  const emaFast = calcEMA2(closes, ema_fast);
  const emaSlow = calcEMA2(closes, ema_slow);
  if (atr2 <= 0 || price <= 0 || !Number.isFinite(atr2) || !Number.isFinite(price)) return strategyZeroReject2("invalid_atr_or_price");
  const boxSlice = candles.slice(-(box_lookback + 1), -1);
  if (boxSlice.length < min_box_bars) return strategyZeroReject2("insufficient_candles");
  const boxHigh = Math.max(...boxSlice.map((c) => c.high));
  const boxLow = Math.min(...boxSlice.map((c) => c.low));
  const boxRange = boxHigh - boxLow;
  const recentCompressionSlice = boxSlice.slice(-Math.min(Math.max(min_box_bars, 12), boxSlice.length));
  const recentBoxHigh = Math.max(...recentCompressionSlice.map((c) => c.high));
  const recentBoxLow = Math.min(...recentCompressionSlice.map((c) => c.low));
  const recentBoxRange = recentBoxHigh - recentBoxLow;
  if (boxRange <= 0 || !Number.isFinite(boxRange)) return strategyZeroReject2("invalid_atr_or_price");
  const buffer = atr2 * breakout_buffer_atr;
  const effectiveBoxHigh = crypto_behavior_tuning && recentBoxRange > 0 && recentBoxRange < boxRange ? recentBoxHigh : boxHigh;
  const effectiveBoxLow = crypto_behavior_tuning && recentBoxRange > 0 && recentBoxRange < boxRange ? recentBoxLow : boxLow;
  const breakoutDistUp = last.close - effectiveBoxHigh;
  const breakoutDistDn = effectiveBoxLow - last.close;
  const closeOutsideUp = breakoutDistUp > 0 && last.close > last.open;
  const closeOutsideDn = breakoutDistDn > 0 && last.close < last.open;
  const breakoutUp = breakoutDistUp > buffer && last.close > last.open;
  const breakoutDn = breakoutDistDn > buffer && last.close < last.open;
  const priorBreakoutSlice = candles.slice(-3, -1);
  const priorBreakoutUp = priorBreakoutSlice.some((c) => c.close > effectiveBoxHigh + buffer && c.close > c.open);
  const priorBreakoutDn = priorBreakoutSlice.some((c) => c.close < effectiveBoxLow - buffer && c.close < c.open);
  const retestHoldUp = crypto_behavior_tuning && priorBreakoutUp && last.low <= effectiveBoxHigh + atr2 * 0.22 && last.close > effectiveBoxHigh && last.close >= last.open;
  const retestHoldDn = crypto_behavior_tuning && priorBreakoutDn && last.high >= effectiveBoxLow - atr2 * 0.22 && last.close < effectiveBoxLow && last.close <= last.open;
  const earlyBreakoutUp = crypto_behavior_tuning && closeOutsideUp && last.high - last.low > atr2 * min_atr_expansion;
  const earlyBreakoutDn = crypto_behavior_tuning && closeOutsideDn && last.high - last.low > atr2 * min_atr_expansion;
  const direction = breakoutUp || earlyBreakoutUp || retestHoldUp ? "buy" : breakoutDn || earlyBreakoutDn || retestHoldDn ? "sell" : last.close >= (boxHigh + boxLow) / 2 ? "buy" : "sell";
  const breakoutConfirmed = breakoutUp || breakoutDn || earlyBreakoutUp || earlyBreakoutDn || retestHoldUp || retestHoldDn;
  const breakoutDist = direction === "buy" ? Math.max(0, breakoutDistUp) : Math.max(0, breakoutDistDn);
  const breakoutDistanceAtr = breakoutDist / atr2;
  const boxBarTol = params.box_bar_tolerance ?? 15e-4;
  const barsInside = boxSlice.filter((c) => c.high <= boxHigh * (1 + boxBarTol) && c.low >= boxLow * (1 - boxBarTol)).length;
  const boxRangeAtr = boxRange / atr2;
  const recentBoxRangeAtr = recentBoxRange / atr2;
  const insideRatio = barsInside / Math.max(boxSlice.length, 1);
  const strictCompressionReady = boxSlice.length >= min_box_bars && barsInside >= min_box_bars && boxRangeAtr <= max_box_atr_range;
  const rangeTightness = max_box_atr_range > 0 ? Math.max(0, Math.min(1, 1 - boxRangeAtr / Math.max(max_box_atr_range * 1.35, 0.01))) : 0;
  const recentRangeTightness = max_box_atr_range > 0 ? Math.max(0, Math.min(1, 1 - recentBoxRangeAtr / Math.max(max_box_atr_range * 1.45, 0.01))) : 0;
  const compressionScore = clampScore2(insideRatio * 35 + Math.max(rangeTightness, recentRangeTightness) * 65);
  const rangeContracted = recentBoxRange > 0 && boxRange > 0 ? recentBoxRange <= boxRange * 0.72 : false;
  const nearCompressionReady = crypto_behavior_tuning && boxSlice.length >= min_box_bars && barsInside >= min_box_bars * 0.65 && (boxRangeAtr <= max_box_atr_range * 1.35 || recentBoxRangeAtr <= max_box_atr_range * 1.45 || rangeContracted) && compressionScore >= 45;
  const compressionReady = strictCompressionReady || nearCompressionReady && breakoutConfirmed;
  const histSlice = candles.slice(-(atr_expansion_lookback + 1), -1);
  const avgBarRange = histSlice.length > 0 ? histSlice.reduce((sum, c) => sum + (c.high - c.low), 0) / histSlice.length : 0;
  const curBarRange = last.high - last.low;
  const atrExpansionRatio = avgBarRange > 0 ? curBarRange / avgBarRange : 1;
  const atrExpansionScore = clampScore2(Math.min(1.4, atrExpansionRatio / Math.max(min_atr_expansion, 0.01)) * 70);
  const breakoutScore = clampScore2((breakoutConfirmed ? 45 : 0) + Math.min(1, breakoutDistanceAtr / Math.max(breakout_buffer_atr * 4, 0.25)) * 55);
  const momentum = calcMomentumScore2(closes, momentum_lookback);
  const bodyAtr = Math.abs(last.close - last.open) / atr2;
  const directionMomentum = direction === "buy" ? momentum : -momentum;
  const rsiDirectional = direction === "buy" ? Math.max(0, (rsi2 - 45) / 20) : Math.max(0, (55 - rsi2) / 20);
  const emaDirectional = direction === "buy" ? emaFast >= emaSlow ? 1 : 0.45 : emaFast <= emaSlow ? 1 : 0.45;
  const candleBodyScore = clampScore2(Math.min(bodyAtr, 1.25) * 80);
  const momentumScore = clampScore2(Math.max(0, directionMomentum) * 45 + Math.min(bodyAtr, 1) * 30 + Math.min(rsiDirectional, 1) * 15 + emaDirectional * 10);
  let volatilityScore = 80;
  if (ind.atr_pct < 0.08) volatilityScore = 25;
  else if (ind.atr_pct < 0.15) volatilityScore = 55;
  else if (ind.atr_pct > 5) volatilityScore = 30;
  else if (ind.atr_pct > 3.5) volatilityScore = 55;
  let entry_low, entry_high, stop_loss, tp1, tp2;
  if (direction === "buy") {
    entry_low = breakoutConfirmed ? Math.min(effectiveBoxHigh, price * 0.9995) : effectiveBoxHigh;
    entry_high = breakoutConfirmed ? Math.max(price, effectiveBoxHigh + atr2 * 0.25) : effectiveBoxHigh + atr2 * 0.25;
    stop_loss = crypto_behavior_tuning ? Math.min(effectiveBoxLow - atr2 * 0.2, price - atr2 * stop_atr_mult) : effectiveBoxLow - atr2 * stop_atr_mult;
    const riskForTargets = Math.abs(price - stop_loss);
    tp1 = crypto_behavior_tuning ? price + riskForTargets * tp1_r : price + atr2 * tp1_r;
    tp2 = crypto_behavior_tuning ? price + riskForTargets * tp2_r : price + atr2 * tp2_r;
  } else {
    entry_low = breakoutConfirmed ? Math.min(price, effectiveBoxLow - atr2 * 0.25) : effectiveBoxLow - atr2 * 0.25;
    entry_high = breakoutConfirmed ? Math.max(effectiveBoxLow, price * 1.0005) : effectiveBoxLow;
    stop_loss = crypto_behavior_tuning ? Math.max(effectiveBoxHigh + atr2 * 0.2, price + atr2 * stop_atr_mult) : effectiveBoxHigh + atr2 * stop_atr_mult;
    const riskForTargets = Math.abs(price - stop_loss);
    tp1 = crypto_behavior_tuning ? price - riskForTargets * tp1_r : price - atr2 * tp1_r;
    tp2 = crypto_behavior_tuning ? price - riskForTargets * tp2_r : price - atr2 * tp2_r;
  }
  const risk = Math.abs(price - stop_loss);
  const reward = Math.abs(tp2 - price);
  const risk_reward = risk > 0 ? parseFloat((reward / risk).toFixed(2)) : 0;
  const rrScore = clampScore2(Math.min(risk_reward / Math.max(min_rr, 0.01), 1.5) * 66);
  const breakoutFreshnessScore = clampScore2(100 - Math.max(0, breakoutDistanceAtr - 0.35) * 42 - Math.max(0, 0.1 - breakoutDistanceAtr) * 140);
  const lateBreakoutPenalty = breakoutDistanceAtr > max_late_breakout_atr ? Math.min(14, Math.round((breakoutDistanceAtr - max_late_breakout_atr) * 12)) : 0;
  const lateBreakoutExhausted = breakoutDistanceAtr > max_late_breakout_atr && momentumScore < 62 && atrExpansionRatio < Math.max(min_atr_expansion * 1.15, 1.08);
  let primaryFailedGate = "";
  if (!compressionReady) primaryFailedGate = "compression_not_ready";
  else if (!breakoutConfirmed) primaryFailedGate = "breakout_not_confirmed";
  else if (atrExpansionRatio < min_atr_expansion && !(crypto_behavior_tuning && nearCompressionReady && breakoutDistanceAtr >= breakout_buffer_atr * 2)) primaryFailedGate = "atr_expansion_weak";
  else if (lateBreakoutExhausted) primaryFailedGate = "late_breakout_exhausted";
  else if (ind.atr_pct > 5) primaryFailedGate = "volatility_too_high";
  else if (momentumScore < 45) primaryFailedGate = "momentum_failed";
  else if (risk_reward < min_rr) primaryFailedGate = "rr_too_low";
  const finalScore = clampScore2(compressionScore * 0.24 + breakoutScore * 0.22 + atrExpansionScore * 0.16 + momentumScore * 0.14 + volatilityScore * 0.08 + rrScore * 0.1 + candleBodyScore * 0.04 + breakoutFreshnessScore * 0.02 - lateBreakoutPenalty);
  if (!primaryFailedGate && finalScore < min_score) primaryFailedGate = "confidence_too_low";
  const score_breakdown = {
    primary_failed_gate: primaryFailedGate || "passed",
    compression_score: compressionScore,
    box_range_atr: parseFloat(boxRangeAtr.toFixed(3)),
    recent_box_range_atr: parseFloat(recentBoxRangeAtr.toFixed(3)),
    range_contracted: rangeContracted,
    box_lookback,
    min_box_bars,
    bars_inside_box: barsInside,
    compression_ready: compressionReady,
    strict_compression_ready: strictCompressionReady,
    near_compression_ready: nearCompressionReady,
    breakout_confirmed: breakoutConfirmed,
    early_breakout: earlyBreakoutUp || earlyBreakoutDn,
    retest_hold_confirmed: retestHoldUp || retestHoldDn,
    prior_breakout_confirmed: priorBreakoutUp || priorBreakoutDn,
    breakout_direction: direction,
    breakout_distance_atr: parseFloat(breakoutDistanceAtr.toFixed(3)),
    breakout_score: breakoutScore,
    breakout_freshness_score: breakoutFreshnessScore,
    max_late_breakout_atr,
    late_breakout_penalty: lateBreakoutPenalty,
    late_breakout_exhausted: lateBreakoutExhausted,
    atr_expansion: parseFloat(atrExpansionRatio.toFixed(3)),
    atr_expansion_score: atrExpansionScore,
    min_atr_expansion,
    momentum_score: momentumScore,
    candle_body_score: candleBodyScore,
    volatility_score: volatilityScore,
    rr_score: rrScore,
    rr: risk_reward,
    stop_distance_pct: pctDistance2(price, stop_loss),
    tp1_distance_pct: pctDistance2(price, tp1),
    tp2_distance_pct: pctDistance2(price, tp2),
    final_score: finalScore,
    max_bars_in_trade: params.max_bars_in_trade ?? 48
  };
  const grade2 = scoreGrade2(finalScore);
  const reason = `CompressionBreakout ${direction}: box=${boxRangeAtr.toFixed(2)} ATR, breakout=${breakoutDistanceAtr.toFixed(2)} ATR, expansion=${atrExpansionRatio.toFixed(2)}x, rr=${risk_reward.toFixed(2)}R, score=${finalScore}`;
  if (primaryFailedGate) {
    return { status: "rejected", direction, entry_low, entry_high, stop_loss, tp1, tp2, risk_reward, confidence_score: finalScore, grade: "reject", reason, rejection_reason: primaryFailedGate, score_breakdown };
  }
  return { status: "candidate", direction, entry_low, entry_high, stop_loss, tp1, tp2, risk_reward, confidence_score: finalScore, grade: grade2, reason, rejection_reason: "", score_breakdown };
}
function evalSwingContinuation(candles, ind, timeframe, params) {
  const rsi_buy_min = params.rsi_buy_min ?? 50;
  const rsi_sell_max = params.rsi_sell_max ?? 50;
  const min_atr_pct = params.min_atr_pct ?? 0.15;
  const max_atr_pct = params.max_atr_pct ?? 4;
  const pullback_bars = Math.max(2, Math.floor(params.pullback_bars ?? 8));
  const stop_atr_mult = params.stop_atr_mult ?? 1.2;
  const tp1_r = params.tp1_r ?? 1.2;
  const tp2_r = params.tp2_r ?? 2.2;
  const min_rr = params.min_rr ?? 1.5;
  const min_score = params.min_score ?? params.min_confidence_balanced ?? 78;
  const crypto_behavior_tuning = params.crypto_behavior_tuning === 1;
  const momentum_lookback = Math.max(1, Math.floor(params.momentum_lookback ?? 3));
  const atr_len = Math.max(2, Math.floor(params.atr_len ?? 14));
  const rsi_len = Math.max(2, Math.floor(params.rsi_len ?? 14));
  const ema_fast = Math.max(2, Math.floor(params.ema_fast ?? 20));
  const ema_slow = Math.max(ema_fast + 1, Math.floor(params.ema_slow ?? 50));
  if (!["15m", "1h"].includes(timeframe)) return strategyZeroReject2("unsupported_timeframe");
  const minLen = Math.max(ema_slow + 5, atr_len + 2, rsi_len + 2, pullback_bars + 10, 60);
  if (candles.length < minLen) return strategyZeroReject2("insufficient_candles");
  if (hasInvalidCandles2(candles)) return strategyZeroReject2("invalid_candles");
  const closes = candles.map((c) => c.close);
  const last = candles[candles.length - 1];
  const prevCloses = closes.slice(0, -pullback_bars);
  const price = last.close;
  const atr2 = calcATR2(candles, atr_len);
  const atrPct = price > 0 ? atr2 / price * 100 : 0;
  const rsi2 = calcRSI2(closes, rsi_len);
  const emaFast = calcEMA2(closes, ema_fast);
  const emaSlow = calcEMA2(closes, ema_slow);
  const priorEmaFast = calcEMA2(prevCloses, ema_fast);
  if (atr2 <= 0 || price <= 0 || !Number.isFinite(atr2) || !Number.isFinite(price)) return strategyZeroReject2("invalid_atr_or_price");
  const emaSpreadPct = emaSlow > 0 ? (emaFast - emaSlow) / emaSlow * 100 : 0;
  const emaSlopePct = priorEmaFast > 0 ? (emaFast - priorEmaFast) / priorEmaFast * 100 : 0;
  const bullBias = emaSpreadPct * 1.4 + emaSlopePct + (price > emaFast ? 0.25 : -0.25) + (rsi2 - 50) / 100;
  const bearBias = -emaSpreadPct * 1.4 - emaSlopePct + (price < emaFast ? 0.25 : -0.25) + (50 - rsi2) / 100;
  const direction = bullBias >= bearBias ? "buy" : "sell";
  const directionalSpread = direction === "buy" ? emaSpreadPct : -emaSpreadPct;
  const directionalSlope = direction === "buy" ? emaSlopePct : -emaSlopePct;
  const emaAligned = directionalSpread > 0;
  const emaAlignment = direction === "buy" ? emaFast > emaSlow ? "bullish" : "not_bullish" : emaFast < emaSlow ? "bearish" : "not_bearish";
  const priceVsEma = direction === "buy" ? (price - emaFast) / price * 100 : (emaFast - price) / price * 100;
  const trendScore = clampScore2((emaAligned ? 42 : 12) + Math.min(Math.max(directionalSpread, 0) / 1.2, 1) * 38 + (directionalSlope > 0 ? 20 : 0));
  const emaSlopeScore = clampScore2(35 + Math.min(Math.max(directionalSlope, -0.15) + 0.15, 0.65) / 0.65 * 65);
  const pullbackWindow = candles.slice(-(pullback_bars + 1), -1);
  const pullbackLow = Math.min(...pullbackWindow.map((c) => c.low));
  const pullbackHigh = Math.max(...pullbackWindow.map((c) => c.high));
  const touchedBuyZone = pullbackLow <= emaFast + atr2 * 0.75;
  const reclaimedBuy = price > emaFast && last.close > last.open;
  const touchedSellZone = pullbackHigh >= emaFast - atr2 * 0.75;
  const reclaimedSell = price < emaFast && last.close < last.open;
  const pullbackReady = direction === "buy" ? touchedBuyZone : touchedSellZone;
  const strictReclaimConfirmed = direction === "buy" ? reclaimedBuy : reclaimedSell;
  let reclaimConfirmed = strictReclaimConfirmed;
  const pullbackScore = direction === "buy" ? clampScore2((touchedBuyZone ? 48 : 18) + (reclaimedBuy ? 38 : price > emaFast ? 22 : 0) + (pullbackLow > emaSlow ? 14 : 5)) : clampScore2((touchedSellZone ? 48 : 18) + (reclaimedSell ? 38 : price < emaFast ? 22 : 0) + (pullbackHigh < emaSlow ? 14 : 5));
  const momentum = calcMomentumScore2(closes, momentum_lookback);
  const directionalMomentum = direction === "buy" ? momentum : -momentum;
  const bodyAtr = Math.abs(last.close - last.open) / atr2;
  const momentumScore = clampScore2(Math.max(0, directionalMomentum) * 60 + Math.min(bodyAtr, 1) * 25 + (direction === "buy" && last.close > last.open || direction === "sell" && last.close < last.open ? 15 : 0));
  const rsiScore = direction === "buy" ? clampScore2(Math.min(Math.max((rsi2 - 45) / Math.max(rsi_buy_min - 45, 1), 0), 1.25) * 80) : clampScore2(Math.min(Math.max((55 - rsi2) / Math.max(55 - rsi_sell_max, 1), 0), 1.25) * 80);
  const continuationChopScore = clampScore2((Math.abs(rsi2 - 50) < 5 ? 35 : 0) + (Math.abs(directionalSpread) < 0.12 ? 30 : 0) + (bodyAtr < 0.22 ? 20 : 0) + (Math.abs(directionalMomentum) < 0.2 ? 15 : 0));
  const trendQualityPass = trendScore >= 50 || crypto_behavior_tuning && emaSlopeScore >= 62 && directionalSpread > 0.02 && priceVsEma > 0 && rsiScore >= 45 && continuationChopScore < 65;
  const reclaimByQuality = crypto_behavior_tuning && pullbackScore >= 74 && momentumScore >= 52 && trendScore >= 58 && emaSlopeScore >= 62 && continuationChopScore < 62 && priceVsEma > -0.02;
  reclaimConfirmed = strictReclaimConfirmed || reclaimByQuality;
  const reclaimQualityPass = reclaimConfirmed;
  let volatilityScore = 85;
  if (atrPct < min_atr_pct) volatilityScore = clampScore2(atrPct / Math.max(min_atr_pct, 0.01) * 55);
  else if (atrPct > max_atr_pct) volatilityScore = clampScore2(Math.max(20, 80 - (atrPct - max_atr_pct) / Math.max(max_atr_pct, 0.01) * 80));
  let entry_low, entry_high, stop_loss, tp1, tp2;
  if (direction === "buy") {
    entry_low = price * 0.9997;
    entry_high = price * 1.0003;
    stop_loss = Math.min(pullbackLow - atr2 * 0.15, price - atr2 * stop_atr_mult);
    const riskForTargets = Math.abs(price - stop_loss);
    tp1 = crypto_behavior_tuning ? price + riskForTargets * tp1_r : price + atr2 * tp1_r;
    tp2 = crypto_behavior_tuning ? price + riskForTargets * tp2_r : price + atr2 * tp2_r;
  } else {
    entry_low = price * 0.9997;
    entry_high = price * 1.0003;
    stop_loss = Math.max(pullbackHigh + atr2 * 0.15, price + atr2 * stop_atr_mult);
    const riskForTargets = Math.abs(price - stop_loss);
    tp1 = crypto_behavior_tuning ? price - riskForTargets * tp1_r : price - atr2 * tp1_r;
    tp2 = crypto_behavior_tuning ? price - riskForTargets * tp2_r : price - atr2 * tp2_r;
  }
  const risk = Math.abs(price - stop_loss);
  const reward = Math.abs(tp2 - price);
  const risk_reward = risk > 0 ? parseFloat((reward / risk).toFixed(2)) : 0;
  const rrScore = clampScore2(Math.min(risk_reward / Math.max(min_rr, 0.01), 1.5) * 66);
  let primaryFailedGate = "";
  if (atrPct < min_atr_pct) primaryFailedGate = "volatility_too_low";
  else if (atrPct > max_atr_pct) primaryFailedGate = "volatility_too_high";
  else if (!trendQualityPass) primaryFailedGate = "trend_filter_failed";
  else if (!pullbackReady || pullbackScore < 45) primaryFailedGate = "pullback_not_ready";
  else if (!reclaimQualityPass) primaryFailedGate = "reclaim_not_confirmed";
  else if (momentumScore < 35 || rsiScore < 35) primaryFailedGate = "momentum_failed";
  else if (risk_reward < min_rr) primaryFailedGate = "rr_too_low";
  const finalScore = clampScore2(trendScore * 0.24 + emaSlopeScore * 0.15 + pullbackScore * 0.18 + momentumScore * 0.16 + rsiScore * 0.11 + volatilityScore * 0.08 + rrScore * 0.08);
  if (!primaryFailedGate && reclaimByQuality && !strictReclaimConfirmed && finalScore < 85) primaryFailedGate = "strict_reclaim_required_for_A";
  if (!primaryFailedGate && continuationChopScore >= 70 && finalScore < 85) primaryFailedGate = "chop_continuation_risk";
  if (!primaryFailedGate && finalScore < min_score) primaryFailedGate = "confidence_too_low";
  const score_breakdown = {
    primary_failed_gate: primaryFailedGate || "passed",
    trend_direction: direction,
    trend_score: trendScore,
    trend_quality_pass: trendQualityPass,
    ema_fast: parseFloat(emaFast.toFixed(8)),
    ema_slow: parseFloat(emaSlow.toFixed(8)),
    ema_alignment: emaAlignment,
    ema_slope: parseFloat(directionalSlope.toFixed(3)),
    ema_slope_score: emaSlopeScore,
    price_vs_ema: parseFloat(priceVsEma.toFixed(3)),
    pullback_score: pullbackScore,
    pullback_ready: pullbackReady,
    reclaim_confirmed: reclaimConfirmed,
    reclaim_quality_pass: reclaimQualityPass,
    strict_reclaim_confirmed: strictReclaimConfirmed,
    reclaim_by_quality: reclaimByQuality,
    continuation_chop_score: continuationChopScore,
    momentum_score: momentumScore,
    rsi_score: rsiScore,
    volatility_score: volatilityScore,
    rr_score: rrScore,
    rr: risk_reward,
    stop_distance_pct: pctDistance2(price, stop_loss),
    tp1_distance_pct: pctDistance2(price, tp1),
    tp2_distance_pct: pctDistance2(price, tp2),
    final_score: finalScore,
    max_bars_in_trade: params.max_bars_in_trade ?? 96
  };
  const grade2 = scoreGrade2(finalScore);
  const reason = `SwingContinuation ${direction}: ema_spread=${directionalSpread.toFixed(3)}%, slope=${directionalSlope.toFixed(3)}%, pullback=${pullbackScore}, reclaim=${reclaimConfirmed}, rr=${risk_reward.toFixed(2)}R, score=${finalScore}`;
  if (primaryFailedGate) {
    return { status: "rejected", direction, entry_low, entry_high, stop_loss, tp1, tp2, risk_reward, confidence_score: finalScore, grade: "reject", reason, rejection_reason: primaryFailedGate, score_breakdown };
  }
  return { status: "candidate", direction, entry_low, entry_high, stop_loss, tp1, tp2, risk_reward, confidence_score: finalScore, grade: grade2, reason, rejection_reason: "", score_breakdown };
}

// supabase/functions/_shared/active-validation-runtime.ts
function calculateActiveIndicators(candles) {
  if (candles.length < 50) throw new Error("ACTIVE_SCANNER_REQUIRES_50_CANDLES");
  const closes = candles.map((c) => c.close), highs = candles.map((c) => c.high), lows = candles.map((c) => c.low), volumes = candles.map((c) => c.volume), last = candles.at(-1);
  const ema20 = emaRootV1(closes, 20), ema50 = emaRootV1(closes, 50), atr14 = atrRootV1(candles, 14), rsi14 = rsiRootV1(closes, 14), recent_high = Math.max(...highs.slice(-20)), recent_low = Math.min(...lows.slice(-20)), avg_volume = volumes.slice(-20).reduce((a, b) => a + b, 0) / 20, body_size = Math.abs(last.close - last.open), atr_pct = last.close > 0 ? atr14 / last.close * 100 : 0;
  const older = candles.slice(-50, -20), olderRange = older.length ? Math.max(...older.map((c) => c.high)) - Math.min(...older.map((c) => c.low)) : recent_high - recent_low, range_compression_ratio = olderRange > 0 ? (recent_high - recent_low) / olderRange : 1, recent = closes.slice(-4);
  let up = 0, down = 0;
  for (let i = 1; i < recent.length; i++) recent[i] > recent[i - 1] ? up++ : recent[i] < recent[i - 1] ? down++ : 0;
  const momentum_score = (up - down) / 3, gk_volatility = calculateGarmanKlassVolatility(candles), volatility_state = atr_pct > 3 || gk_volatility > 18e-4 ? "high" : atr_pct < 0.5 && gk_volatility < 2e-4 ? "low" : "normal";
  let regime = "unclear";
  if (ema20 > ema50 * 1.002 && rsi14 > 52) regime = "trend_up";
  else if (ema20 < ema50 * 0.998 && rsi14 < 48) regime = "trend_down";
  else if (range_compression_ratio < 0.55) regime = "compression";
  else if (atr_pct > 2 || gk_volatility > 25e-4) regime = "expansion";
  else if (rsi14 > 45 && rsi14 < 55) regime = "ranging";
  return { ema20, ema50, atr14, rsi14, recent_high, recent_low, avg_volume, body_size, atr_pct, range_compression_ratio, momentum_score, volatility_state, regime, gk_volatility };
}
function createApprovedReplayRegistry(config2, symbol, timeframe) {
  if (!config2.version || !config2.strategies.length) throw new Error("APPROVED_SCANNER_CONFIGURATION_REQUIRED");
  const definitions = [], researchDefinitions = [...regimeResearchDefinitions(), ...intradayResearchDefinitions(), ...costAwareResearchDefinitions(), ...altResearchDefinitions(), ...coordinatedCryptoDefinitions(), ...signalEnsembleDefinitions(), ...dailyTrendDefinitions()];
  for (const item of config2.strategies.filter((s) => s.enabled)) {
    const regime = researchDefinitions.find((s) => s.id === item.id);
    if (regime) {
      if (item.version !== regime.version) throw new Error(`ACTIVE_STRATEGY_VERSION_MISMATCH:${item.id}`);
      if (!regime.config.allowed_timeframes.includes(timeframe) || !regime.config.allowed_symbols.includes(symbol) || !item.timeframes.includes(timeframe) || item.symbols.length && !item.symbols.includes(symbol)) continue;
      const params = { ...regime.config.params, ...item.parameters };
      definitions.push({ ...regime, lifecycle: "ENABLED", publicationMode: "LIVE", config: { ...regime.config, enabled: true, min_score: item.minScore, min_rr: item.minRiskReward, max_bars_in_trade: item.maxBarsInTrade, params }, evaluate: (ctx) => regime.evaluate({ ...ctx, strategy_parameters: params }) });
      continue;
    }
    const contract = FOREX_STRATEGY_CONTRACTS.find((c) => c.id === item.id), forexEvaluator = FOREX_PRODUCTION_EVALUATORS[item.id], crypto = { "crypto.micro-scalper": { name: "MicroScalper", evaluate: evalMicroScalper }, "crypto.quick-scalp": { name: "QuickScalp", evaluate: evalQuickScalp }, "crypto.compression-breakout": { name: "CompressionBreakout", evaluate: evalCompressionBreakout }, "crypto.swing-continuation": { name: "SwingContinuation", evaluate: evalSwingContinuation } }[item.id];
    if (!contract && !crypto) throw new Error(`ACTIVE_STRATEGY_EVALUATOR_UNAVAILABLE:${item.id}`);
    if (item.version !== "1.0.0") throw new Error(`ACTIVE_STRATEGY_VERSION_MISMATCH:${item.id}`);
    if (!item.timeframes.includes(timeframe) || item.symbols.length && !item.symbols.includes(symbol)) continue;
    if (crypto && !/^[A-Z0-9]{2,15}USDT$/.test(symbol)) continue;
    if (contract && !forexStrategyEligibility(contract, symbol).eligible) continue;
    const legacyName = contract?.legacyName ?? crypto.name, market = contract ? "forex" : "crypto", runtime = { strategy_name: legacyName, enabled: true, min_score: item.minScore, min_rr: item.minRiskReward, max_bars_in_trade: item.maxBarsInTrade, min_stop_distance_pct: item.minStopDistancePct ?? 0, min_tp1_distance_pct: item.minTp1DistancePct ?? 0, min_tp2_distance_pct: item.minTp2DistancePct ?? 0, allowed_symbols: item.symbols, allowed_timeframes: item.timeframes, params: item.parameters };
    definitions.push({ id: item.id, version: item.version, legacyName, market, lifecycle: "ENABLED", publicationMode: "LIVE", certification: "PRODUCTION", config: runtime, evaluate: (ctx) => contract ? forexEvaluator(ctx, { ...item.parameters, min_score: item.minScore, min_rr: item.minRiskReward }) : crypto.evaluate(ctx.candles, ctx.indicators, ctx.timeframe, item.id === "crypto.micro-scalper" ? microScalperRuntimeParams(runtime, ctx.timeframe).params : { ...item.parameters, min_score: item.minScore, min_rr: item.minRiskReward, max_bars_in_trade: item.maxBarsInTrade, ...item.id !== "crypto.quick-scalp" ? { crypto_behavior_tuning: 1 } : {} }, ctx.higher_timeframe_candles) });
  }
  if (!definitions.length) throw new Error("NO_APPROVED_STRATEGY_FOR_SYMBOL_TIMEFRAME");
  return new ProfessionalStrategyRegistry(definitions);
}

// supabase/functions/_shared/coordinated-crypto-policy.ts
function cryptoTeamPolicy(entries) {
  const team = entries.filter((e) => CRYPTO_TEAM_ROLES.some((r) => r.name === e.name));
  if (!team.length) return;
  for (const e of team) {
    const b = e.result.score_breakdown, role = CRYPTO_TEAM_ROLES.find((r) => r.name === e.name);
    if (b.team_policy !== "crypto-team/v1" || b.team_role !== role.id || b.score_is_probability !== false || !Number.isFinite(Date.parse(String(b.source_close)))) return "TEAM_POLICY_EVIDENCE_INVALID";
    const state2 = String(b.team_state), buy = e.result.direction === "buy", sell = e.result.direction === "sell";
    if (role.id === "crypto.team-trend" && !(buy && state2 === "TREND_UP" || sell && state2 === "TREND_DOWN") || role.id === "crypto.team-range" && state2 !== "RANGE" || role.id === "crypto.team-breakout" && !(buy && state2 === "EXPANSION_UP" || sell && state2 === "EXPANSION_DOWN") || role.id === "crypto.team-alt" && !(buy && ["TREND_UP", "EXPANSION_UP"].includes(state2))) return "TEAM_ROLE_REGIME_MISMATCH";
  }
  if (new Set(team.map((e) => String(e.result.score_breakdown.team_state))).size > 1) return "TEAM_MARKET_STATE_CONFLICT";
  return "";
}

// supabase/functions/_shared/adaptive-market-policy.ts
function observeAdaptiveMarket(candles, ind) {
  const invalid = { version: "adaptive-market/v1", state: "INVALID", efficiency: 0, relativeAtr: 0, barRangeAtr: 0, trendAtr: 0, valid: false };
  if (candles.length < 50 || ![ind.atr14, ind.ema20, ind.ema50].every(Number.isFinite) || ind.atr14 <= 0 || candles.some((c, i) => ![c.open, c.high, c.low, c.close, c.volume].every(Number.isFinite) || c.low <= 0 || c.high < Math.max(c.open, c.close) || c.low > Math.min(c.open, c.close) || c.volume < 0 || !Number.isFinite(Date.parse(c.open_time)) || i > 0 && Date.parse(c.open_time) <= Date.parse(candles[i - 1].open_time))) return invalid;
  const recent = candles.slice(-21), travel = recent.slice(1).reduce((sum, c, i) => sum + Math.abs(c.close - recent[i].close), 0), efficiency = travel > 0 ? Math.abs(recent.at(-1).close - recent[0].close) / travel : 0;
  const ranges = candles.slice(-50, -14).map((c, i) => Math.max(c.high - c.low, Math.abs(c.high - (candles[candles.length - 51 + i]?.close ?? c.open)), Math.abs(c.low - (candles[candles.length - 51 + i]?.close ?? c.open)))).sort((a, b) => a - b);
  const baseline = ranges[Math.floor(ranges.length / 2)], relativeAtr = baseline > 0 ? ind.atr14 / baseline : 0, last = candles.at(-1), barRangeAtr = (last.high - last.low) / ind.atr14, trendAtr = (ind.ema20 - ind.ema50) / ind.atr14;
  let state2 = "TRANSITION";
  if (relativeAtr > 2.5 || barRangeAtr > 3.5) state2 = "SHOCK";
  else if (ind.range_compression_ratio < 0.55) state2 = "COMPRESSION";
  else if (efficiency >= 0.25 && Math.abs(trendAtr) >= 0.6) state2 = trendAtr > 0 ? "TREND_UP" : "TREND_DOWN";
  else if (efficiency < 0.2 && Math.abs(trendAtr) < 0.6) state2 = "RANGE";
  return { version: "adaptive-market/v1", state: state2, efficiency, relativeAtr, barRangeAtr, trendAtr, valid: true };
}
function adaptiveCandidateBlock(candidate2, market) {
  if (!market.valid) return "adaptive_invalid_market_evidence";
  if (market.state === "SHOCK") return "adaptive_volatility_shock";
  if (candidate2.market !== "crypto") return;
  const trend = candidate2.strategyId.includes("swing-continuation"), scalp = candidate2.strategyId.includes("scalp");
  if ((trend || scalp) && market.state === "RANGE") return "adaptive_range_unsuitable_for_continuation";
  if (trend && market.state === "TRANSITION") return "adaptive_transition_without_trend";
  if ((trend || scalp) && (market.state === "TREND_UP" && candidate2.side === "sell" || market.state === "TREND_DOWN" && candidate2.side === "buy")) return "adaptive_countertrend_continuation";
}

// supabase/functions/_shared/scanner-market-context.ts
var clampScore3 = (value) => Math.min(Math.max(Math.round(value), 0), 100);
var gradeIndex = (g) => g === "A+" ? 3 : g === "A" ? 2 : g === "B" ? 1 : 0;
function classifyMarketContext(ind, candles) {
  const last = candles[candles.length - 1];
  const prev = candles[candles.length - 2] ?? last;
  const atr2 = Math.max(ind.atr14, 0);
  const price = Math.max(last?.close ?? 0, 0);
  const emaSpreadAtr = atr2 > 0 ? Math.abs(ind.ema20 - ind.ema50) / atr2 : 0;
  const distanceFromEmaAtr = atr2 > 0 ? Math.abs(price - ind.ema20) / atr2 : 0;
  const bodyAtr = atr2 > 0 ? Math.abs(last.close - last.open) / atr2 : 0;
  const barRangeAtr = atr2 > 0 ? (last.high - last.low) / atr2 : 0;
  const recentHigh = ind.recent_high;
  const recentLow = ind.recent_low;
  const breakoutUp = atr2 > 0 && last.close > recentHigh - atr2 * 0.1 && last.close > last.open;
  const breakoutDn = atr2 > 0 && last.close < recentLow + atr2 * 0.1 && last.close < last.open;
  const trendStrength = clampScore3(Math.min(1, emaSpreadAtr / 2.2) * 58 + (ind.regime.startsWith("trend") ? 24 : 0) + Math.abs(ind.rsi14 - 50) / 50 * 18);
  const momentumStrength = clampScore3(Math.abs(ind.momentum_score) * 60 + Math.min(bodyAtr, 1.2) * 28 + (last.close > prev.close === ind.momentum_score >= 0 ? 12 : 0));
  const volatilityExpansion = clampScore3(Math.min(barRangeAtr / 1.6, 1.4) * 72 + (ind.atr_pct > 2 ? 18 : 0));
  const volatilityContraction = clampScore3(Math.max(0, 1 - ind.range_compression_ratio) * 85 + (ind.atr_pct < 0.5 ? 15 : 0));
  const compressionState = clampScore3(Math.max(0, 1 - ind.range_compression_ratio / 0.75) * 100);
  const rangeState = clampScore3((ind.rsi14 > 45 && ind.rsi14 < 55 ? 45 : 0) + Math.max(0, 1 - emaSpreadAtr / 1.4) * 35 + (ind.range_compression_ratio > 0.7 ? 20 : 0));
  const chopLevel = clampScore3(rangeState * 0.65 + (bodyAtr < 0.22 ? 20 : 0) + (Math.abs(ind.momentum_score) < 0.2 ? 15 : 0));
  const overextension = clampScore3(Math.min(distanceFromEmaAtr / 2.4, 1.4) * 100);
  const breakoutState = clampScore3((breakoutUp || breakoutDn ? 55 : 0) + volatilityExpansion * 0.3 + compressionState * 0.15);
  const pullbackState = clampScore3((distanceFromEmaAtr <= 0.9 ? 45 : 0) + trendStrength * 0.35 + (bodyAtr >= 0.2 ? 20 : 0));
  const reclaimState = clampScore3((last.close > ind.ema20 && last.close > last.open || last.close < ind.ema20 && last.close < last.open ? 40 : 0) + pullbackState * 0.45 + momentumStrength * 0.15);
  const atrRegime = ind.atr_pct > 3.5 ? "very_high" : ind.atr_pct > 2 ? "high" : ind.atr_pct < 0.15 ? "very_low" : ind.atr_pct < 0.5 ? "low" : "normal";
  const recentMovePct = price > 0 && candles.length > 12 ? Math.abs((price - candles[candles.length - 12].close) / price * 100) : 0;
  const invalidationDistanceAtr = atr2 > 0 ? Math.max(0.1, distanceFromEmaAtr) : 0;
  let preferred_strategy = "none";
  if (compressionState >= 58 && breakoutState >= 58 && overextension < 75 && chopLevel < 72) preferred_strategy = "CompressionBreakout";
  else if (trendStrength >= 62 && reclaimState >= 58 && chopLevel < 58 && overextension < 82) preferred_strategy = "SwingContinuation";
  else if (momentumStrength >= 72 && overextension < 58 && volatilityExpansion >= 55 && chopLevel < 52) preferred_strategy = "QuickScalp";
  else if (momentumStrength >= 58 && overextension < 72 && volatilityExpansion >= 38 && chopLevel < 68) preferred_strategy = "MicroScalper";
  const positiveStates = [
    momentumStrength >= 55 && overextension < 72,
    compressionState >= 55 && breakoutState >= 55,
    trendStrength >= 60 && reclaimState >= 55
  ].filter(Boolean).length;
  const mixed_market = preferred_strategy === "none" || positiveStates !== 1 || chopLevel >= 72;
  const opportunityScore = clampScore3(
    trendStrength * 0.2 + momentumStrength * 0.18 + volatilityExpansion * 0.14 + compressionState * 0.1 + breakoutState * 0.13 + (100 - chopLevel) * 0.13 + Math.max(0, 100 - overextension) * 0.07 + Math.min(recentMovePct * 8, 100) * 0.05
  );
  const expectedMoveBucket = opportunityScore >= 78 && ind.atr_pct >= 0.7 ? "1-2pct_clean_move" : opportunityScore >= 65 ? "0.5-1pct_profit_lock_candidate" : "low_expected_move";
  const riskQuality = overextension > 82 || chopLevel > 76 ? "poor" : overextension < 65 && chopLevel < 62 ? "clean" : "mixed";
  const liquidityQuality = ind.avg_volume > 0 ? "available" : "unknown";
  return {
    adaptive: observeAdaptiveMarket(candles, ind),
    regime: ind.regime,
    trend_strength: trendStrength,
    momentum_strength: momentumStrength,
    volatility_expansion: volatilityExpansion,
    volatility_contraction: volatilityContraction,
    compression_state: compressionState,
    range_state: rangeState,
    chop_level: chopLevel,
    atr_regime: atrRegime,
    distance_from_ema_atr: parseFloat(distanceFromEmaAtr.toFixed(3)),
    overextension,
    breakout_state: breakoutState,
    pullback_state: pullbackState,
    reclaim_state: reclaimState,
    preferred_strategy,
    mixed_market,
    opportunity_score: opportunityScore,
    expected_move_bucket: expectedMoveBucket,
    risk_quality: riskQuality,
    liquidity_quality: liquidityQuality,
    strategy_match: preferred_strategy,
    recent_move_pct: parseFloat(recentMovePct.toFixed(3)),
    invalidation_distance_atr: parseFloat(invalidationDistanceAtr.toFixed(3))
  };
}
var forexRole = (name) => ({ ForexLondonBreakout: "CompressionBreakout", GoldVolatilityBreakout: "CompressionBreakout", ForexNewYorkContinuation: "MicroScalper", ForexTrendPullback: "SwingContinuation" })[name] ?? name;
function marketRoleFit(e, ctx) {
  if (e.cfg.params.market_adaptation_enabled === 1) e = { ...e, name: forexRole(e.name) };
  if (e.name === "QuickScalp") {
    return clampScore3(ctx.momentum_strength * 0.34 + ctx.volatility_expansion * 0.24 + (100 - ctx.overextension) * 0.24 + (100 - ctx.chop_level) * 0.18);
  }
  if (e.name === "MicroScalper" || e.name === "ForexMicroScalper") {
    return clampScore3(ctx.momentum_strength * 0.38 + (100 - ctx.overextension) * 0.24 + ctx.volatility_expansion * 0.2 + (100 - ctx.chop_level) * 0.18);
  }
  if (e.name === "CompressionBreakout") {
    return clampScore3(ctx.compression_state * 0.3 + ctx.breakout_state * 0.34 + ctx.volatility_expansion * 0.18 + (100 - Math.max(ctx.overextension, ctx.chop_level)) * 0.18);
  }
  if (e.name === "SwingContinuation" || e.name === "ForexSwingContinuation") {
    return clampScore3(ctx.trend_strength * 0.34 + ctx.reclaim_state * 0.28 + ctx.pullback_state * 0.18 + (100 - ctx.chop_level) * 0.2);
  }
  return 50;
}
function strategyFreshnessScore(e, ctx) {
  const b = e.result.score_breakdown;
  if (e.name === "CompressionBreakout") {
    const breakoutFreshness = scoreBreakdownNumber(b, "breakout_freshness_score");
    return breakoutFreshness > 0 ? breakoutFreshness : clampScore3(100 - Math.max(0, scoreBreakdownNumber(b, "breakout_distance_atr") - 0.35) * 42);
  }
  if (e.name === "SwingContinuation" || e.name === "ForexSwingContinuation") {
    const strictReclaim = scoreBreakdownBool(b, "strict_reclaim_confirmed");
    const reclaimByQuality = scoreBreakdownBool(b, "reclaim_by_quality");
    return clampScore3((strictReclaim ? 78 : reclaimByQuality ? 56 : 35) + ctx.reclaim_state * 0.16 + (100 - ctx.chop_level) * 0.06);
  }
  if (e.name === "QuickScalp") {
    const extension = scoreBreakdownNumber(b, "price_extension_atr");
    return clampScore3(94 - Math.max(0, extension - 0.6) * 34 + ctx.momentum_strength * 0.08 + ctx.volatility_expansion * 0.06);
  }
  if (e.name === "MicroScalper" || e.name === "ForexMicroScalper") {
    const extension = scoreBreakdownNumber(b, "price_extension_atr");
    return clampScore3(88 - Math.max(0, extension - 0.8) * 22 - (scoreBreakdownBool(b, "chase_risk") ? 28 : 0) + ctx.momentum_strength * 0.1);
  }
  return 55;
}
function arbitrationNoTradeReason(ctx, entries) {
  if (entries.length === 0) return "";
  if (entries.every((e) => e.name === "DailyEmaTrend")) return entries.every((e) => dailyEvidence(e.result.score_breakdown)) ? "" : "DAILY_POLICY_MISMATCH";
  const sleevePolicy = signalEnsembleMarketPolicy(entries);
  if (sleevePolicy !== void 0) return sleevePolicy;
  const teamPolicy = cryptoTeamPolicy(entries);
  if (teamPolicy !== void 0) return teamPolicy;
  if (entries.every((e) => ["crypto.cost-aware-15m", "forex.cost-aware-hourly"].includes(e.name))) {
    return entries.every((e) => {
      const b = e.result.score_breakdown;
      return b.cost_aware_policy_version === "cost-aware-opportunity/v1" && typeof b.forecast_net_r === "number" && Number.isFinite(b.forecast_net_r) && b.forecast_net_r >= e.cfg.params.minimum_predicted_net_r && typeof b.estimated_cost_r === "number" && Number.isFinite(b.estimated_cost_r) && b.estimated_cost_r >= 0 && b.score_is_probability === false && b.forecast_is_guarantee === false;
    }) ? "" : "COST_AWARE_POLICY_MISMATCH";
  }
  if (entries.every((e) => ["crypto.vwap-reclaim-15m", "crypto.failed-auction-15m"].includes(e.name))) {
    return entries.every((e) => {
      const b = e.result.score_breakdown, eff = b.efficiency, trend = b.hourly_trend_atr, cost = b.estimated_cost_r;
      return b.intraday_policy_version === "intraday-opportunity/v1" && typeof eff === "number" && Number.isFinite(eff) && typeof trend === "number" && Number.isFinite(trend) && typeof cost === "number" && Number.isFinite(cost) && cost >= 0 && cost <= e.cfg.params.maximumCostR && (e.name === "crypto.vwap-reclaim-15m" ? b.setup === "CLOSED_HOURLY_TREND_VWAP_RECLAIM" && eff >= 0.2 && trend >= 0.4 && (e.result.direction === "buy" ? b.hourly_direction === 1 : b.hourly_direction === -1) : b.setup === "PRIOR_RANGE_SWEEP_AND_REJECTION" && eff <= 0.3 && trend <= 1.2);
    }) ? "" : "INTRADAY_POLICY_MISMATCH";
  }
  if (entries.every((e) => ["RegimeContinuation", "RegimeRangeRejection", "RegimeChannelBreakout"].includes(e.name))) {
    return entries.every((e) => e.result.score_breakdown.regime_policy_version === "regime-opportunity/v1" && (e.name !== "RegimeRangeRejection" ? ["TREND_UP", "TREND_DOWN", "EXPANSION_UP", "EXPANSION_DOWN"].includes(String(e.result.score_breakdown.regime)) : e.result.score_breakdown.regime === "RANGE")) ? "" : "REGIME_POLICY_MISMATCH";
  }
  if (entries.every((e) => e.name === "AltRelativeStrength")) {
    return entries.every((e) => {
      const b = e.result.score_breakdown;
      return b.relative_strength_policy === "alt-relative-strength/v1" && b.score_is_probability === false && e.result.direction === "buy" && b.closed_hour_breakout === true && b.estimated_cost_bps === 25 && typeof b.btc_return === "number" && Number.isFinite(b.btc_return) && b.btc_return > 0 && typeof b.alt_return === "number" && Number.isFinite(b.alt_return) && b.alt_return >= 0.03 && typeof b.relative_return === "number" && Number.isFinite(b.relative_return) && b.relative_return >= 0.02 && typeof b.week_return === "number" && Number.isFinite(b.week_return) && b.week_return > 0 && typeof b.quote_volume_ratio === "number" && Number.isFinite(b.quote_volume_ratio) && b.quote_volume_ratio >= 1.5;
    }) ? "" : "ALT_RELATIVE_STRENGTH_POLICY_MISMATCH";
  }
  const top = entries[0];
  const topScore = arbitrationScore(top, ctx);
  const hasAPlus = entries.some((entry) => entry.result.grade === "A+");
  if (entries.every((e) => /^(Forex|Gold)/.test(e.name) && e.cfg.params.market_adaptation_enabled === 1)) {
    if (ctx.chop_level >= 76 && !hasAPlus) return "forex_chop_requires_a_plus";
    if (marketRoleFit(top, ctx) < 55 && !hasAPlus) return "forex_strategy_role_mismatch";
    if (ctx.overextension >= 90 && top.result.grade !== "A+") return "forex_overextended_entry";
    return "";
  }
  if (ctx.chop_level >= 76 && !hasAPlus) return "mixed_choppy_market_requires_a_plus";
  if (ctx.mixed_market && ctx.preferred_strategy === "none" && !hasAPlus) return "mixed_market_no_clear_strategy_requires_a_plus";
  if (ctx.mixed_market && top.result.grade !== "A+" && topScore < 0.68) return "mixed_market_expected_value_too_low";
  return "";
}
function scoreBreakdownNumber(breakdown, key) {
  const value = breakdown?.[key];
  return typeof value === "number" && Number.isFinite(value) ? value : 0;
}
function scoreBreakdownBool(breakdown, key) {
  return breakdown?.[key] === true || breakdown?.[key] === "true" || breakdown?.[key] === "passed";
}
function strategyIdentityFit(e) {
  const b = e.result.score_breakdown;
  if (e.name === "CompressionBreakout") {
    return clampScore3(
      scoreBreakdownNumber(b, "compression_score") * 0.3 + scoreBreakdownNumber(b, "breakout_score") * 0.35 + scoreBreakdownNumber(b, "atr_expansion_score") * 0.18 + scoreBreakdownNumber(b, "momentum_score") * 0.17 + (scoreBreakdownBool(b, "near_compression_ready") ? 6 : 0)
    );
  }
  if (e.name === "SwingContinuation" || e.name === "ForexSwingContinuation") {
    return clampScore3(
      scoreBreakdownNumber(b, "trend_score") * 0.3 + scoreBreakdownNumber(b, "pullback_score") * 0.28 + scoreBreakdownNumber(b, "momentum_score") * 0.22 + scoreBreakdownNumber(b, "ema_slope_score") * 0.1 + scoreBreakdownNumber(b, "rr_score") * 0.1
    );
  }
  if (e.name === "QuickScalp") {
    return clampScore3(
      scoreBreakdownNumber(b, "volume_expansion_score") * 0.18 + scoreBreakdownNumber(b, "liquidity_score") * 0.12 + scoreBreakdownNumber(b, "ema_alignment_score") * 0.18 + scoreBreakdownNumber(b, "momentum_acceleration_score") * 0.24 + scoreBreakdownNumber(b, "atr_expansion_score") * 0.14 + scoreBreakdownNumber(b, "impulse_quality_score") * 0.14
    );
  }
  if (e.name === "MicroScalper") {
    return clampScore3(
      scoreBreakdownNumber(b, "trend_score") * 0.24 + scoreBreakdownNumber(b, "momentum_score") * 0.22 + scoreBreakdownNumber(b, "rsi_score") * 0.18 + scoreBreakdownNumber(b, "candle_body_score") * 0.12 + scoreBreakdownNumber(b, "volatility_score") * 0.12 + scoreBreakdownNumber(b, "rr_score") * 0.12
    );
  }
  if (e.name === "ForexMicroScalper") {
    return clampScore3(
      scoreBreakdownNumber(b, "trend_score") * 0.25 + scoreBreakdownNumber(b, "momentum_score") * 0.25 + scoreBreakdownNumber(b, "candle_score") * 0.2 + scoreBreakdownNumber(b, "spread_or_distance_score") * 0.2 + scoreBreakdownNumber(b, "rr_score") * 0.1
    );
  }
  return clampScore3(
    scoreBreakdownNumber(b, "trend_score") * 0.25 + scoreBreakdownNumber(b, "momentum_score") * 0.25 + scoreBreakdownNumber(b, "rsi_score") * 0.18 + scoreBreakdownNumber(b, "candle_body_score") * 0.14 + scoreBreakdownNumber(b, "rr_score") * 0.18
  );
}
function overextensionPenalty(e) {
  const b = e.result.score_breakdown;
  let penalty = 0;
  if (scoreBreakdownBool(b, "chase_risk")) penalty += 0.1;
  const extensionAtr = scoreBreakdownNumber(b, "price_extension_atr");
  if (extensionAtr > 2) penalty += Math.min((extensionAtr - 2) * 0.04, 0.12);
  const bodyAtr = scoreBreakdownNumber(b, "body_atr");
  if ((e.name === "MicroScalper" || e.name === "ForexMicroScalper") && bodyAtr > 1.35) penalty += 0.04;
  return penalty;
}
function arbitrationScore(e, ctx) {
  const r = e.result;
  if (e.name === "DailyEmaTrend" && dailyEvidence(r.score_breakdown)) return r.confidence_score;
  const g = e.guard;
  const scorePct = r.confidence_score / 100;
  const rrPct = Math.min(r.risk_reward / 3.5, 1);
  const slMargin = g.sl_pct > 0 && e.cfg.min_stop_distance_pct > 0 ? Math.min(Math.max((g.sl_pct - e.cfg.min_stop_distance_pct) / e.cfg.min_stop_distance_pct, 0), 1) : 0.5;
  const tp1Margin = g.tp1_pct > 0 && e.cfg.min_tp1_distance_pct > 0 ? Math.min(Math.max((g.tp1_pct - e.cfg.min_tp1_distance_pct) / e.cfg.min_tp1_distance_pct, 0), 1) : 0.5;
  const tp2Margin = g.tp2_pct > 0 && e.cfg.min_tp2_distance_pct > 0 ? Math.min(Math.max((g.tp2_pct - e.cfg.min_tp2_distance_pct) / e.cfg.min_tp2_distance_pct, 0), 1) : 0.5;
  const distMargin = (slMargin + tp1Margin + tp2Margin) / 3;
  const gradePct = gradeIndex(r.grade) / 3;
  const identityPct = strategyIdentityFit(e) / 100;
  const roleFitPct = ctx ? marketRoleFit(e, ctx) / 100 : identityPct;
  const freshnessPct = ctx ? strategyFreshnessScore(e, ctx) / 100 : 0.55;
  const preferredBonus = ctx?.preferred_strategy === e.name ? 0.05 : 0;
  const gradeQualityBonus = r.grade === "A+" ? 0.04 : r.grade === "A" ? 0.015 : 0;
  const mixedMarketPenalty = ctx?.mixed_market && r.grade !== "A+" ? 0.04 : 0;
  const swingChopPenalty = ctx && (e.name === "SwingContinuation" || e.name === "ForexSwingContinuation") && ctx.chop_level >= 58 && r.grade !== "A+" ? 0.09 : 0;
  const opportunityPct = ctx ? ctx.opportunity_score / 100 : 0.55;
  const riskQualityPenalty = ctx?.risk_quality === "poor" ? 0.08 : ctx?.risk_quality === "mixed" ? 0.025 : 0;
  return parseFloat(Math.max(0, scorePct * 0.18 + identityPct * 0.13 + roleFitPct * 0.2 + freshnessPct * 0.08 + opportunityPct * 0.12 + rrPct * 0.14 + distMargin * 0.08 + gradePct * 0.07 + gradeQualityBonus + preferredBonus - mixedMarketPenalty - swingChopPenalty - overextensionPenalty(e) - riskQualityPenalty).toFixed(4));
}

// supabase/functions/_shared/arbitrator.ts
var ARBITRATOR_VERSION = "arbitrator.root-compat-v1";
var canonical3 = (value) => value === null || typeof value !== "object" ? JSON.stringify(value) : Array.isArray(value) ? `[${value.map(canonical3).join(",")}]` : `{${Object.entries(value).sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => `${JSON.stringify(k)}:${canonical3(v)}`).join(",")}}`;
function hash2(input) {
  let h1 = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h1 ^= input.charCodeAt(i);
    h1 = Math.imul(h1, 16777619);
  }
  return `arb_${(h1 >>> 0).toString(16).padStart(8, "0")}`;
}
function rejectionReasons(c, options) {
  const reasons = [];
  const dynamic = dailyCandidate(c);
  if (c.lifecycle !== "ENABLED" || c.publicationMode !== "LIVE") reasons.push("research_or_non_live_excluded");
  if (c.eligible === false) reasons.push("legacy_gate_rejected", ...c.rejectionReasons);
  if (!c.fresh) reasons.push("stale_candidate");
  if (!Number.isFinite(Date.parse(c.expiry)) || Date.parse(c.expiry) <= options.now.getTime()) reasons.push("expired_candidate");
  if (![c.confidence, c.score, c.entry, c.stop, c.riskReward, ...c.targets].every(Number.isFinite)) reasons.push("non_finite_value");
  if (!["buy", "sell"].includes(c.side)) reasons.push("invalid_side");
  if (c.targets.some((target, i) => i > 0 && (c.side === "buy" ? target <= c.targets[i - 1] : target >= c.targets[i - 1]))) reasons.push("invalid_target_order");
  if (c.entry <= 0 || c.stop <= 0 || !dynamic && c.targets.length === 0 || c.targets.some((v) => v <= 0)) reasons.push("invalid_price_structure");
  if (c.side === "buy" && !(c.stop < c.entry && c.targets.every((t) => t > c.entry)) || c.side === "sell" && !(c.stop > c.entry && c.targets.every((t) => t < c.entry))) reasons.push("invalid_price_structure");
  if (!dynamic && (c.riskReward <= 0 || c.riskReward < (options.minimumRiskReward ?? 0))) reasons.push("invalid_risk_reward");
  if (c.score < (options.minimumScore ?? 0)) reasons.push("below_score_threshold");
  if (options.allowedGrades && !options.allowedGrades.includes(c.grade)) reasons.push("grade_filtered");
  return [...new Set(reasons)];
}
function arbitrate(candidates, options) {
  const snapshot = candidates.map((candidate2) => ({ ...candidate2, targets: [...candidate2.targets], evidence: { ...candidate2.evidence }, rejectionReasons: [...candidate2.rejectionReasons] }));
  const rejected3 = [];
  const eligible = snapshot.filter((candidate2) => {
    const reasons = rejectionReasons(candidate2, options);
    if (reasons.length) rejected3.push({ candidateId: candidate2.id, reasons, evidence: { lifecycle: candidate2.lifecycle, publication_mode: candidate2.publicationMode } });
    return reasons.length === 0;
  });
  const canonicalDecision = arbitrateCanonical(eligible.map((c) => ({ id: c.id, strategyId: c.strategyId, strategyVersion: c.strategyVersion, configurationVersion: String(c.evidence.configuration_version ?? "runtime"), timestamp: options.now.toISOString(), symbol: c.symbol, primaryTimeframe: c.timeframe, side: c.side.toUpperCase(), entry: c.entry, stop: c.stop, targets: c.targets, score: c.score, evidence: { reasonCodes: [], indicators: {}, observations: Object.fromEntries(Object.entries(c.evidence).filter((entry) => ["string", "number", "boolean"].includes(typeof entry[1]))) } })), { minimumScore: options.minimumScore ?? 0, blockedSymbols: [] });
  eligible.sort((a, b) => canonicalDecision.scoreBreakdown[b.id] - canonicalDecision.scoreBreakdown[a.id] || a.id.localeCompare(b.id));
  const ties = eligible.length > 1 && Math.abs(eligible[0].score - eligible[1].score) <= 1e-4;
  const forced = options.forceNoTradeReason || options.noTradePolicy?.(eligible) || void 0;
  const winner = !forced ? eligible.find((c) => c.id === canonicalDecision.chosen?.id) : void 0;
  for (const loser of eligible.filter((c) => c.id !== winner?.id)) rejected3.push({ candidateId: loser.id, reasons: [forced ? forced : canonicalDecision.rejected.find((r) => r.candidateId === loser.id)?.reasonCodes[0] ?? "LOWER_RANK"], evidence: { selected_candidate: winner?.id ?? null, force_no_trade_reason: forced ?? null, canonical_authority: "trading-domain.arbitrateCanonical" } });
  const decision = winner ? "WINNER" : "NO_TRADE";
  const keyPayload = { version: ARBITRATOR_VERSION, decision, winner: winner?.id ?? null, candidates: snapshot.map((c) => ({ id: c.id, score: c.score, priority: c.priority ?? 0, rr: c.riskReward })), rejected: rejected3.map((r) => ({ id: r.candidateId, reasons: r.reasons })), forced: forced ?? null };
  return { decision, winner, considered: [...eligible, ...snapshot.filter((candidate2) => !eligible.some((item) => item.id === candidate2.id))], rejected: rejected3, tieBreakEvidence: ties ? ["score_tie", "stable_candidate_id", "identity_fit_priority"] : [], version: ARBITRATOR_VERSION, decisionKey: hash2(canonical3(keyPayload)), evidence: { policy: "canonical_score_then_stable_candidate_id", authority: "trading-domain.arbitrateCanonical", forced_no_trade_reason: forced ?? null, immutable_snapshot: true } };
}

// supabase/functions/_shared/active-scanner-core.ts
var ACTIVE_SCANNER_FRAMEWORK = "professional-strategy-registry/v1";
var ACTIVE_SCANNER_ARBITRATOR = "arbitrator.root-compat-v1";
function evaluateActiveStrategies(registry, context) {
  return registry.evaluate(context);
}
function candidateCostRejection(candidate2) {
  const cost = candidate2.evidence.estimated_round_trip_cost_bps, minimum = candidate2.evidence.minimum_net_target_r;
  if (cost === void 0) return;
  if (typeof cost !== "number" || !Number.isFinite(cost) || cost < 0 || minimum !== void 0 && (typeof minimum !== "number" || !Number.isFinite(minimum) || minimum < 0)) return "invalid_declared_execution_cost";
  const risk = Math.abs(candidate2.entry - candidate2.stop);
  if (risk <= 0 || !candidate2.targets.length) return "invalid_cost_geometry";
  const gross = (Math.abs(candidate2.targets[0] - candidate2.entry) + Math.abs(candidate2.targets.at(-1) - candidate2.entry)) / 2 / risk;
  const costR = candidate2.entry * cost / 1e4 / risk;
  return gross - costR <= Number(minimum ?? 0) ? "costs_exceed_target_payoff" : void 0;
}
function arbitrateActiveScanner(candidates, options) {
  const checked = candidates.map((candidate2) => {
    const adaptiveReason = options.marketContext && (options.adaptivePolicy ?? candidate2.evidence.adaptive_policy_approved === true) ? adaptiveCandidateBlock(candidate2, options.marketContext.adaptive) : void 0;
    const reason = candidateCostRejection(candidate2) || adaptiveReason;
    const evidence = { ...candidate2.evidence, ...options.marketContext ? { adaptive_market: options.marketContext.adaptive } : {} };
    return reason ? { ...candidate2, eligible: false, rejectionReasons: [...candidate2.rejectionReasons, reason], evidence } : { ...candidate2, evidence };
  });
  const eligible = checked.filter((c) => c.eligible !== false && c.lifecycle === "ENABLED" && c.publicationMode === "LIVE" && c.fresh && c.score >= (options.minimumScore ?? 0) && Date.parse(c.expiry) > options.now.getTime());
  const opposing = eligible.some((c) => c.evidence.team_policy === "crypto-team/v1" || c.evidence.signal_ensemble_policy === "crypto-signal-ensemble/v1") ? eligible.flatMap((a) => eligible.filter((b) => b.symbol === a.symbol && b.side !== a.side).map((b) => Math.abs(a.score - b.score))) : [];
  const conflict = opposing.some((margin) => margin <= 0.08) ? "OPPOSING_SETUP_SCORES_TOO_CLOSE" : void 0;
  const result = arbitrate(checked, { ...options, forceNoTradeReason: options.forceNoTradeReason ?? conflict });
  return { ...result, evidence: { ...result.evidence, ...options.marketContext ? { market_context: options.marketContext, adaptive_policy_enabled: options.adaptivePolicy ?? checked.some((c) => c.evidence.adaptive_policy_approved === true), market_policy_version: "adaptive-market/v1" } : {} } };
}

// supabase/functions/_shared/active-qualification.ts
var grade = (value) => value === "A+" ? 3 : value === "A" ? 2 : value === "B" ? 1 : 0;
function qualifyActiveCandidate(result, config2, minSignalGrade) {
  const reasons = [];
  if (config2.strategy_name === "DailyEmaTrend" && dailyEvidence(result.score_breakdown)) {
    const entry2 = result.entry_high, slPct2 = (entry2 - result.stop_loss) / entry2 * 100;
    if (result.status !== "candidate" || result.direction !== "buy" || ![entry2, result.entry_low, result.stop_loss, result.confidence_score].every(Number.isFinite) || entry2 !== result.entry_low || result.stop_loss <= 0 || entry2 <= result.stop_loss || result.tp1 !== 0 || result.tp2 !== 0 || result.risk_reward !== 0 || config2.min_rr !== 0 || result.confidence_score < config2.min_score || grade(result.grade) < grade(minSignalGrade)) reasons.push("invalid_daily_trend_contract");
    return { passed: !reasons.length, reasons, slPct: slPct2, tp1Pct: 0, tp2Pct: 0, riskReward: 0 };
  }
  if (result.status === "rejected") reasons.push(result.rejection_reason || "evaluator_rejected");
  const buy = /^(buy|long)$/i.test(result.direction), sell = /^(sell|short)$/i.test(result.direction);
  const levels = [result.entry_low, result.entry_high, result.stop_loss, result.tp1, result.tp2];
  const entry = buy ? result.entry_high : result.entry_low, risk = Math.abs(entry - result.stop_loss);
  const slPct = entry > 0 ? risk / entry * 100 : 0, tp1Pct = entry > 0 ? Math.abs(result.tp1 - entry) / entry * 100 : 0, tp2Pct = entry > 0 ? Math.abs(result.tp2 - entry) / entry * 100 : 0, rr = risk > 0 ? Math.abs(result.tp2 - entry) / risk : 0;
  if (!levels.every(Number.isFinite) || levels.some((v) => v <= 0) || result.entry_low > result.entry_high) reasons.push("invalid_trade_levels");
  if (!(buy && result.stop_loss < result.entry_low && result.tp1 > result.entry_high && result.tp2 >= result.tp1 || sell && result.stop_loss > result.entry_high && result.tp1 < result.entry_low && result.tp2 <= result.tp1)) reasons.push("invalid_trade_geometry");
  if (!Number.isFinite(result.confidence_score) || !Number.isFinite(config2.min_score) || !Number.isFinite(config2.min_rr)) reasons.push("invalid_qualification_inputs");
  if (slPct < (config2.min_stop_distance_pct ?? 0)) reasons.push("sl_too_close");
  if (tp1Pct < (config2.min_tp1_distance_pct ?? 0)) reasons.push("tp1_too_close");
  if (tp2Pct < (config2.min_tp2_distance_pct ?? 0)) reasons.push("tp2_too_close");
  if (rr < config2.min_rr) reasons.push("rr_too_low");
  if (result.confidence_score < config2.min_score) reasons.push("confidence_too_low");
  if (grade(result.grade) < grade(minSignalGrade)) reasons.push("grade_below_min_signal_grade");
  return { passed: reasons.length === 0, reasons: [...new Set(reasons)], slPct, tp1Pct, tp2Pct, riskReward: rr };
}

// supabase/functions/_shared/phase-l-validation.ts
var duration = (tf) => {
  const m = /^(\d+)(m|h|d)$/.exec(tf);
  if (!m) throw new Error("UNSUPPORTED_TIMEFRAME");
  return +m[1] * (m[2] === "m" ? 6e4 : m[2] === "h" ? 36e5 : 864e5);
};
function admitHistoricalCandles(input, timeframe, asOf, calendar = "24x7") {
  const exclusions = [], ms2 = duration(timeframe), limit = Date.parse(asOf), seen = /* @__PURE__ */ new Set(), out = [];
  for (const c of [...input].sort((a, b) => Date.parse(a.open_time) - Date.parse(b.open_time))) {
    const t = Date.parse(c.open_time), normalized = Number.isFinite(t) ? new Date(t).toISOString() : c.open_time;
    let code = "";
    if (!Number.isFinite(t) || !/(Z|[+-]\d\d:\d\d)$/.test(c.open_time)) code = "INVALID_TIMESTAMP_OR_TIMEZONE";
    else if (seen.has(normalized)) code = "DUPLICATE_CANDLE";
    else if (t + ms2 > limit) code = "OPEN_OR_FUTURE_CANDLE";
    else if (![c.open, c.high, c.low, c.close, c.volume].every(Number.isFinite) || c.low < 0 || c.high < Math.max(c.open, c.close) || c.low > Math.min(c.open, c.close) || c.volume < 0) code = "INVALID_OHLC";
    if (code) {
      exclusions.push({ code, openTime: c.open_time, detail: "candle excluded; never repaired" });
      continue;
    }
    seen.add(normalized);
    out.push({ ...c, open_time: normalized });
  }
  for (let i = 1; i < out.length; i++) {
    const gap = Date.parse(out[i].open_time) - Date.parse(out[i - 1].open_time);
    if (gap > ms2) {
      const weekend = calendar === "FOREX_24x5" && [0, 6].includes(new Date(Date.parse(out[i - 1].open_time) + ms2).getUTCDay());
      exclusions.push({ code: weekend ? "MARKET_SESSION_GAP" : "UNEXPECTED_GAP", openTime: out[i].open_time, detail: `${gap / ms2 - 1} missing interval(s)` });
    }
  }
  return { candles: out, exclusions, status: out.length ? "ADMITTED" : "EXCLUDED" };
}
function runBoundedValidation(config2, registry, contexts) {
  if (config2.maxCycles < 1 || config2.maxCycles > 1e4) throw new Error("UNSAFE_CYCLE_LIMIT");
  const decisions = [];
  const used = /* @__PURE__ */ new Set();
  for (const context of contexts) {
    if (decisions.length >= config2.maxCycles) break;
    const at = Date.parse(context.evaluated_at);
    if (at < Date.parse(config2.start) || at > Date.parse(config2.end)) continue;
    if (context.higher_timeframe_candles?.some((c) => !Number.isFinite(Date.parse(c.open_time)) || Date.parse(c.open_time) + 9e5 > at)) throw new Error("LOOKAHEAD_HIGHER_TIMEFRAME");
    const last = context.candles.at(-1);
    if (!Number.isFinite(at) || !last || context.candles.some((c, i) => !Number.isFinite(Date.parse(c.open_time)) || Date.parse(c.open_time) + duration(config2.timeframe) > at || i > 0 && Date.parse(c.open_time) <= Date.parse(context.candles[i - 1].open_time))) throw new Error("LOOKAHEAD_OR_OPEN_CANDLE");
    const cycleId = `${config2.runId}:${config2.symbol}:${config2.timeframe}:${context.evaluated_at}`;
    if (used.has(cycleId)) continue;
    used.add(cycleId);
    const marketContext = classifyMarketContext(context.indicators, context.candles);
    const entries = /* @__PURE__ */ new Map();
    const evaluations = evaluateActiveStrategies(registry, context), qualifications = new Map(evaluations.map((e) => [e.definition.id, qualifyActiveCandidate(e.professional.legacy, e.definition.config, config2.minSignalGrade ?? "A")]));
    const candidates = evaluations.filter((e) => qualifications.get(e.definition.id)?.passed && e.professional.decision !== "NO_TRADE" && e.professional.entry && e.professional.stop && (e.professional.tp1 || dailyEvidence(e.professional.evidence))).map((e) => ({ id: `${cycleId}:${e.definition.id}`, strategyId: e.definition.id, strategyVersion: e.definition.version, market: config2.market, symbol: config2.symbol, timeframe: config2.timeframe, side: e.professional.decision.toLowerCase(), confidence: e.professional.confidence, grade: e.professional.grade, score: arbitrationScore({ name: e.definition.legacyName, result: e.professional.legacy, cfg: e.definition.config, guard: { sl_pct: qualifications.get(e.definition.id).slPct, tp1_pct: qualifications.get(e.definition.id).tp1Pct, tp2_pct: qualifications.get(e.definition.id).tp2Pct } }, marketContext), entry: (e.professional.entry.low + e.professional.entry.high) / 2, stop: e.professional.stop, targets: dailyEvidence(e.professional.evidence) ? [] : [.../* @__PURE__ */ new Set([e.professional.tp1, ...e.professional.tp2 ? [e.professional.tp2] : []])], riskReward: e.professional.risk_reward, expiry: e.professional.expires_at, fresh: true, lifecycle: e.definition.lifecycle === "ENABLED" ? "ENABLED" : "RESEARCH", publicationMode: e.definition.publicationMode ?? "LIVE", evidence: { ...e.professional.evidence, ...e.definition.config.params.estimated_round_trip_cost_bps !== void 0 ? { estimated_round_trip_cost_bps: e.definition.config.params.estimated_round_trip_cost_bps, minimum_net_target_r: e.definition.config.params.minimum_net_target_r ?? 0 } : {}, adaptive_policy_approved: e.definition.config.params.market_adaptation_enabled === 1, configuration_version: config2.configurationVersion, parameter_version: config2.parameterVersion, dataset_id: config2.dataset.id }, rejectionReasons: e.professional.rejection_reasons }));
    for (const evaluation of evaluations) {
      const q = qualifications.get(evaluation.definition.id);
      entries.set(evaluation.definition.id, { name: evaluation.definition.legacyName, result: evaluation.professional.legacy, cfg: evaluation.definition.config, guard: { sl_pct: q.slPct, tp1_pct: q.tp1Pct, tp2_pct: q.tp2Pct } });
    }
    const arbitration = arbitrateActiveScanner(candidates, { now: new Date(context.evaluated_at), minimumScore: config2.minimumScore, allowedGrades: config2.allowedGrades, marketContext, adaptivePolicy: config2.adaptivePolicy, noTradePolicy: (ranked) => arbitrationNoTradeReason(marketContext, ranked.map((c) => entries.get(c.strategyId))) || void 0 });
    decisions.push({ cycleId, candleCloseTime: context.evaluated_at, candidates: evaluations.map((e) => ({ strategyId: e.definition.id, strategyVersion: e.definition.version, decision: e.professional.decision, rejectionReasons: [...e.professional.rejection_reasons, ...qualifications.get(e.definition.id)?.reasons ?? []] })), arbitration, exclusions: [] });
  }
  return decisions;
}
var PHASE_L_AUTHORITY = Object.freeze({ framework: ACTIVE_SCANNER_FRAMEWORK, arbitrator: ACTIVE_SCANNER_ARBITRATOR, publication: false, execution: false, certification: false });

// supabase/functions/_shared/scanner-selection-policy.ts
function applyScannerSelectionPolicy(at, state2, policy) {
  if (policy.preventDuplicateSymbolSignals && state2.activeSignalId) return { allowed: false, reason: "duplicate_active_signal" };
  if (policy.maxActiveSignals !== void 0 && (state2.activeCount ?? 0) >= policy.maxActiveSignals) return { allowed: false, reason: "crypto_concentration_limit" };
  if (state2.lastSelectedAt && Date.parse(at) - Date.parse(state2.lastSelectedAt) < policy.cooldownMs) return { allowed: false, reason: "scanner_cooldown" };
  return { allowed: true, reason: null };
}

// supabase/functions/_shared/phase-m-validation.ts
async function replayScannerChronologically(input) {
  const events = [...input.events].sort((a, b) => Date.parse(a.closedAt) - Date.parse(b.closedAt) || a.symbol.localeCompare(b.symbol) || a.timeframe.localeCompare(b.timeframe));
  const identities = /* @__PURE__ */ new Map(), active = new Map(input.resume?.active), lastSignal = new Map(input.resume?.lastSignal), evidence = [];
  let cursor = input.resume?.cursor ?? 0;
  for (const event of events.slice(cursor)) {
    if (await input.shouldCancel?.()) throw new Error("RUN_CANCELLED");
    const id2 = `${event.symbol}:${event.timeframe}:${event.closedAt}`, prior = identities.get(id2);
    if (prior && prior !== event.contentHash) throw new Error(`REPLAY_CONTENT_CONFLICT:${id2}`);
    if (prior) continue;
    identities.set(id2, event.contentHash);
    for (const [symbol, expiry] of active) if (Date.parse(expiry) <= Date.parse(event.closedAt)) active.delete(symbol);
    for (const symbol of input.beforeEvent?.(event) ?? []) active.delete(symbol);
    const last = lastSignal.get(event.symbol), admission = applyScannerSelectionPolicy(event.closedAt, { activeSignalId: active.has(event.symbol) ? event.symbol : void 0, lastSelectedAt: last, activeCount: active.size }, { preventDuplicateSymbolSignals: true, cooldownMs: input.cooldownMs, maxActiveSignals: input.maxActiveSignals });
    let selection;
    if (!admission.allowed) selection = { decision: "REJECTED", reasons: [admission.reason === "duplicate_active_signal" ? "ACTIVE_SIGNAL_RESTRICTION" : admission.reason === "crypto_concentration_limit" ? "CRYPTO_CONCENTRATION_LIMIT" : "SCANNER_COOLDOWN"] };
    else selection = await input.evaluate(event, { active, lastSignal });
    if (selection.decision === "SIGNAL") {
      if (!selection.signalId || !selection.expiresAt) throw new Error("INVALID_SCANNER_SELECTION");
      active.set(event.symbol, selection.expiresAt);
      lastSignal.set(event.symbol, event.closedAt);
    }
    const row = { event, selection };
    evidence.push(row);
    await input.onEvidence?.(row, { cursor: ++cursor, active: [...active], lastSignal: [...lastSignal] });
  }
  return Object.freeze(evidence);
}

// supabase/functions/_shared/multi-dataset-scanner-replay.ts
var width = (tf) => {
  const m = /^(\d+)(m|h|d)$/.exec(tf);
  if (!m) throw new Error("UNSUPPORTED_TIMEFRAME");
  return Number(m[1]) * (m[2] === "m" ? 6e4 : m[2] === "h" ? 36e5 : 864e5);
};
async function runMultiDatasetScannerReplay(input) {
  if (!input.datasets.length) throw new Error("REPLAY_DATASETS_REQUIRED");
  if (input.datasets.some((d) => d.configurationHash !== input.configurationHash)) throw new Error("REPLAY_CONFIGURATION_LINEAGE_CONFLICT");
  validateCoordinatedDatasets2(input.configuration, input.datasets);
  const alt = needsBtcReference2(input.configuration), windowSize = requiredReplayBars2(input.configuration), events = [], contexts = /* @__PURE__ */ new Map();
  const admitted2 = input.datasets.map((dataset) => ({ dataset, rows: admitHistoricalCandles(dataset.candles, dataset.timeframe, input.end, dataset.market === "crypto" ? "24x7" : "FOREX_24x5").candles }));
  const observedPositions = /* @__PURE__ */ new Map();
  const lifecycle = Boolean(input.lifecycleAssumptions), positions = new Map((input.resume?.positions ?? []).map((p) => [p.candidate.symbol, p]));
  if (lifecycle && input.resume?.cursor && input.resume.lifecycleVersion !== REPLAY_LIFECYCLE_VERSION) throw Error("REPLAY_LIFECYCLE_CHECKPOINT_REQUIRES_NEW_RUN");
  if (lifecycle && [...positions.values()].some((p) => !admitted2.some((d) => d.dataset.id === p.datasetId && d.dataset.symbol === p.candidate.symbol && d.dataset.timeframe === p.candidate.timeframe && d.dataset.market === "crypto") || !input.configuration.strategies.some((s) => s.id === p.candidate.strategyId))) throw Error("REPLAY_LIFECYCLE_CHECKPOINT_INVALID");
  const reference = alt ? admitted2.find((d) => d.dataset.symbol === "BTCUSDT" && d.dataset.timeframe === "15m") : void 0;
  const referenceCloses = new Map(reference?.rows.map((c, i) => [Date.parse(c.open_time) + 9e5, i]) ?? []);
  if (alt && admitted2.filter((d) => d.dataset.timeframe !== "1d").some((d) => d.rows.filter((c) => Date.parse(c.open_time) + 9e5 <= Date.parse(input.start)).length < windowSize)) throw Error("ALT_WARMUP_COVERAGE_REQUIRED");
  for (const { dataset, rows } of admitted2) {
    if (referenceOnly2(input.configuration, dataset.symbol, dataset.timeframe)) continue;
    for (let i = dataset.timeframe === "1d" && hasDaily(input.configuration) ? 200 : alt ? windowSize - 1 : 54; i < rows.length; i++) {
      if (i % 64 === 0 && await input.shouldCancel?.()) throw new Error("RUN_CANCELLED");
      const candles = rows.slice(dataset.timeframe === "1d" && hasDaily(input.configuration) ? 0 : Math.max(0, i - windowSize + 1), i + 1), closedAt = new Date(Date.parse(candles.at(-1).open_time) + width(dataset.timeframe)).toISOString();
      if (hasDaily(input.configuration) && dataset.timeframe === "15m" && Date.parse(closedAt) % 36e5 !== 0) continue;
      if (closedAt < input.start || closedAt > input.end || isCryptoTeam(input.configuration) && Date.parse(closedAt) % 36e5 !== 0) continue;
      const identity = `${dataset.symbol}:${dataset.timeframe}:${closedAt}`, contentHash = `${dataset.hash}:${candles.at(-1).open_time}:${candles.at(-1).close}`;
      events.push({ symbol: dataset.symbol, timeframe: dataset.timeframe, closedAt, contentHash, payload: identity });
      contexts.set(identity, { dataset, candles });
    }
  }
  if (events.length > input.maxCycles) throw new Error("REPLAY_RANGE_EXCEEDS_CYCLE_LIMIT_SELECT_SHORTER_PERIOD");
  return replayScannerChronologically({ shouldCancel: input.shouldCancel, resume: input.resume, beforeEvent: lifecycle ? (event) => {
    const released = [];
    for (const [symbol, position] of positions) {
      const prior = observedPositions.get(symbol);
      if (prior?.id === position.candidate.id && prior.at === event.closedAt) continue;
      observedPositions.set(symbol, { id: position.candidate.id, at: event.closedAt });
      const data2 = admitted2.find((d) => d.dataset.id === position.datasetId);
      if (observeReplayPosition(position, data2.rows, event.closedAt)) {
        positions.delete(symbol);
        released.push(symbol);
      } else if (Date.parse(position.candidate.expiry) <= Date.parse(event.closedAt)) positions.delete(symbol);
    }
    return released;
  } : void 0, onEvidence: async (row, state2) => {
    if (lifecycle) {
      const cycle = row.selection.cycle, arbitration = cycle?.arbitration, winner = arbitration?.winner;
      if (arbitration) arbitration.evidence = { ...arbitration.evidence, selection_lifecycle: REPLAY_LIFECYCLE_VERSION, lifecycle_scope: "crypto", future_outcomes_used_for_admission: false };
      if (winner && winner.market === "crypto" && cycle) {
        const strategy = input.configuration.strategies.find((s) => s.id === winner.strategyId);
        positions.set(winner.symbol, { candidate: winner, decisionAt: row.event.closedAt, datasetId: cycle.datasetId, assumptions: { ...dailyOutcomeAssumptions(winner.strategyId, input.lifecycleAssumptions), maxBarsInTrade: dailyOutcomeAssumptions(winner.strategyId, input.lifecycleAssumptions).maxBarsInTrade ?? strategy.maxBarsInTrade } });
      }
      state2.lifecycleVersion = REPLAY_LIFECYCLE_VERSION;
      state2.positions = [...positions.values()];
    }
    await input.onEvidence?.(row, state2);
  }, events: events.sort((a, b) => Date.parse(a.closedAt) - Date.parse(b.closedAt) || a.symbol.localeCompare(b.symbol) || a.timeframe.localeCompare(b.timeframe)).slice(0, input.maxCycles), cooldownMs: input.cooldownMs, ...isCryptoTeam(input.configuration) || isSignalEnsemble(input.configuration) || hasDaily(input.configuration) ? { maxActiveSignals: 3 } : {}, evaluate: (event) => {
    const ctx = contexts.get(String(event.payload)), registry = createApprovedReplayRegistry(input.configuration, event.symbol, event.timeframe);
    const config2 = { runId: input.runId, mode: "REPLAY", dataset: { id: ctx.dataset.id, source: ctx.dataset.source, provenance: "MULTI_DATASET_REPLAY", sha256: ctx.dataset.hash, timezone: "UTC", marketCalendar: ctx.dataset.market === "crypto" ? "24x7" : "FOREX_24x5" }, configurationVersion: input.configuration.version, parameterVersion: input.configurationHash, symbol: event.symbol, market: ctx.dataset.market, timeframe: event.timeframe, start: event.closedAt, end: event.closedAt, maxCycles: 1, minimumScore: 0, allowedGrades: ["A+", "A", "B"], minSignalGrade: input.configuration.minSignalGrade };
    const referenceIndex = referenceCloses.get(Date.parse(event.closedAt));
    const decision = runBoundedValidation(config2, registry, [{ symbol: event.symbol, market: ctx.dataset.market, timeframe: event.timeframe, candles: ctx.candles, indicators: calculateActiveIndicators(ctx.candles.slice(-ACTIVE_MARKET_WINDOW)), evaluated_at: event.closedAt, higher_timeframe_candles: event.timeframe === "5m" ? closedFifteenMinuteContext(ctx.dataset.candles, event.closedAt) : void 0, reference_candles: referenceIndex === void 0 ? void 0 : reference.rows.slice(Math.max(0, referenceIndex - windowSize + 1), referenceIndex + 1) }])[0];
    const winner = decision?.arbitration.winner, cycle = decision ? { cycleId: decision.cycleId, candidates: decision.candidates, arbitration: decision.arbitration, datasetId: ctx.dataset.id, datasetHash: ctx.dataset.hash, configurationHash: input.configurationHash } : void 0;
    if (reference && decision) decision.arbitration.evidence = { ...decision.arbitration.evidence, reference_dataset_id: reference.dataset.id, reference_dataset_hash: reference.dataset.hash, reference_as_of: event.closedAt, research_only: true };
    return winner ? { decision: "SIGNAL", signalId: winner.id, expiresAt: winner.expiry, reasons: [], cycle } : { decision: "NO_TRADE", reasons: decision?.arbitration.rejected.flatMap((r) => r.reasons) ?? ["NO_CANDIDATE"], cycle };
  } });
}

// scripts/research/daily-connected/combined.ts
var sha = (b) => createHash("sha256").update(b).digest("hex");
var native = JSON.parse(gunzipSync(readFileSync("docs/research/daily-connected/native-fixtures.json.gz")).toString());
var config = dailyConfiguration(PROMISING_PAIR_PROFILE);
var configurationHash = sha(JSON.stringify(config));
var sources = [];
var data = native.assets.map((a) => ({ id: a.symbol + "-spot-daily", hash: sha(JSON.stringify(a.candles)), configurationHash, source: "BINANCE_KLINES", symbol: a.symbol, market: "crypto", timeframe: "1d", candles: a.candles }));
for (const symbol of ["BTCUSDT", "BNBUSDT", "SOLUSDT", "XRPUSDT"]) {
  const candles = [];
  for (let year = 2025; year <= 2026; year++) for (let month = 1; month <= (year === 2025 ? 12 : 9); month++) {
    const name = `${symbol}-15m-${year}-${String(month).padStart(2, "0")}`, folder = existsSync(`../research-data/crypto-development/${name}.json`) ? "crypto-development" : "signal-extended", prefix = `../research-data/${folder}/${name}`, raw = readFileSync(prefix + ".json"), meta = JSON.parse(readFileSync(prefix + ".manifest.json", "utf8")), zip = readFileSync(prefix + ".zip"), checksum = readFileSync(prefix + ".zip.CHECKSUM", "utf8").split(/\s/)[0];
    if (sha(raw) !== meta.datasetSha256 || sha(zip) !== checksum || checksum !== meta.rawSha256) throw Error("SOURCE_HASH");
    sources.push(meta);
    candles.push(...JSON.parse(raw.toString()));
  }
  data.push({ id: symbol + "-usdm-15m", hash: sha(JSON.stringify(candles)), configurationHash, source: "BINANCE_USDM_KLINES", symbol, market: "crypto", timeframe: "15m", candles });
}
var engineFiles = ["scripts/research/daily-connected/combined.ts", ...["daily-trend-contract.ts", "daily-trend.ts", "daily-trend-outcome.ts", "daily-trend-profile.ts", "replay-outcomes.ts", "phase-l-validation.ts", "active-qualification.ts", "arbitrator.ts", "scanner-replay-lifecycle.ts", "multi-dataset-scanner-replay.ts", "signal-ensemble-selection.ts", "active-validation-runtime.ts", "scanner-market-context.ts"].map((p) => "supabase/functions/_shared/" + p)];
var sourceHashes = Object.fromEntries(engineFiles.map((p) => [p, sha(readFileSync(p))]));
var state;
var selected = [];
var cycles = 0;
for (let month = 1; month < 21; month++) {
  const from = new Date(Date.UTC(2025, month, 1)).toISOString(), until = new Date(Date.UTC(2025, month + 1, 1)).toISOString();
  const end = new Date(Date.parse(until) - 1).toISOString();
  const datasets = data.map((d) => ({ ...d, candles: d.timeframe === "1d" ? d.candles.filter((c) => Date.parse(c.open_time) < Date.parse(until)) : d.candles.filter((c) => Date.parse(c.open_time) >= Date.parse(from) - 960 * 9e5 && Date.parse(c.open_time) < Date.parse(until)) }));
  await runMultiDatasetScannerReplay({ runId: "daily-alt-continuous", datasets, configuration: config, configurationHash, start: from, end, cooldownMs: 0, maxCycles: 1e4, lifecycleAssumptions: config.outcomeAssumptions, resume: state ? { ...state, cursor: 0 } : void 0, onEvidence: async (row, resume) => {
    cycles++;
    state = structuredClone(resume);
    const c = row.selection.cycle?.arbitration?.winner;
    if (!c) return;
    const d = data.find((d2) => d2.symbol === c.symbol && d2.timeframe === c.timeframe);
    const a = dailyOutcomeAssumptions(c.strategyId, config.outcomeAssumptions), stress = { ...a, feeBps: a.feeBps * 1.5, spreadBps: a.spreadBps * 1.5, slippageBps: a.slippageBps * 1.5, fundingBps: a.fundingBps * 1.5 };
    const base = evaluateReplayOutcome(c, d.candles, row.event.closedAt, a), stressed = evaluateReplayOutcome(c, d.candles, row.event.closedAt, stress);
    if (!base || !stressed) throw Error("OUTCOME_MISSING");
    selected.push({ at: row.event.closedAt, candidate: c, base, stress: stressed });
  } });
  console.log(JSON.stringify({ through: until, cycles, selections: selected.length }));
  writeFileSync("../daily-connected-checkpoint.json", JSON.stringify({ through: until, cycles, state, selected, configurationHash, sourceHashes }));
}
var counts = /* @__PURE__ */ new Map();
for (const s of selected) if (s.base.status !== "EXCLUDED") counts.set(s.base.entryTime.slice(0, 10), (counts.get(s.base.entryTime.slice(0, 10)) ?? 0) + 1);
var quiet = 0;
var streak = 0;
var longest = 0;
var days = 0;
for (let t = Date.parse("2025-02-01"); t < Date.parse("2026-10-01"); t += 864e5) {
  days++;
  if (!counts.has(new Date(t).toISOString().slice(0, 10))) {
    quiet++;
    longest = Math.max(longest, ++streak);
  } else streak = 0;
}
for (const [p, h] of Object.entries(sourceHashes)) if (sha(readFileSync(p)) !== h) throw Error("FROZEN_ENGINE_CHANGED");
var summary = { sourceHashes, classification: "CONTINUOUS_CANONICAL_REGISTRY_ARBITRATION_WITH_OBSERVED_LIFECYCLE_ALREADY_SEEN_CALENDAR", configuration: config, configurationHash, cycles, base: summarizeReplayOutcomes(selected.map((s) => s.base)), stress: summarizeReplayOutcomes(selected.map((s) => s.stress)), byRole: config.strategies.map((r) => ({ id: r.id, base: summarizeReplayOutcomes(selected.filter((s) => s.candidate.strategyId === r.id).map((s) => s.base)), stress: summarizeReplayOutcomes(selected.filter((s) => s.candidate.strategyId === r.id).map((s) => s.stress)) })), activity: { days, entries: [...counts.values()].reduce((a, b) => a + b, 0), quietDays: quiet, longestQuietStreak: longest, meanPerDay: [...counts.values()].reduce((a, b) => a + b, 0) / days, activeDayFraction: (days - quiet) / days }, publication: false, execution: false, promotion: false };
writeFileSync("docs/research/daily-connected/combined-evidence.json.gz", gzipSync(JSON.stringify({ ...summary, sources: [...native.sources, ...sources], selected })));
writeFileSync("docs/research/daily-connected/combined-summary.json", JSON.stringify(summary, null, 2) + "\n");
console.log(JSON.stringify({ base: summary.base.profitFactor, stress: summary.stress.profitFactor, activity: summary.activity }));
