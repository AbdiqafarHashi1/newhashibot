import {EXECUTION_CANONICAL_REVIEWS} from './execution-canonical-reviews.ts';
import {FRONTIER_CANONICAL_REVIEWS} from './frontier-canonical-reviews.ts';
import {LAUNCH_CANONICAL_REVIEWS} from './launch-canonical-reviews.ts';
import {executionStrategyChoices} from './execution-strategy-selection.ts';
import {PROP_STRATEGY_BUNDLES} from './prop-strategy-bundles.ts';

/** Selection shortcuts only. Never alter risk, symbols, releases or account authorization. */
export function executionStrategyPresets(provider:string,environment:string){
 if(!['MT5','MT5_PERSONAL','MT5_PROP','BINANCE','BYBIT'].includes(provider.toUpperCase())||!['demo','testnet','live'].includes(environment))return [];
 const available=new Set(executionStrategyChoices(provider,environment).map(c=>c.id));
 const reviewed=LAUNCH_CANONICAL_REVIEWS.map(r=>r.strategyId).filter(id=>available.has(id));
 const definitions=[
  {id:'reviewed',label:provider.toUpperCase()==='MT5_PROP'?'Prop · reviewed Forex & Gold':'All reviewed configurations',ids:reviewed},
  {id:'gold-compression',label:'Gold · compression · full 5R',ids:FRONTIER_CANONICAL_REVIEWS.map(r=>r.strategyId).filter(id=>available.has(id))},
  {id:'gold',label:'Gold · momentum & reversal',ids:reviewed.filter(id=>id.startsWith('gold.'))},
  {id:'forex',label:'Forex · Yen & Sterling',ids:reviewed.filter(id=>id.startsWith('forex.'))},
  {id:'crypto-swing',label:'Crypto · swing & pullback',ids:reviewed.filter(id=>id.startsWith('crypto.')&&!id.includes('native-'))},
  {id:'crypto-intraday',label:'Crypto · DOGE & LTC intraday',ids:reviewed.filter(id=>id.startsWith('crypto.native-'))},
  {id:'prop-intraday',label:'Prop · intraday comparison',ids:provider.toUpperCase()==='MT5_PROP'?PROP_STRATEGY_BUNDLES.INTRADAY.ids.filter(id=>reviewed.includes(id)):[]},
 ];
 return definitions.filter(p=>p.ids.length>0);
}
const friendlyNames:Record<string,string>={
 'gold.frontier-compression-15-24-1.5-5-h96':'Gold compression · 15m · 5R · up to 24h',
 'crypto.launch-trend-pullback-48-1.5-5':'Crypto trend pullback · 1.5 ATR / 5R',
 'crypto.launch-trend-pullback-48-2-3-h72':'Crypto trend pullback · 2 ATR / 3R',
 'crypto.launch-rsi2-48-3-3-h72':'Crypto RSI reversal · 3 ATR / 3R',
 'crypto.native-vwap-reclaim-5-24-2-1.5-dogeusdt-h12-v0.006':'DOGE VWAP reclaim · 5m · 1.5R',
 'crypto.native-failed-breakout-15-48-3-1.5-ltcusdt-h24-v0.006':'LTC failed breakout · 15m · 1.5R',
 'gold.native-momentum-15-48-2-5':'Gold momentum · 15m · 5R',
 'gold.native-momentum-60-24-2-5':'Gold momentum · 1h · 5R',
 'gold.native-band-reentry-15-48-3-5':'Gold range re-entry · 15m · 5R',
 'forex.native-band-reentry-60-12-2-5':'USDJPY range re-entry · 1h · 5R',
 'forex.native-sweep-retest-60-16-2-5-usdjpy-h72':'USDJPY sweep & retest · 1h · 5R',
 'forex.native-squeeze-15-48-2-3-usdjpy-h12':'USDJPY compression breakout · 15m · 3R',
 'forex.native-rsi2-15-48-2-5-gbpusd-h24-v0.0008':'GBPUSD RSI reversal · 15m · 5R',
};
export function executionStrategyDisplayName(id:string,fallback:string){return friendlyNames[id]??fallback;}
export function executionStrategyEvidence(id:string){return EXECUTION_CANONICAL_REVIEWS.find(r=>r.strategyId===id)??null;}
