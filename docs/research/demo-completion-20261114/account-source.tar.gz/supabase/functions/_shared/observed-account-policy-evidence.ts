import {approvedPropAccountProfile} from './prop-account-profile.ts';
import {isSourceBoundFtmoStaticRules} from './prop-program.ts';
import {assertPropServiceCapital} from './prop-service-limits.ts';
import {observedBybitQuoteConversion} from './bybit-wallet-valuation.ts';
import {validateAccountExecutionContext} from './account-execution-brain/contracts.ts';
import type {AccountExecutionContext} from './account-execution-brain/types.ts';
const finite=(v:unknown):v is number=>typeof v==='number'&&Number.isFinite(v);
export function assertCompleteProductionContext(c:AccountExecutionContext,scope:{customerId:string;accountId:string;provider:string;observedAt:string},now=Date.now()){
 if(!validateAccountExecutionContext(c).valid||c.account_id!==scope.accountId||c.user_id!==scope.customerId||c.provider!==scope.provider||!['DEMO','TESTNET','LIVE'].includes(c.environment)||Date.parse(c.updated_at)!==Date.parse(scope.observedAt))throw Error('COMPLETE_SCOPED_CONTEXT_REQUIRED');
 const age=now-Date.parse(scope.observedAt);if(!Number.isFinite(age)||age<0||age>60000)throw Error('PROVIDER_CONTEXT_STALE');
 if(![c.balance,c.equity,c.free_margin,c.used_margin,c.leverage].every(finite)||c.balance<=0||c.equity<=0||c.free_margin<0||c.used_margin<0||c.leverage<=0)throw Error('ACCOUNT_FINANCIAL_CONTEXT_REQUIRED');
 for(const [value,keys] of [[c.daily_drawdown,['starting_balance','peak_equity','current_drawdown_amount','current_drawdown_pct','max_allowed_pct']],[c.total_drawdown,['initial_balance','high_water_mark','current_drawdown_amount','current_drawdown_pct','max_allowed_pct']],[c.exposure,['total_notional_usd','total_open_risk_usd','total_open_risk_pct','active_position_count']],[c.risk_profile,['max_risk_per_trade_pct','max_open_risk_pct','max_leverage','min_notional_usd']]] as const){if(!value||keys.some(k=>!finite((value as unknown as Record<string,unknown>)[k])||Number((value as unknown as Record<string,unknown>)[k])<0))throw Error('ACCOUNT_RISK_CONTEXT_REQUIRED')}
 if(!Array.isArray(c.open_positions)||c.open_positions.length!==c.exposure.active_position_count||c.open_positions.some(p=>!p.ticket_or_id||!p.symbol||!['BUY','SELL'].includes(p.side)||![p.quantity,p.entry_price,p.current_price,p.unrealized_pnl,p.open_risk_amount,p.open_risk_pct,p.notional_value].every(finite)||p.quantity<=0||p.open_risk_amount<0))throw Error('COMPLETE_POSITION_CONTEXT_REQUIRED');
 if(!c.exposure.positions_by_symbol||Object.values(c.exposure.positions_by_symbol).some(v=>!Number.isInteger(v)||v<0)||Math.abs(c.open_positions.reduce((n,p)=>n+p.open_risk_amount,0)-c.exposure.total_open_risk_usd)>1e-6)throw Error('POSITION_RISK_RECONCILIATION_REQUIRED');
 const staticProp=c.provider==='MT5_PROP'&&['PROP_EVALUATION','PROP_FUNDED'].includes(c.account_type)&&isSourceBoundFtmoStaticRules(c.prop_rules);
 if(c.daily_drawdown.starting_balance<=0||c.total_drawdown.initial_balance<=0||c.daily_drawdown.current_drawdown_amount+1e-6<Math.max(0,(staticProp?c.daily_drawdown.starting_balance:Math.max(c.daily_drawdown.starting_balance,c.daily_drawdown.peak_equity))-c.equity)||c.total_drawdown.current_drawdown_amount+1e-6<Math.max(0,(staticProp?c.total_drawdown.initial_balance:Math.max(c.total_drawdown.initial_balance,c.total_drawdown.high_water_mark))-c.equity)||c.exposure.total_open_risk_pct+1e-6<c.exposure.total_open_risk_usd/c.balance*100)throw Error('DRAWDOWN_OR_EXPOSURE_UNDERSTATED');
 if(typeof c.daily_drawdown.is_violated!=='boolean'||typeof c.total_drawdown.is_violated!=='boolean'||!c.session_state||typeof c.session_state.is_session_open!=='boolean'||!c.session_state.active_session_name||!c.news_state||typeof c.news_state.in_high_impact_news_window!=='boolean'||!c.runtime_health||typeof c.runtime_health.is_healthy!=='boolean'||!Number.isInteger(c.runtime_health.error_count_last_hour))throw Error('OBSERVED_MARKET_RUNTIME_CONTEXT_REQUIRED');
 for(const t of [c.session_state.current_time_utc,c.runtime_health.last_heartbeat_at]){const a=now-Date.parse(t);if(!Number.isFinite(a)||a<0||a>60000)throw Error('MARKET_RUNTIME_CONTEXT_STALE')}
 if(c.provider==='MT5_PROP'&&(!c.prop_rules||!Object.values(c.prop_rules).every(v=>typeof v==='boolean'||typeof v==='string'||finite(v))))throw Error('PROP_RULE_CONTEXT_REQUIRED');
}
/** Internal provider workers publish a full context; financial facts are checked against the current monitor. */
export async function recordObservedAccountPolicyEvidence(db:any,input:any,now=Date.now()){
 const c=input.account_context,scope={customerId:input.customer_id,accountId:input.execution_account_id,provider:input.provider,observedAt:input.observed_at};assertCompleteProductionContext(c,scope,now);
 const a=await db.from('connected_execution_accounts').select('*').eq('id',scope.accountId).eq('customer_id',scope.customerId).single();if(a.error||!a.data||String(a.data.provider).toUpperCase()!==scope.provider)throw Error('ACCOUNT_EVIDENCE_OWNER_REQUIRED');
 if(isSourceBoundFtmoStaticRules(c.prop_rules)&&(c.provider!=='MT5_PROP'||!isSourceBoundFtmoStaticRules(approvedPropAccountProfile(a.data))))throw Error('APPROVED_STATIC_PROP_SCOPE_REQUIRED');
 if(c.environment!==String(a.data.environment).toUpperCase()||c.account_type!==a.data.account_mode)throw Error('PROVIDER_ACCOUNT_MODE_MISMATCH');
 const mt5=scope.provider.startsWith('MT5');let q=db.from(mt5?'mt5_account_snapshots':'execution_account_runtime_proof').select('*').eq(mt5?'owner_id':'customer_id',scope.customerId).eq('account_id',mt5?a.data.provider_account_identity:a.data.account_id);if(!mt5)q=q.eq('execution_instance_id',a.data.execution_instance_id).eq('credential_ref',a.data.credential_ref);
 const proof=await q.order(mt5?'captured_at':'observed_at',{ascending:false}).limit(1).maybeSingle();if(proof.error||!proof.data)throw Error('CURRENT_PROVIDER_SNAPSHOT_REQUIRED');
 const raw=mt5?proof.data:proof.data.account_state,at=mt5?proof.data.captured_at:proof.data.observed_at;
 const numbers=mt5?[raw.balance,raw.equity,raw.free_margin]:scope.provider==='BINANCE'?[raw.account_total_wallet_balance,raw.account_total_margin_balance,raw.account_available_balance]:[raw.account_wallet_balance,raw.account_equity,raw.trading_available_balance];
 if(Date.parse(at)!==Date.parse(scope.observedAt)||numbers.some((v:any,i:number)=>v===null||v===undefined||!Number.isFinite(Number(v))||Math.abs(Number(v)-[c.balance,c.equity,c.free_margin][i])>1e-6))throw Error('PROVIDER_FINANCIAL_EVIDENCE_MISMATCH');
 const positions=mt5?raw.positions:scope.provider==='BINANCE'?raw.open_binance_positions:raw.positions;
 const orders=mt5?raw.orders:scope.provider==='BINANCE'?raw.open_binance_orders:raw.open_orders;
 if(!Array.isArray(orders)||orders.length!==input.pending_orders)throw Error('PROVIDER_ORDER_EVIDENCE_MISMATCH');
 if(!Array.isArray(positions)||positions.length!==c.open_positions.length||positions.some((p:any)=>!c.open_positions.some((x:any)=>x.symbol===p.symbol&&Math.abs(x.quantity-Math.abs(Number(p.quantity??p.volume??p.positionAmt??p.size)))<1e-8)))throw Error('PROVIDER_POSITION_EVIDENCE_MISMATCH');
 if(!input.contract_specification||input.contract_specification.provider!==scope.provider||input.contract_specification.symbol!==input.symbol||input.routing_policy?.provider!==scope.provider||input.capabilities?.provider!==scope.provider||!Number.isInteger(input.pending_orders)||input.pending_orders<0)throw Error('PROVIDER_ROUTING_EVIDENCE_REQUIRED');
 if(scope.provider==='BYBIT'&&input.contract_specification.account_currency==='USD'){const rate=observedBybitQuoteConversion(raw);if(Math.abs(rate-Number(input.contract_specification.quote_to_account_conversion))>1e-10)throw Error('BYBIT_CURRENCY_VALUATION_MISMATCH');}
 if(scope.provider==='MT5_PROP')assertPropServiceCapital(c.total_drawdown.initial_balance,input.contract_specification.account_currency);
 const row={...input,execution_instance_id:a.data.execution_instance_id,credential_ref:a.data.credential_ref,source_reference:`${mt5?'mt5':'crypto'}:${proof.data.id??at}`};
 const saved=await db.from('account_policy_evidence').insert(row).select('id').single();if(saved.error||!saved.data)throw Error('ACCOUNT_POLICY_EVIDENCE_NOT_PERSISTED');return saved.data;
}
