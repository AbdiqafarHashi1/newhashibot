import {BINANCE_TESTNET_CANONICAL_SYSTEM_IDENTITY,verifyProvider,type OnboardingProvider,type RawCredential,type SafeVerification} from "./execution-account-onboarding.ts";
export interface CustomerCredentialStore { knownBinding?():Promise<{identity:string;fingerprint:string;kind:"NATIVE_ACCOUNT"|"DEMO_CREDENTIAL"}|null>; persist(input:{customerId:string;accountId:string;provider:OnboardingProvider;secretJson:string;verification:SafeVerification}):Promise<string>; }
/** Verify first, persist second. Raw material is never returned and no fallback store exists. */
export async function verifyAndPersistCustomerCredential(input:{customerId:string;accountId:string;provider:OnboardingProvider;environment:string;credential:RawCredential;store:CustomerCredentialStore;fetcher?:typeof fetch}){
 let verification=await verifyProvider(input.provider,input.environment,input.credential,input.fetcher);
 const known=verification.credential_fingerprint&&input.store.knownBinding?await input.store.knownBinding():null;
 if(known&&known.fingerprint===verification.credential_fingerprint&&known.kind==='NATIVE_ACCOUNT'&&verification.native_account_uid&&known.identity!==verification.native_account_uid)throw Error('PROVIDER_IDENTITY_CHANGED_CREATE_SEPARATE_ACCOUNT');
 if(known&&known.fingerprint===verification.credential_fingerprint)verification={...verification,discovered_account_identity:known.identity,identity_kind:known.kind};
 if(!verification.connection_verified||verification.first_blocker)throw new Error(verification.first_blocker??"PROVIDER_VERIFICATION_FAILED");
 if(!verification.trading_permission)throw new Error("TRADING_PERMISSION_REQUIRED");
 if(verification.withdrawal_permission!==false)throw new Error("WITHDRAWAL_PERMISSION_REJECTED");
 if(!verification.discovered_account_identity||verification.discovered_account_identity===BINANCE_TESTNET_CANONICAL_SYSTEM_IDENTITY)throw new Error("CUSTOMER_PROVIDER_IDENTITY_UNVERIFIED");
 const secretJson=JSON.stringify({api_key:input.credential.apiKey,api_secret:input.credential.apiSecret});
 const reference=await input.store.persist({customerId:input.customerId,accountId:input.accountId,provider:input.provider,secretJson,verification});
 return Object.freeze({state:"CONNECTED" as const,provider:input.provider.toUpperCase(),environment:input.environment,identityKind:verification.identity_kind??"NATIVE_ACCOUNT",accountIdentity:verification.discovered_account_identity,capabilities:{trading:true,withdrawal:false,verified:true},credentialReference:`vault:••••${reference.slice(-8)}`});
}
