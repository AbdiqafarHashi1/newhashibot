import { deepFreeze, stableFingerprint, type DeepReadonly } from "./strategy-plan.ts";
import type { ExecutionPlan, PlannedOrder, PlannedProviderConfiguration } from "./professional-execution-planning.ts";
import type { CertifiedProviderPort, ProviderLookupResult, ProviderSubmissionResult } from "./professional-execution-adoption.ts";

export interface ExactProviderTransport { send(operation: string, payload: Readonly<Record<string, unknown>>, identity: string): Promise<ProviderSubmissionResult>; lookup(identity: string): Promise<ProviderLookupResult>; }

abstract class ExactAdapter implements CertifiedProviderPort {
  constructor(protected readonly plan: DeepReadonly<ExecutionPlan>, protected readonly transport: ExactProviderTransport) {}
  protected abstract validateOrder(order: DeepReadonly<PlannedOrder>): void;
  async configure(instruction: DeepReadonly<PlannedProviderConfiguration>): Promise<ProviderSubmissionResult> { if (!this.plan.provider_configuration.includes(instruction)) throw new Error("uncertified_configuration_instruction"); return this.transport.send(instruction.action, instruction.provider_payload, instruction.idempotency_key); }
  async submit(order: DeepReadonly<PlannedOrder>): Promise<ProviderSubmissionResult> { if (!this.plan.orders.includes(order)) throw new Error("uncertified_order_instruction"); this.validateOrder(order); return this.transport.send(order.order_type, order.provider_payload, order.client_order_id); }
  lookupByClientId(clientOrderId: string): Promise<ProviderLookupResult> { return this.transport.lookup(clientOrderId); }
}

export class BinanceTestnetAdoptionAdapter extends ExactAdapter { protected validateOrder(order: DeepReadonly<PlannedOrder>): void { if (this.plan.provider !== "BINANCE" || this.plan.routing?.environment !== "TESTNET" || order.provider !== "BINANCE" || order.provider_payload.newClientOrderId !== order.client_order_id) throw new Error("binance_testnet_payload_not_certified"); } }
export class BybitDemoAdoptionAdapter extends ExactAdapter { protected validateOrder(order: DeepReadonly<PlannedOrder>): void { if (this.plan.provider !== "BYBIT" || this.plan.routing?.environment !== "DEMO" || order.provider !== "BYBIT" || order.provider_payload.orderLinkId !== order.client_order_id || order.provider_payload.category === undefined) throw new Error("bybit_demo_v5_payload_not_certified"); } }
export class Mt5PersonalDemoAdoptionAdapter extends ExactAdapter { protected validateOrder(order: DeepReadonly<PlannedOrder>): void { if (this.plan.provider !== "MT5_PERSONAL" || this.plan.routing?.environment !== "DEMO" || order.provider !== "MT5_PERSONAL" || order.provider_payload.comment !== order.client_order_id || order.provider_payload.lots !== order.quantity) throw new Error("mt5_personal_demo_command_not_certified"); } }
export class Mt5PropDemoAdoptionAdapter extends ExactAdapter { protected validateOrder(order: DeepReadonly<PlannedOrder>): void { if (this.plan.provider !== "MT5_PROP" || this.plan.routing?.environment !== "DEMO" || order.provider !== "MT5_PROP" || order.provider_payload.comment !== order.client_order_id || order.provider_payload.lots !== order.quantity) throw new Error("mt5_prop_demo_command_not_certified"); } }

/** Only the canonical revalidator may provide the live permission; demo adapters still reject live by default. */
export class ApprovedLiveAdoptionAdapter extends ExactAdapter {
 constructor(plan:DeepReadonly<ExecutionPlan>,transport:ExactProviderTransport,private readonly permissionVerified:boolean=false){super(plan,transport)}
 protected validateOrder(order:DeepReadonly<PlannedOrder>):void {
  if(!this.permissionVerified||this.plan.routing?.environment!=='LIVE'||order.provider!==this.plan.provider)throw Error('LIVE_EXECUTION_PERMISSION_REQUIRED');
  const p=order.provider_payload;
  if(this.plan.provider==='BINANCE'&&p.newClientOrderId!==order.client_order_id||this.plan.provider==='BYBIT'&&(p.orderLinkId!==order.client_order_id||p.category!=='linear')||this.plan.provider.startsWith('MT5')&&(p.comment!==order.client_order_id||p.lots!==order.quantity))throw Error('LIVE_NATIVE_PAYLOAD_MISMATCH');
 }
}

export const SHADOW_COMPARE_VERSION = "execution-shadow-compare/v1" as const;
export interface LegacyExecutionProjection { provider: string; account_id: string; symbol: string; side: string; entry_type: string; quantity: number; leverage: number; entry_price: number | null; stop: number | null; tp1: number | null; tp2: number | null; time_in_force: string; reduce_only_semantics: string; protection_sequence: readonly string[]; }
export function shadowCompare(plan: DeepReadonly<ExecutionPlan>, legacy: LegacyExecutionProjection) {
  const entry = plan.orders.find((o) => o.role === "ENTRY" || o.role.startsWith("ENTRY_TP")); const stop = plan.orders.find((o) => o.role === "STOP_LOSS"); const tp1 = plan.orders.find((o) => o.role === "TAKE_PROFIT_1"); const tp2 = plan.orders.find((o) => o.role === "TAKE_PROFIT_2");
  const certified: LegacyExecutionProjection = { provider: plan.provider, account_id: plan.routing?.account_id ?? "", symbol: plan.routing?.provider_symbol ?? "", side: entry?.side ?? "", entry_type: entry?.order_type ?? "", quantity: plan.capital_allocation_plan.allocation?.quantity ?? 0, leverage: plan.capital_allocation_plan.allocation?.leverage ?? 0, entry_price: entry?.price ?? null, stop: stop?.trigger ?? plan.strategy_plan.risk_proposal.initial_stop, tp1: tp1?.trigger ?? plan.strategy_plan.risk_proposal.tp1, tp2: tp2?.trigger ?? plan.strategy_plan.risk_proposal.tp2, time_in_force: entry?.time_in_force ?? "", reduce_only_semantics: String(stop?.reduce_only ?? false), protection_sequence: plan.orders.filter((o) => o.role === "STOP_LOSS" || o.role.startsWith("TAKE_PROFIT")).map((o) => o.role) };
  const differences = Object.keys(certified).filter((key) => stableFingerprint(certified[key as keyof LegacyExecutionProjection]) !== stableFingerprint(legacy[key as keyof LegacyExecutionProjection]));
  const classification = differences.length === 0 ? "EXACT_PARITY" : differences.every((x) => x === "entry_price") ? "ECONOMICALLY_EQUIVALENT" : "MATERIAL_BEHAVIORAL_DRIFT";
  return deepFreeze({ schema_version: SHADOW_COMPARE_VERSION, execution_plan_id: plan.execution_plan_id, classification, differences, certified, legacy, fingerprint: stableFingerprint({ plan: plan.execution_fingerprint, certified, legacy }) });
}

export const EXECUTION_PROOF_REQUEST_VERSION = "execution-proof-request/v1" as const;
export interface ExecutionProofRequest { schema_version: typeof EXECUTION_PROOF_REQUEST_VERSION; mode: "DRY_RUN" | "SHADOW_COMPARE" | "SUBMIT_ONE"; provider: ExecutionPlan["provider"]; environment: "TESTNET" | "DEMO" | "LIVE"; account_id: string; symbol: string; maximum_authorized_test_risk: number; confirmation: "NONE" | "I_UNDERSTAND_TEST_EXECUTION"; credentials_available: boolean; provider_truth_fresh: boolean; certified_policy: boolean; conflicting_proof_run: boolean; rollback_available: boolean; }
export function validateProofRequest(request: ExecutionProofRequest): readonly string[] { const failures: string[] = []; if (request.environment === "LIVE") failures.push("production_environment_forbidden"); if (!request.account_id || !request.symbol) failures.push("explicit_route_required"); if (!(request.maximum_authorized_test_risk > 0 && Number.isFinite(request.maximum_authorized_test_risk))) failures.push("bounded_test_risk_required"); if (request.mode === "SUBMIT_ONE" && request.confirmation !== "I_UNDERSTAND_TEST_EXECUTION") failures.push("explicit_confirmation_required"); if (!request.credentials_available) failures.push("credentials_unavailable"); if (!request.provider_truth_fresh) failures.push("provider_truth_stale"); if (!request.certified_policy) failures.push("adoption_policy_uncertified"); if (request.conflicting_proof_run) failures.push("conflicting_proof_run"); if (!request.rollback_available) failures.push("rollback_unavailable"); return deepFreeze(failures); }
